#!/usr/bin/env python3
"""
RailCall flow runtime v0 — THE MOTOR.

A flow = stages + deterministic transition rules. When data shoots in, each item is auto-routed to its
stage and the next action is QUEUED. The blueprint (compose_engine) draws the pipeline; this MOVES data
through it.

Honest boundaries (the brand):
  - routing + queuing is REAL and deterministic (transparent rules, no model in the loop).
  - WRITES (emails, collections letters, status changes) are GOVERNED — queued for the Approval Airlock,
    NEVER auto-sent here. This routes and decides; the airlock-bound write actually does it (next wire).
  - every run leaves a receipt (what moved, what's queued, integrity hash). Touches no external API.
"""
import re
import io
import csv
import json
import hashlib


def _num(v):
    if v in (None, ""):
        return None
    try:
        return float(re.sub(r"[^0-9.\-]", "", str(v)))
    except Exception:
        return None


# GENERIC field detection — the engine is NOT AR-specific. It reads whatever columns a dataset has.
WRITE_KW = ("send", "email", "letter", "post", "create", "update", "notify", "charge", "message",
            "issue", "draft", "escalat", "call", "remind", "publish", "assign")
STATUS_FIELDS = ("stage", "status", "state", "phase", "bucket", "stage_in", "status_in")
STATUS_KW = ("stage", "status", "state", "phase", "bucket")
NAME_FIELDS = ("client", "customer", "name", "account", "company", "contact", "lead")
AMOUNT_KW = ("amount", "balance", "total", "value", "price", "mrr", "due", "owed", "revenue")


def _field(record, names):
    for k in record:
        if k and str(k).strip().lower() in names:
            return record[k]
    return None


def _field_kw(record, kws):
    for k in record:
        if k and any(a in str(k).strip().lower() for a in kws):
            return record[k]
    return None


def _status_field(record):
    """The record's status/stage value: exact-name match first, else a column whose NAME contains a status
    keyword (so 'current_stage', 'lead_status', 'deal_state' are all detected, not just 'stage')."""
    v = _field(record, STATUS_FIELDS)
    if v is None or str(v).strip() == "":
        v = _field_kw(record, STATUS_KW)
    return v


AMOUNT_PRIORITY = ("balance", "owed", "due", "amount", "mrr", "total", "value", "price", "revenue")


def _amount_of(record):
    """The record's money value, by PRIORITY: a 'balance/owed/due' column (what's actually owed NOW) beats an
    'invoice_total/value' column, so collections sizing + drafted amounts reflect the remaining balance, not the
    original invoice. Falls back across the priority list."""
    for kw in AMOUNT_PRIORITY:
        for k in record:
            if k and kw in str(k).strip().lower():
                v = _num(record[k])
                if v is not None:
                    return v
    return None


def _is_write(step):
    return any(k in (step or "").lower() for k in WRITE_KW)


def _toks(s):
    return set(re.findall(r"[a-z]{4,}", (s or "").lower()))


def _resolve_step(val, steps):
    """Map a stage_map value to an actual workflow step label (exact ci > substring > token overlap)."""
    if not val:
        return None
    v = str(val).strip().lower()
    for st in steps:
        if st.lower() == v:
            return st
    for st in steps:
        if v and (v in st.lower() or st.lower() in v):
            return st
    vt = _toks(val)
    scored = sorted(((len(vt & _toks(st)), st) for st in steps), reverse=True)
    if scored and scored[0][0] > 0:
        return scored[0][1]
    return None


def _norm_map(m):
    """Lowercase + strip stage_map keys for case-insensitive matching; values kept as-is (None preserved)."""
    out = {}
    for k, v in (m or {}).items():
        if k is None:
            continue
        out[str(k).strip().lower()] = v
    return out


def route(record, steps, stage_map=None):
    """GENERIC routing. PRECEDENCE: (1) an explicit stage_map (the user/compose maps the data's status
    vocabulary -> a step, or to null=terminal), (2) zero/settled amount -> final step, (3) status token-overlap
    with a step, (4) first actionable step. Deterministic, no model in the loop.
    Returns (stage, reason, action, is_write, status)."""
    status = str(_status_field(record) or "").strip()
    amt = _amount_of(record)
    writes = [st for st in steps if _is_write(st)]
    # (1) explicit stage_map — the routing-intelligence unlock for cross-source data
    if stage_map and status and status.strip().lower() in stage_map:
        val = stage_map[status.strip().lower()]
        if val in (None, "", "null", "terminal"):
            return "— (terminal)", "stage_map: %r is terminal — workflow complete, no action queued" % status, \
                "—", False, "terminal_stage"
        st = _resolve_step(val, steps)
        if st:
            return st, "stage_map: %r → %r" % (status, st), st, _is_write(st), \
                ("queued" if _is_write(st) else "in_stage")
        st = writes[0] if writes else (steps[0] if steps else "step")
        return st, "stage_map: %r points to unknown step %r — used first actionable step" % (status, val), \
            st, _is_write(st), ("queued" if _is_write(st) else "in_stage")
    # (2) settled
    if amt is not None and amt == 0 and steps:
        st = steps[-1]
        return st, "amount/balance is 0 — settled, routed to the final step", st, _is_write(st), "done"
    # (3) status token overlap with a step
    if status:
        st_toks = _toks(status)
        scored = sorted(((len(st_toks & _toks(st)), st) for st in steps), reverse=True)
        if scored and scored[0][0] > 0:
            st = scored[0][1]
            return st, "record status %r matched this workflow step" % status, st, _is_write(st), \
                ("queued" if _is_write(st) else "in_stage")
    # (4) fallback — first actionable step
    st = writes[0] if writes else (steps[0] if steps else "step")
    why = ("status %r matched no step — entered at the first actionable step (map it for precise routing)" % status
           if status else "no status field detected — entered at the first actionable step")
    return st, why, st, _is_write(st), ("queued" if _is_write(st) else "in_stage")


def run_spec(spec, rows, stamp="", stage_map=None):
    """Run the data through THE RAILCALL-BUILT WORKFLOW — its steps ARE the pipeline. Generic over records.
    An optional stage_map (runtime arg merged OVER spec['stage_map']) maps the data's status vocabulary to
    steps so cross-source data routes intelligently instead of falling to the first step. The effective map is
    recorded INTO the receipt and sha-pinned, so the routing is auditable + reproducible."""
    steps = [s.get("label", "") for s in spec.get("steps", [])]
    spec_map = _norm_map(spec.get("stage_map"))
    run_map = _norm_map(stage_map)
    effective = dict(spec_map)
    effective.update(run_map)
    map_source = "runtime" if run_map else ("spec" if spec_map else None)
    flow_id = "flow/" + (spec.get("name") or "workflow")
    records, per_step, queued, approval_req, blocked, actionable, mapped, terminal = [], {}, 0, 0, 0, 0.0, 0, 0
    for i, r in enumerate(rows):
        stage, reason, action, is_write, status = route(r, steps, effective or None)
        if reason.startswith("stage_map:"):
            mapped += 1
        amt = _amount_of(r)
        name = str(_field(r, NAME_FIELDS) or "").strip()
        rid = "r%03d" % (i + 1)
        records.append({"record_id": rid, "name": name or rid, "amount": amt,
                        "current_stage": stage, "routing_reason": reason, "next_action": action,
                        "approval_required": is_write, "status": status,
                        "receipt_ref": flow_id + "#" + rid})
        per_step[stage] = per_step.get(stage, 0) + 1
        if status == "queued":
            queued += 1
            actionable += amt or 0
        if status == "terminal_stage":
            terminal += 1
        if is_write:
            approval_req += 1
    receipt = {
        "schema": "railcall_flow_receipt.v0",
        "workflow": spec.get("name"), "title": spec.get("title"),
        "ran_the_workflow_railcall_built": True,
        "workflow_steps": steps,
        "at": stamp, "records_processed": len(records),
        "stage_counts": per_step,
        "actions_queued": queued, "approval_required": approval_req, "blocked": blocked,
        "terminal_records": terminal,
        "stage_map_source": map_source, "stage_map_routed": mapped, "stage_map": effective,
        "actionable_amount": round(actionable, 2), "external_api_touched": False,
        "note": ("ran the RailCall-built workflow ON the data — each record routed to one of the workflow's OWN "
                 "steps; write actions are QUEUED for the Approval Airlock, nothing auto-fired."),
    }
    receipt["integrity"] = "sha256:" + hashlib.sha256(
        json.dumps({k: v for k, v in receipt.items() if k != "integrity"}, sort_keys=True, default=str).encode()).hexdigest()
    return {"records": records, "receipt": receipt, "flow_id": flow_id}


def distinct_statuses(rows):
    """The distinct status/stage values present in the data — for building a stage_map."""
    seen = []
    for r in rows:
        s = str(_status_field(r) or "").strip()
        if s and s not in seen:
            seen.append(s)
    return seen


def propose_stage_map(rows, steps):
    """Deterministic best-guess map: each distinct data status -> the step with the most token overlap
    (or null when there's no overlap, so the human can map or mark it terminal). No model in the loop."""
    out = {}
    for s in distinct_statuses(rows):
        st = _resolve_step(s, steps)
        out[s] = st  # may be None -> the UI shows it as unmapped for the human to decide
    return out


# ---- batch follow-up drafts (DRY-RUN: compose N, send 0) ----
DEFAULT_SUBJECT = "Following up on your account"
DEFAULT_BODY = ("Hi {name},\n\nOur records show an outstanding balance of {amount}. When you have a moment, "
                "could you let us know the expected payment date so we can update our files?\n\nThank you,\n"
                "Accounts Receivable")
EMAIL_KW = ("email", "e_mail", "mail")


def _recipient(row, name):
    e = _field_kw(row, EMAIL_KW)
    if e and "@" in str(e):
        return str(e).strip()
    slug = re.sub(r"[^a-z0-9]+", "", (name or "account").lower()) or "account"
    return "billing@%s.example" % slug


def _fill(tmpl, rec):
    if not tmpl:
        return ""
    amt = rec.get("amount")
    money = ("$" + format(int(amt), ",")) if isinstance(amt, (int, float)) else "your balance"
    out = str(tmpl)
    for k, v in {"{name}": rec.get("name") or "there", "{amount}": money, "{balance}": money,
                 "{stage}": rec.get("current_stage") or "", "{next_action}": rec.get("next_action") or ""}.items():
        out = out.replace(k, str(v))
    return out


def draft_batch(spec, rows, template=None, stage_map=None):
    """Compose a DRY-RUN batch of follow-up drafts: one per QUEUED (write) record, recipient pulled from the
    record, subject/body filled from the workflow's email_template (or a default). Composes only — NO send."""
    steps = [s.get("label", "") for s in spec.get("steps", [])]
    eff = dict(_norm_map(spec.get("stage_map")))
    eff.update(_norm_map(stage_map))
    tmpl = template or spec.get("email_template") or {}
    subj_t = tmpl.get("subject") or DEFAULT_SUBJECT
    body_t = tmpl.get("body") or DEFAULT_BODY
    drafts = []
    skipped = 0
    for i, r in enumerate(rows):
        stage, reason, action, is_write, status = route(r, steps, eff or None)
        if not is_write:                       # settled / no-action records get no follow-up draft
            skipped += 1
            continue
        name = str(_field(r, NAME_FIELDS) or "").strip() or ("r%03d" % (i + 1))
        amt = _amount_of(r)
        rec = {"record_id": "r%03d" % (i + 1), "name": name, "amount": amt,
               "current_stage": stage, "next_action": action}
        drafts.append({"record_id": rec["record_id"], "name": name, "to": _recipient(r, name),
                       "subject": _fill(subj_t, rec), "body": _fill(body_t, rec),
                       "amount": amt, "sent": False, "dry_run": True})
    return drafts, {"subject": subj_t, "body": body_t}, skipped


def batch_manifest(spec, rows, sender, template=None, stage_map=None):
    """The human-approvable summary of a batch: count, total, from, templates, and a batch_hash over the EXACT
    drafted to/subject/body of every record — so approving the manifest binds the actual composed content."""
    drafts, tmpl, skipped = draft_batch(spec, rows, template, stage_map)
    total = round(sum(d["amount"] or 0 for d in drafts), 2)
    cover = [{"to": d["to"], "subject": d["subject"], "body": d["body"]} for d in drafts]
    batch_hash = "sha256:" + hashlib.sha256(json.dumps(cover, sort_keys=True).encode()).hexdigest()
    manifest = {"count": len(drafts), "skipped": skipped, "total_amount": total, "from": sender,
                "subject_template": tmpl["subject"], "body_template": tmpl["body"],
                "batch_hash": batch_hash, "dry_run": True}
    return manifest, drafts


def rows_from_csv(text):
    return [dict(r) for r in csv.DictReader(io.StringIO(text))]
