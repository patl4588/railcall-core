# RailCall Studio — Constitution (as-built)

**Status:** describes the system EXACTLY as it runs at commit `52d233a5a9` on `workbench-engine-v0`, 2026-06-20.
**Scope rule:** this document contains only as-built mechanics. No roadmap, no theoretical features, nothing invented.
If a behavior is not in the code, it is not in this Constitution. Every clause cites the file/function that enforces it.

---

## Article 0 — Cross-cutting immutable laws

These hold across every surface and may not be weakened by any feature.

0.1 **Loopback only.** The server binds `127.0.0.1` (`studio_server.py: HOST`). No LAN/public bind without an explicit, deliberate exception.
0.2 **BYOK, local, 0600.** Provider keys live in `.railcall_workspace/keys.local.json`, written by `save_secret()` with file mode `600` and the dir `700`. The vault is gitignored and is **never transmitted** anywhere. The UI shows keys only as `••••••` (`redact()` masks any field whose name matches `SECRET_HINT`).
0.3 **The inference provider is never surfaced.** The assistant identifies only as "RailCall's own assistant" (`system_prompt()`). No UI element names Groq/OpenAI/Anthropic/etc. Allowed wording is "RailCall's assistant / BYOK / local"; naming the model is forbidden.
0.4 **No mutation without a human approval bound to the exact payload.** Enforced in `execute_command()` — see Article II.
0.5 **DRY-RUN is the default and current-only mode for outbound writes.** No real send fires until a provider key is tested AND the dry-run default is explicitly removed. There is no real-send toggle in the build.
0.6 **Every build / flow / command / batch produces a receipt**, and every receipt's integrity is recomputable from scratch by the independent auditor (`audit_workflow.py`). Statuses are honest: `PASS` / `PARTIAL` / `UNKNOWN` / `not_configured` / `not_wired_yet` / `DRY-RUN` — never fake green.
0.7 **Only audited, permissive-licensed code is assembled.** Permissive set (`compose_engine.PERMISSIVE`): `MIT, ISC, Apache-2.0, BSD-2-Clause, BSD-3-Clause, 0BSD, Unlicense, CC0-1.0`. Nothing else is composable.

---

## Article I — The Builder

### I.1 Where components come from — the pre-coded, pre-audited treasury

The builder does not write code and does not fetch code on demand. It assembles from a **pre-coded library that was ripped from permissive open source and audited ahead of time.** The library is finite (it is the screened set, not "unlimited"). It is loaded by `compose_engine.treasury_index(root)` from, on disk:

- `library/ui/ui_component_index.json` — the audited **components** (each carries `component_name`, `license`, `version`, `smoke_test_result`, `role`). *As-built count: 29.*
- `library/ui/receipts/*.json` — per-component audit receipts supplying the `archive_sha256` (the version-pin / sha256 lock).
- `library/combo_candidates.json` — the audited **combos** (each carries `combo_id`, `intent`, `members_resolved` with member `name`/`license`/`version`). *As-built count: 20.*

`studio_server.catalog()` exposes exactly this set to the assistant and the compiler. Every piece is therefore **license-screened, version-pinned, sha256-locked, and smoke-tested before it can be used.**

### I.2 What happens when a user requests a workflow — the spec

1. The user describes the process in plain English. The assistant is grounded by `system_prompt()` on the audited catalog above and leads with the workflow OUTCOME, never with library names.
2. The user types `build`. `POST /api/build → compose_engine.compose_spec(messages, catalog, groq_raw)` asks the inference layer for a SINGLE strict-JSON object:
   `{"name", "title", "trigger", "steps":[{"label","piece"}], "stage_map":{}, "outputs":[]}`.
3. **Every `piece` MUST be an EXACT string from the allowed list (combos + components) or `null`.** Any invented/unknown name is forced to `null` and the step is flagged `unaudited` (`compose_spec`: `if p not in allow: p = None … "unaudited": p is None`). The model is never trusted to introduce a piece that isn't in the treasury.
4. `compile_spec(spec, root, builds, tests, stamp)` then, deterministically and with **zero sockets**:
   - resolves each piece against the treasury (`_piece_record`) and checks it is permissive (`_permissive`);
   - renders a self-contained visual artifact to `builds/<name>.html`;
   - computes `integrity_root = "sha256:" + sha256(json.dumps(spec, sort_keys=True) + html)`;
   - writes the **build receipt** `tests/workflow_<name>_receipt.json`, schema `railcall_workflow_receipt.v1`, containing the canonical `spec` (so the auditor can recompute the hash), `audited_pieces`, `unaudited_steps`, `license_clean`, `external_sockets: 0`, `integrity_root`, and `honest_status: "SPEC_VISUAL_RECEIPT"`.
5. **Result grading is earned, not assumed:** `result = PASS` only when every step has an audited, permissive piece; `PARTIAL` if some steps still need auditing; `UNAUDITED` if none resolved.
6. `spec.stage_map` and `spec.email_template`, when present, are normalized and carried INTO the spec, so they are covered by `integrity_root` (sha-pinned). They may also be persisted later via a governed write (Article II.4).

### I.3 The Builder's boundaries

- The builder **does not touch, transform, analyze, clean, compute on, or run the user's data.** It only arranges audited blocks into a spec + visual + receipt (`system_prompt()` CAPABILITY HONESTY block; canonical line: *"RailCall doesn't touch or transform your data — it builds workflows your team runs on it."*).
- The output is explicitly **not a running, deployed application** (`honest_status: SPEC_VISUAL_RECEIPT`, `honest_note` in `compile_spec`).
- A file dropped into the FILES panel is imported **locally only** (loopback) and shown as a row/column preview; it is never uploaded or transmitted.

---

## Article II — The Guardrails (the Execution Loop)

### II.1 Running a flow = route + QUEUE, never execute

`POST /api/flow/run → flow_engine.run_spec(spec, rows, stamp, stage_map)` runs the data through **the workflow's own steps** (`ran_the_workflow_railcall_built: true`). Each record is routed deterministically, with this fixed precedence (`flow_engine.route`):

1. explicit `stage_map` (data status word → a step, or `null` = terminal/no action),
2. a settled amount (`balance/owed/due` == 0) → the final step,
3. status token-overlap with a step,
4. otherwise the first actionable (write) step.

A step whose label contains a write verb (`WRITE_KW`: send, email, letter, post, create, update, notify, charge, …) marks the record `approval_required` and `status: "queued"`. **No write executes during a flow run.** The flow run writes a **flow receipt** (`railcall_flow_receipt.v0`) with `external_api_touched: false` and an `integrity` sha256, and emits per-record `record_id · name · amount · current_stage · routing_reason · next_action · approval_required · status · receipt_ref`.

### II.2 The Approval Airlock

A command's `mode` is authoritative from `command_registry.COMMANDS` (the model is never trusted). For `mode: write_requires_approval`:

1. **Preview** — `preview_command()` builds a deterministic airlock card: `command_id, provider, mode, risk, required_integration, expected_external_touch, payload (redacted), payload_hash, idempotency_key`, and writes a `pending_approval` receipt. Nothing executes.
2. **Chat is blocked while the card is open** — `airlockLock(true)` disables the terminal input (`#tbInput`) and send (`#tbSend`); the placeholder reads "⚠ approval pending." Re-enabled only on approve/reject.
3. **Payload binding (exact):**
   - `payload_hash = "sha256:" + sha256(command_id + "\n" + canonical(inputs))`
   - `idempotency_key = "idem_" + sha256(command_id + "|" + canonical(inputs))[:24]`
   - `canonical(inputs) = json.dumps(inputs, sort_keys=True, separators=(",",":"))` — so the hash is over the EXACT bytes that will execute, and the idempotency key prevents a duplicate fire of the same payload.
4. **Approve** — `approve_command(method="ui_click")` binds a human approval to that exact `payload_hash` (`bind_approval` → `approved_payload_hash`).
5. **Execute** — `execute_command()` runs the handler **only if** a pending approval exists whose `approved_payload_hash === payload_hash(command_id, inputs)`. If there is no approval, or the hash does not match, the result is `blocked_by_policy` and **nothing executes.** Every path (validation fail, blocked, executed, failed) writes a command receipt.

### II.3 The Semantic Firewall

Before a human ever sees an airlock card, `approval_airlock.validate(cmd, inputs)` rejects a malformed/hallucinated payload: required fields must be present; each field must match its declared type (`string` / `number` / `array` / `object`); **unknown fields are rejected**; null bytes and oversized values are rejected; and any `claimed` command_id/provider/mode that disagrees with the authoritative `commands.json` entry is rejected. A failure yields `validation_failed` / `failed_with_receipt` — it never becomes an approvable card.

### II.4 Single draft vs. batch draft

- **Single** (`email.send_followup`): one record → one payload (`to`, `subject`, `body`) → one airlock card → one approval → one command receipt.
- **Batch** (`email.send_batch`): the airlock card shows a **manifest** — `count`, `skipped` (settled/no-action records, e.g. paid balances, that get no draft), `total_amount`, `from`, `subject_template`, `body_template`, and a `batch_hash = sha256` over the EXACT `{to, subject, body}` of **every** draft. **The human approves the SET with one approval, not N cards.** Execution composes the drafts and writes **one batch receipt** (`railcall_batch_receipt.v1`) containing all drafts, `sent: 0`, `external_api_touched: false`, and an `integrity` sha256. Batch is **DRY-RUN only** (Article 0.5).
- Governed spec writes (`workflow.set_stage_map`, `workflow.set_email_template`) use the same airlock path and re-compile the build receipt so the saved map/template is sha-pinned into `integrity_root`.

### II.5 Receipts and the `external_api_touched` proof

There are four receipt schemas, each proving one thing:

| receipt | schema | proves |
|---|---|---|
| build | `railcall_workflow_receipt.v1` | the workflow was composed honestly from audited code (provenance, `external_sockets: 0`, `integrity_root`) |
| flow | `railcall_flow_receipt.v0` | data moved through that workflow (which records hit which steps, how many queued, `external_api_touched: false`) |
| command | `railcall_command_receipt.v1` | an approved write executed safely (approval bound to the exact payload; `integrity_hash` binds schema version + resolved command + payload hash + approval + pre/post-execution hashes + `external_api_touched` + artifact) |
| batch | `railcall_batch_receipt.v1` | N governed drafts were composed from the template and approved as a set (`batch_hash` over all drafts, `sent: 0`, `external_api_touched: false`) |

`external_api_touched` is a **fact about the process, not a claim.** `compile_spec` and `run_spec` open zero sockets. In `execute_command`, the field is set to `(provider != "railcall") AND NOT output.dry_run` — so it is `false` for any local action and for any DRY-RUN, and `true` only when a handler genuinely reaches an external API (e.g. `github.list_issues`). Every receipt's integrity is independently recomputable by `audit_workflow.py` (and live, per-receipt, via `POST /api/receipts/verify`), which is adversarially tested to catch forged approvals, tampered hashes, fabricated licenses, and fake-green statuses.

---

## Article III — Amendment

This Constitution changes only when the code changes. To amend: change the code, re-run the regression suite + the auditor (both must stay green), then update the cited clause here in the same commit. No clause may be amended by description alone.
