#!/usr/bin/env python3
"""
RailCall workflow AUDITOR — independent verifier for railcall_workflow_receipt.v1.

Deliberately re-reads the treasury and recomputes everything FROM SCRATCH (it does not import the
compose engine), so it's a genuine cross-check, not a rubber stamp. For every receipt it asserts:

  1. provenance   — every audited piece really exists in the treasury with the license it claims
                    (and, for components, the sha256 it claims matches the treasury's own receipt)
  2. no-invention — zero pieces that aren't in the treasury
  3. license_clean— recomputed from the pieces, must match what the receipt claims
  4. honest result— PASS only if every step has an audited piece AND license is clean; else PARTIAL
  5. sockets      — external_sockets must be 0
  6. honesty      — honest_status must be SPEC_VISUAL_RECEIPT (no "running app" overclaim)
  7. integrity    — sha256(spec + artifact html) recomputed, must match integrity_root
  8. artifact     — the built file actually exists

Exit 0 iff every receipt passes every check.
"""
import os
import sys
import json
import glob
import hashlib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import railcall_signing as _signing   # Ed25519 verify against the PINNED install pubkey (signing_pubkey.json)
except Exception:   # pragma: no cover - signing verify is additive; absence => every receipt is "unsigned"
    _signing = None

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PERMISSIVE = {"MIT", "ISC", "Apache-2.0", "BSD-2-Clause", "BSD-3-Clause", "0BSD", "Unlicense", "CC0-1.0"}
G, R, Y, X = "\033[32m", "\033[31m", "\033[33m", "\033[0m"


def load(p, d):
    try:
        with open(p) as f:
            return json.load(f)
    except Exception:
        return d


def norm(n):
    return str(n).replace("@", "").replace("/", "__").lower()


def load_treasury():
    comps, combos, sha = {}, {}, {}
    ci = load(os.path.join(ROOT, "library", "ui", "ui_component_index.json"), {})
    for c in ci.get("components", []):
        if c.get("component_name"):
            comps[c["component_name"]] = {"license": c.get("license"), "smoke": c.get("smoke_test_result")}
    rdir = os.path.join(ROOT, "library", "ui", "receipts")
    if os.path.isdir(rdir):
        for f in os.listdir(rdir):
            r = load(os.path.join(rdir, f), {})
            if r.get("component_name") and r.get("archive_sha256"):
                sha[norm(r["component_name"])] = r["archive_sha256"]
    cc = load(os.path.join(ROOT, "library", "combo_candidates.json"), {})
    for c in cc.get("combos", []):
        if c.get("combo_id"):
            combos[c["combo_id"]] = {m.get("name"): m.get("license")
                                     for m in c.get("members_resolved", []) if m.get("name")}
    return comps, combos, sha


def _signature_check(rcpt, integrity_value, chk):
    """Ed25519 signature verification, layered ON TOP of the existing sha256 integrity check.

    Verifies the receipt's "signature" block AGAINST THE PINNED INSTALL PUBLIC KEY (loaded from the
    published signing_pubkey.json) — NOT any pubkey carried in the receipt (that would be trivially
    forgeable). Honest three-way distinction (NO FAKE GREEN):
      - no signature block            -> UNSIGNED. Legacy/honest. The granular check is reported as a
                                         non-failing INFO ("unsigned (no signature)") so the 1422 legacy
                                         receipts keep passing. It is NOT reported as signed-and-verified.
      - signature verifies vs install -> the granular check PASSES ("signature verifies against the
                                         install public key").
      - signature present but invalid -> hard FAIL (forged / tampered / wrong key).
    Sets rcpt-independent state via chk(). Returns the verdict string for callers that want it."""
    sig_block = rcpt.get("signature")
    if _signing is None:
        # the verifier can't load the signing layer at all -> treat as unsigned (never bless as verified).
        if sig_block:
            chk("signature verifies against the install public key", False,
                "signing layer unavailable to verify a present signature")
            return "signature_fail"
        chk("signature: unsigned (no signature) — legacy receipt, honestly not signed-and-verified", True,
            "INFO: unsigned")
        return "unsigned"
    verdict = _signing.verify_against_install(integrity_value, sig_block)
    if verdict == _signing.SIG_UNSIGNED:
        # honest: legacy/unsigned. NON-failing info check (must NOT fail the audit).
        chk("signature: unsigned (no signature) — legacy receipt, honestly not signed-and-verified", True,
            "INFO: unsigned")
    elif verdict == _signing.SIG_VERIFIED:
        chk("signature verifies against the install public key", True,
            "key_id=%s" % (sig_block.get("key_id") if isinstance(sig_block, dict) else "?"))
    else:   # SIG_FAIL
        chk("signature verifies against the install public key", False,
            "signature present but does NOT verify against the pinned install pubkey (forged/tampered/wrong-key)")
    return verdict


def audit_receipt(rcpt, comps, combos, sha, receipt_dir=None, standalone=False):
    checks = []   # (name, ok, detail)

    def chk(name, ok, detail=""):
        checks.append((name, bool(ok), detail))

    pieces = rcpt.get("audited_pieces", [])
    steps = rcpt.get("nodes", [])

    # ROBUSTNESS / fail-safe (not fail-loud): `nodes` and `audited_pieces` come from an untrusted receipt
    # body. A non-list value must surface as an HONEST FAIL on this receipt, never crash the whole CLI run
    # (one malformed runtime receipt would otherwise abort the audit of every other receipt — a gate DoS).
    if not isinstance(steps, list):
        chk("nodes is a list", False, "got %s" % type(steps).__name__)
        steps = []
    if not isinstance(pieces, list):
        chk("audited_pieces is a list", False, "got %s" % type(pieces).__name__)
        pieces = []

    if standalone:
        # standalone sample mode: no treasury present, so provenance (license/sha) is honestly NOT verified.
        # We still fully verify the receipt's internal integrity (spec <-> local artifact) and structure,
        # AND catch an internal fake-green (a PASS the receipt's own fields contradict) — no treasury needed.
        chk("provenance (treasury license/sha) — SKIPPED: standalone sample mode, no treasury present", True)
        _audit_standalone_honesty(rcpt, steps, chk)
    else:
        _audit_provenance(rcpt, pieces, steps, comps, combos, sha, chk)

    # 5: sockets (always) — the top-level claim AND the parallel nested claim must both be 0 and agree,
    # so a forged receipt can't say external_sockets:0 while network.sockets_opened_during_execution is non-0
    chk("external_sockets == 0", rcpt.get("external_sockets") == 0, "got %r" % rcpt.get("external_sockets"))
    _net = rcpt.get("network")
    if _net is None:
        _net = {}
    if not isinstance(_net, dict):
        # a present-but-non-dict `network` must FAIL, not silently skip: otherwise a forged receipt could
        # stash a real (non-zero) socket count under a non-dict `network` to disarm the cross-check below.
        chk("network is a dict (so the nested-socket cross-check can run)", False,
            "got %s" % type(_net).__name__)
    elif "sockets_opened_during_execution" in _net:
        _nv = _net.get("sockets_opened_during_execution")
        chk("network.sockets_opened_during_execution == 0 (agrees with external_sockets)",
            _nv == 0 and _nv == rcpt.get("external_sockets"),
            "nested=%r top=%r" % (_nv, rcpt.get("external_sockets")))
    # 6: no overclaim (always)
    chk("honest_status = SPEC_VISUAL_RECEIPT", rcpt.get("honest_status") == "SPEC_VISUAL_RECEIPT")
    # 7: integrity recompute (always) — find the artifact next to the receipt OR in builds/.
    # SECURITY: `art` comes from an untrusted receipt body. Contain every candidate to its intended
    # base dir (realpath must stay inside builds/ or the given receipt_dir) so a crafted artifact like
    # "/etc/passwd" or "../../secret" can never make the auditor open a file outside those dirs
    # (path-traversal / arbitrary-file existence+content oracle).
    spec, art = rcpt.get("spec"), rcpt.get("artifact")

    def _contained(base, name):
        # join base+name, resolve, and only accept if it stays within base (rejects abs paths + ../ escapes)
        try:
            base_r = os.path.realpath(base)
            full_r = os.path.realpath(os.path.join(base, name))
            if full_r == base_r or full_r.startswith(base_r + os.sep):
                return full_r
        except Exception:
            pass
        return None

    artp = None
    if art:
        bases = ([receipt_dir] if receipt_dir else []) + [os.path.join(ROOT, "builds")]
        for base in bases:
            cand = _contained(base, art)
            if cand and os.path.isfile(cand):
                artp = cand
                break
    if spec and artp:
        html = open(artp).read()
        got = "sha256:" + hashlib.sha256((json.dumps(spec, sort_keys=True) + html).encode()).hexdigest()
        chk("integrity_root recomputes from spec + local artifact", got == rcpt.get("integrity_root"),
            "" if got == rcpt.get("integrity_root") else "MISMATCH")
        chk("artifact file present", True)
    else:
        chk("integrity_root recomputes from spec + local artifact", False, "missing spec or artifact")
        chk("artifact file present", bool(artp), str(art))
    # 9: Ed25519 signature (additive) — verified against the PINNED install pubkey over integrity_root.
    _signature_check(rcpt, rcpt.get("integrity_root"), chk)
    return checks


def _audit_provenance(rcpt, pieces, steps, comps, combos, sha, chk):
    invented, lic_ok, sha_ok = [], True, True
    recomputed_clean = bool(pieces)
    for p in pieces:
        nm = p.get("name", "")
        if nm.startswith("combo:"):
            real = combos.get(nm)   # {member_name: license}
            if real is None:
                invented.append(nm)
                recomputed_clean = False
                continue
            real_lic = sorted(set(real.values()))
            if not (real and all(l in PERMISSIVE for l in real.values())):
                recomputed_clean = False
            # claimed combo license string + member_licenses must match the treasury (catch fabrication)
            if p.get("license") and p["license"] != "+".join(real_lic):
                lic_ok = False
            if p.get("member_licenses") and sorted(set(p["member_licenses"])) != real_lic:
                lic_ok = False
            # no invented members
            if p.get("members") and (set(p["members"]) - set(real.keys())):
                lic_ok = False
        else:
            real = comps.get(nm)
            if real is None:
                invented.append(nm)
                recomputed_clean = False
                continue
            if p.get("license") != real.get("license"):
                lic_ok = False
            if real.get("license") not in PERMISSIVE:
                recomputed_clean = False
            want = sha.get(norm(nm)) or sha.get(norm(nm.split("/")[-1]))
            if p.get("sha256") and want and p["sha256"] != want:
                sha_ok = False
    chk("provenance: pieces exist in treasury", not invented,
        "" if not invented else "MISSING " + ", ".join(invented))
    chk("provenance: claimed licenses match treasury", lic_ok)
    chk("provenance: component sha256 match treasury", sha_ok)

    # 3: license_clean recomputed
    chk("license_clean recomputed matches receipt", recomputed_clean == bool(rcpt.get("license_clean")),
        "receipt=%s recomputed=%s" % (rcpt.get("license_clean"), recomputed_clean))

    # 4: honest result (PASS only if every step audited + clean).
    # FAKE-GREEN GUARD: a workflow with NO steps did no auditable work, so it can never be PARTIAL just
    # because it carries some `audited_pieces` — without steps it is UNAUDITED. (Pre-fix, a step-less
    # receipt that merely listed pieces graded PARTIAL and the 'no fake green' check passed.)
    has_steps = bool(steps)
    every_step_audited = has_steps and all(isinstance(s, dict) and s.get("piece") for s in steps)
    expect = ("PASS" if (every_step_audited and recomputed_clean)
              else ("PARTIAL" if (has_steps and pieces) else "UNAUDITED"))
    chk("workflow declares at least one step", has_steps, "nodes empty/absent")
    chk("result is honest (no fake green)", rcpt.get("result") == expect,
        "receipt=%s expected=%s" % (rcpt.get("result"), expect))


def _audit_standalone_honesty(rcpt, steps, chk):
    """No-treasury honesty: provenance (does this piece really exist / is its license clean) is
    unverifiable without the treasury, but a PASS claim must still be internally consistent with the
    receipt's OWN fields — every node audited, zero unaudited_steps, license_clean asserted. This catches
    a shipped sample that overclaims PASS (the mode the distributed package actually runs in)."""
    result = rcpt.get("result")
    unaudited = rcpt.get("unaudited_steps") or []
    has_steps = bool(steps)
    every_step_audited = has_steps and all(isinstance(s, dict) and s.get("piece") for s in steps)
    # FAKE-GREEN GUARD (mirrors _audit_provenance): a step-less receipt did no auditable work, so any
    # non-UNAUDITED grade (PASS *or* PARTIAL) is dishonest even in standalone mode where provenance is
    # unverifiable. Without this, a no-nodes PARTIAL that merely carries audited_pieces passed the gate.
    chk("workflow declares at least one step", has_steps, "nodes empty/absent")
    ok, detail = True, ""
    if result in ("PASS", "PARTIAL") and not has_steps:
        ok = False
        detail = "result=%s but the workflow declares zero steps (no auditable work)" % result
    elif result == "PASS":
        ok = every_step_audited and not unaudited and bool(rcpt.get("license_clean"))
        if not ok:
            detail = "result=PASS but every_step_audited=%s unaudited_steps=%d license_clean=%r" % (
                every_step_audited, len(unaudited), rcpt.get("license_clean"))
    chk("result is internally honest (no fake green: PASS requires every step audited, "
        "no unaudited_steps, license_clean)", ok, detail)


WRITE_MODES = ("write_requires_approval", "write_blocked")
CMD_STATUSES = {"executed", "approved_not_executed", "pending_approval", "blocked_by_policy",
                "not_wired_yet", "not_configured", "failed_with_receipt", "failed_safely"}


def _cmd_integrity(body):
    # MUST mirror approval_airlock._integrity EXACTLY (same field tuple). mode/provider/risk are covered
    # so a write receipt tampered down to mode='read' fails this recompute instead of dodging the guard.
    # `output` is covered too so flipping output.sent false->true (the send-truth the UI card reads off a
    # batch/send command receipt) BREAKS this recompute instead of still verifying PASS.
    cover = {k: body.get(k) for k in ("command_schema_version", "resolved_command_id", "payload_hash",
                                      "approval", "pre_execution_hash", "post_execution_result_hash",
                                      "result_status", "external_api_touched", "artifact_path",
                                      "mode", "provider", "risk", "approval_requirement",
                                      "required_integration", "output")}
    return "sha256:" + hashlib.sha256(json.dumps(cover, sort_keys=True, default=str).encode()).hexdigest()


def audit_command_receipt(rcpt):
    checks = []

    def chk(name, ok, detail=""):
        checks.append((name, bool(ok), detail))

    chk("integrity_hash recomputes", _cmd_integrity(rcpt) == rcpt.get("integrity_hash"))
    chk("result_status is a known status", rcpt.get("result_status") in CMD_STATUSES, "got %r" % rcpt.get("result_status"))
    ap, ph = rcpt.get("approval"), rcpt.get("payload_hash")
    if ap:   # an approval, if present, must bind to THIS payload — catches a tampered/forged approval
        chk("approval binds to this exact payload", ap.get("approved_payload_hash") == ph,
            "approval=%s != payload=%s" % (str(ap.get("approved_payload_hash"))[:20], str(ph)[:20]))
        chk("approval method is explicit", ap.get("method") in ("ui_click", "terminal_confirm"))
    if rcpt.get("result_status") == "executed" and rcpt.get("mode") in WRITE_MODES:
        chk("executed write carries an approval bound to the executed payload",
            bool(ap) and ap.get("approved_payload_hash") == ph, "no approval bound to the executed payload")
    if rcpt.get("provider") == "railcall":
        chk("local command did not touch an external API", rcpt.get("external_api_touched") is False)
    # Ed25519 signature (additive) — verified against the PINNED install pubkey over integrity_hash.
    _signature_check(rcpt, rcpt.get("integrity_hash"), chk)
    return checks


def _flow_integrity(body):
    # EXCLUDE both `integrity` (self) and `signature` (additive, layered on top — NOT inside the sha256
    # cover). The generator computes integrity BEFORE attaching signature, so the recompute must drop
    # signature too or every freshly-signed flow/batch receipt would false-fail this check.
    return "sha256:" + hashlib.sha256(
        json.dumps({k: v for k, v in body.items() if k not in ("integrity", "signature")},
                   sort_keys=True, default=str).encode()).hexdigest()


def audit_flow_receipt(rcpt):
    checks = []

    def chk(name, ok, detail=""):
        checks.append((name, bool(ok), detail))

    chk("integrity recomputes", _flow_integrity(rcpt) == rcpt.get("integrity"))
    chk("ran the RailCall-built workflow", rcpt.get("ran_the_workflow_railcall_built") is True)
    chk("references a workflow + its steps", bool(rcpt.get("workflow")) and bool(rcpt.get("workflow_steps")))
    chk("no external API fired (v0 — writes only queued)", rcpt.get("external_api_touched") is False)
    _signature_check(rcpt, rcpt.get("integrity"), chk)
    return checks


def audit_batch_receipt(rcpt):
    checks = []

    def chk(name, ok, detail=""):
        checks.append((name, bool(ok), detail))

    drafts = rcpt.get("drafts") or []
    cover = [{"to": d.get("to"), "subject": d.get("subject"), "body": d.get("body")} for d in drafts]
    recomputed_hash = "sha256:" + hashlib.sha256(json.dumps(cover, sort_keys=True).encode()).hexdigest()
    chk("integrity recomputes", _flow_integrity(rcpt) == rcpt.get("integrity"))
    chk("count matches the drafts", rcpt.get("count") == len(drafts))
    chk("batch_hash covers the EXACT drafted content", rcpt.get("batch_hash") == recomputed_hash)
    chk("DRY-RUN — nothing transmitted", rcpt.get("sent") == 0 and rcpt.get("external_api_touched") is False
        and all(d.get("sent") is False for d in drafts))
    _signature_check(rcpt, rcpt.get("integrity"), chk)
    return checks


def audit_ui_receipt(rcpt, comps, combos, sha, standalone=False):
    """Verify a railcall_ui_receipt.v0: integrity recomputes, every component is an audited treasury
    piece with a matching license, non-treasury picks are flagged, key_id is a NAME not a secret."""
    chks = []
    def chk(n, ok, d=""): chks.append((n, bool(ok), d))
    claimed = rcpt.get("integrity_root", "")
    # EXCLUDE both `integrity_root` (self) and `signature` (additive) from the sha256 recompute.
    body = {k: v for k, v in rcpt.items() if k not in ("integrity_root", "signature")}
    recomputed = "sha256:" + hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()
    chk("integrity_root recomputes", claimed == recomputed,
        "claimed=%s recomputed=%s" % (str(claimed)[:18], recomputed[:18]))
    _signature_check(rcpt, claimed, chk)
    comp_list = rcpt.get("components", []) or []
    if not standalone and (comps or combos):
        unknown = [c.get("id") for c in comp_list if c.get("id") not in comps and c.get("id") not in combos]
        chk("every component is an audited treasury piece", not unknown, "unknown=%s" % unknown)
        mism = [c.get("id") for c in comp_list
                if c.get("id") in comps and c.get("license") != comps[c["id"]].get("license")]
        chk("component licenses match the treasury", not mism, "mismatched=%s" % mism)
    chk("non-treasury picks flagged as candidates (bounded)", isinstance(rcpt.get("treasury_candidates"), list))
    kid = str(rcpt.get("key_id", ""))
    chk("key_id is a provider name, not a secret", 0 < len(kid) < 24 and " " not in kid, "key_id=%r" % kid)
    return chks


def _safe_audit(fn, *a, **kw):
    """Run one receipt's auditor; convert ANY unexpected exception into an honest FAIL check instead of
    letting it abort the whole run. A single malformed (e.g. machine-generated) receipt must not be able
    to brick the audit of every other receipt — a gate DoS. This NEVER turns a fail into a fake-green:
    an exception always yields a failing check, so the receipt FAILS loud-and-contained."""
    try:
        return fn(*a, **kw)
    except Exception as e:
        return [("auditor ran without error", False, "%s: %s" % (type(e).__name__, str(e)[:120]))]


def main():
    args = sys.argv[1:]
    allow_empty = "--allow-empty" in args
    pos = [a for a in args if not a.startswith("--")]
    rdir = pos[0] if pos else os.path.join(ROOT, "tests")
    comps, combos, sha = load_treasury()
    standalone = not (comps or combos)   # no treasury present -> standalone sample mode (integrity only)
    receipts = []
    for p in sorted(glob.glob(os.path.join(rdir, "*receipt*.json"))):
        d = load(p, {})
        if d.get("schema") == "railcall_workflow_receipt.v1":
            receipts.append((os.path.basename(p), d, os.path.dirname(p)))
    # command receipts: scan the given dir (e.g. sample_receipt) AND the live workspace
    cmd_receipts, seen = [], set()
    for cd in [rdir, os.path.join(ROOT, ".railcall_workspace", "receipts")]:
        if os.path.isdir(cd):
            for p in sorted(glob.glob(os.path.join(cd, "*.json"))):
                d = load(p, {})
                if d.get("schema") == "railcall_command_receipt.v1" and os.path.basename(p) not in seen:
                    seen.add(os.path.basename(p))
                    cmd_receipts.append((os.path.basename(p), d))
    flow_receipts, fseen = [], set()
    for cd in [rdir, os.path.join(ROOT, ".railcall_workspace", "flow_receipts")]:
        if os.path.isdir(cd):
            for p in sorted(glob.glob(os.path.join(cd, "*.json"))):
                d = load(p, {})
                if d.get("schema") == "railcall_flow_receipt.v0" and os.path.basename(p) not in fseen:
                    fseen.add(os.path.basename(p))
                    flow_receipts.append((os.path.basename(p), d))
    batch_receipts, bseen = [], set()
    for cd in [rdir, os.path.join(ROOT, ".railcall_workspace", "batch_receipts")]:
        if os.path.isdir(cd):
            for p in sorted(glob.glob(os.path.join(cd, "*.json"))):
                d = load(p, {})
                if d.get("schema") == "railcall_batch_receipt.v1" and os.path.basename(p) not in bseen:
                    bseen.add(os.path.basename(p))
                    batch_receipts.append((os.path.basename(p), d))
    ui_receipts, useen = [], set()
    for cd in [rdir, os.path.join(ROOT, ".railcall_workspace")]:
        if os.path.isdir(cd):
            for p in sorted(glob.glob(os.path.join(cd, "*receipt*.json"))):
                d = load(p, {})
                if d.get("schema") == "railcall_ui_receipt.v0" and os.path.basename(p) not in useen:
                    useen.add(os.path.basename(p))
                    ui_receipts.append((os.path.basename(p), d))

    mode = ("STANDALONE SAMPLE MODE — no treasury; integrity + structure verified, provenance not claimed"
            if standalone else "treasury: %d components, %d combos" % (len(comps), len(combos)))
    print("RailCall auditor — %s · %d workflow + %d command + %d flow + %d batch + %d ui receipts\n"
          % (mode, len(receipts), len(cmd_receipts), len(flow_receipts), len(batch_receipts), len(ui_receipts)))
    if not receipts and not cmd_receipts and not flow_receipts and not batch_receipts and not ui_receipts:
        if allow_empty:
            print(Y + "no receipts found — passing only because --allow-empty was set" + X)
            return 0
        print(R + "AUDIT FAIL — zero railcall_workflow_receipt.v1 receipts in " + rdir +
              " (pass --allow-empty to permit an empty set on purpose)" + X)
        return 1

    all_ok = True
    for fname, rcpt, rdir_of in receipts:
        checks = _safe_audit(audit_receipt, rcpt, comps, combos, sha, receipt_dir=rdir_of, standalone=standalone)
        wf_ok = all(ok for _, ok, _ in checks)
        all_ok = all_ok and wf_ok
        head = (G + "PASS" + X) if wf_ok else (R + "FAIL" + X)
        print("%s  %s  (%s, result=%s)" % (head, rcpt.get("workflow_id"), fname, rcpt.get("result")))
        for name, ok, detail in checks:
            mark = G + "  ✓" + X if ok else R + "  ✗" + X
            print("   %s %s%s" % (mark, name, ("  — " + detail) if (detail and not ok) else ""))
        print()

    for fname, rcpt in cmd_receipts:
        checks = _safe_audit(audit_command_receipt, rcpt)
        ok = all(o for _, o, _ in checks)
        all_ok = all_ok and ok
        head = (G + "PASS" + X) if ok else (R + "FAIL" + X)
        print("%s  cmd %s  (%s, %s)" % (head, rcpt.get("resolved_command_id"), fname, rcpt.get("result_status")))
        for name, o, detail in checks:
            mark = G + "  ✓" + X if o else R + "  ✗" + X
            print("   %s %s%s" % (mark, name, ("  — " + detail) if (detail and not o) else ""))
        print()

    for fname, rcpt in flow_receipts:
        checks = _safe_audit(audit_flow_receipt, rcpt)
        ok = all(o for _, o, _ in checks)
        all_ok = all_ok and ok
        head = (G + "PASS" + X) if ok else (R + "FAIL" + X)
        print("%s  flow %s  (%s, %s records)" % (head, rcpt.get("workflow"), fname, rcpt.get("records_processed")))
        for name, o, detail in checks:
            mark = G + "  ✓" + X if o else R + "  ✗" + X
            print("   %s %s%s" % (mark, name, ("  — " + detail) if (detail and not o) else ""))
        print()

    for fname, rcpt in batch_receipts:
        checks = _safe_audit(audit_batch_receipt, rcpt)
        ok = all(o for _, o, _ in checks)
        all_ok = all_ok and ok
        head = (G + "PASS" + X) if ok else (R + "FAIL" + X)
        print("%s  batch %s  (%s, %s drafts · DRY-RUN)" % (head, rcpt.get("workflow"), fname, rcpt.get("count")))
        for name, o, detail in checks:
            mark = G + "  ✓" + X if o else R + "  ✗" + X
            print("   %s %s%s" % (mark, name, ("  — " + detail) if (detail and not o) else ""))
        print()

    for fname, rcpt in ui_receipts:
        checks = _safe_audit(audit_ui_receipt, rcpt, comps, combos, sha, standalone)
        ok = all(o for _, o, _ in checks)
        all_ok = all_ok and ok
        head = (G + "PASS" + X) if ok else (R + "FAIL" + X)
        print("%s  ui  %s  (%s, result=%s)" % (head, rcpt.get("ui_id"), fname, rcpt.get("result")))
        for name, o, detail in checks:
            mark = G + "  ✓" + X if o else R + "  ✗" + X
            print("   %s %s%s" % (mark, name, ("  — " + detail) if (detail and not o) else ""))
        print()

    print(("=" * 48) + "\n" + ((G + "AUDIT PASS — every receipt verified" + X) if all_ok
          else (R + "AUDIT FAIL — see ✗ above" + X)))
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
