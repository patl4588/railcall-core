#!/usr/bin/env python3
"""
RailCall Org API Command Registry v0 — the typed catalog of workplace commands + the governance that
resolves EVERY command to exactly ONE honest status. No vague success, no fake green, no hidden writes.

The 6 terminal statuses (the hard rule — every action is exactly one of these):
  available_read_only                 wired + configured + read-only            -> safe to run now
  available_write_requires_approval   wired + configured + mutating             -> needs the human Approval Airlock
  not_configured                      wired, but required secrets are missing
  not_wired_yet                       declared but not implemented (honest stub, visible in UI + receipts)
  blocked_by_policy                   refused by policy (e.g. a write attempted before the Airlock exists)
  failed_with_receipt                 attempted and failed (validation/runtime) — still leaves a receipt

v0 EXECUTION POLICY: only `available_read_only` LOCAL commands actually run. Every external/mutating
command resolves to a gated status and touches NO external API — it only writes a receipt.
"""
import hashlib
import json

# mode: read | write_requires_approval | write_blocked | not_wired_yet
COMMANDS = [
    {"id": "workflow.build", "title": "Build a workflow from the conversation", "provider": "railcall",
     "risk": "low", "mode": "read", "wired": True, "requires": [], "preview": True, "receipt_required": True,
     "input_schema": {"messages": {"type": "array", "required": True}},
     "output_schema": {"workflow": "string", "result": "string", "artifact": "string"}},
    {"id": "workflow.audit", "title": "Re-verify receipts with the independent auditor", "provider": "railcall",
     "risk": "low", "mode": "read", "wired": True, "requires": [], "preview": True, "receipt_required": True,
     "input_schema": {}, "output_schema": {"result": "string"}},
    {"id": "receipts.list", "title": "List recent receipts", "provider": "railcall",
     "risk": "low", "mode": "read", "wired": True, "requires": [], "preview": True, "receipt_required": False,
     "input_schema": {}, "output_schema": {"receipts": "array"}},
    {"id": "workspace.set_session_status", "title": "Change a session's status (a governed LOCAL write)",
     "provider": "railcall", "risk": "low", "mode": "write_requires_approval", "wired": True, "requires": [],
     "preview": True, "receipt_required": True,
     "input_schema": {"session_id": {"type": "string", "required": True}, "status": {"type": "string", "required": True}},
     "output_schema": {"ok": "boolean"}},
    {"id": "workflow.set_stage_map", "title": "Save a stage map INTO a workflow (governed LOCAL write)",
     "provider": "railcall", "risk": "low", "mode": "write_requires_approval", "wired": True, "requires": [],
     "preview": True, "receipt_required": True,
     "input_schema": {"workflow": {"type": "string", "required": True}, "stage_map": {"type": "object", "required": True}},
     "output_schema": {"integrity_root": "string"}},
    {"id": "workflow.set_email_template", "title": "Save an email template INTO a workflow (governed LOCAL write)",
     "provider": "railcall", "risk": "low", "mode": "write_requires_approval", "wired": True, "requires": [],
     "preview": True, "receipt_required": True,
     "input_schema": {"workflow": {"type": "string", "required": True}, "email_template": {"type": "object", "required": True}},
     "output_schema": {"integrity_root": "string"}},
    {"id": "github.list_issues", "title": "List open GitHub issues", "provider": "github",
     "risk": "low", "mode": "read", "wired": True, "requires": ["GITHUB_TOKEN", "GITHUB_OWNER", "GITHUB_REPO"],
     "preview": True, "receipt_required": True,
     "input_schema": {"state": {"type": "string", "required": False}}, "output_schema": {"issues": "array"}},
    {"id": "github.create_issue", "title": "Open a GitHub issue from a failed audit", "provider": "github",
     "risk": "medium", "mode": "write_requires_approval", "wired": False,
     "requires": ["GITHUB_TOKEN", "GITHUB_OWNER", "GITHUB_REPO"], "preview": True, "receipt_required": True,
     "input_schema": {"title": {"type": "string", "required": True}, "body": {"type": "string", "required": True}},
     "output_schema": {"issue_url": "string"}},
    {"id": "slack.post_message", "title": "Post a build alert to Slack", "provider": "slack",
     "risk": "low", "mode": "write_requires_approval", "wired": False, "requires": ["SLACK_BOT_TOKEN"],
     "preview": True, "receipt_required": True,
     "input_schema": {"channel": {"type": "string", "required": True}, "text": {"type": "string", "required": True}},
     "output_schema": {"ts": "string"}},
    {"id": "stripe.read_balance", "title": "Read the Stripe balance (payment QA)", "provider": "stripe",
     "risk": "high", "mode": "read", "wired": False, "requires": ["STRIPE_SECRET_KEY"],
     "preview": True, "receipt_required": True, "input_schema": {}, "output_schema": {"available": "number"}},
    {"id": "notion.export_session", "title": "Export the session notes to Notion", "provider": "notion",
     "risk": "low", "mode": "write_requires_approval", "wired": False, "requires": ["NOTION_TOKEN"],
     "preview": True, "receipt_required": True,
     "input_schema": {"page_title": {"type": "string", "required": True}}, "output_schema": {"page_url": "string"}},
    {"id": "email.send_followup", "title": "Send a follow-up email to an account (governed write)", "provider": "email",
     "risk": "high", "mode": "write_requires_approval", "wired": True,
     "requires": ["SMTP_HOST", "SMTP_PORT", "SMTP_USER", "SMTP_PASS", "SMTP_FROM"],
     "preview": True, "receipt_required": True,
     "input_schema": {"to": {"type": "string", "required": True}, "subject": {"type": "string", "required": True},
                      "body": {"type": "string", "required": True}},
     "output_schema": {"sent": "boolean"}},
    {"id": "email.send_batch", "title": "Draft a batch of follow-ups for a workflow run (governed · DRY-RUN)",
     "provider": "email", "risk": "high", "mode": "write_requires_approval", "wired": True,
     "requires": ["SMTP_HOST", "SMTP_PORT", "SMTP_USER", "SMTP_PASS", "SMTP_FROM"],
     "preview": True, "receipt_required": True,
     "input_schema": {"workflow": {"type": "string", "required": True}, "data": {"type": "string", "required": True}},
     "output_schema": {"count": "number", "batch_receipt": "string"}},
]
CMD_BY_ID = {c["id"]: c for c in COMMANDS}

TERMINAL_STATUSES = {"available_read_only", "available_write_requires_approval", "not_configured",
                     "not_wired_yet", "blocked_by_policy", "failed_with_receipt"}
EXEC_CLASS = {
    "available_read_only": "read_only",
    "available_write_requires_approval": "write_approved",  # only reachable AFTER the Approval Airlock
    "blocked_by_policy": "blocked",
    "not_wired_yet": "not_wired",
    "not_configured": "not_configured",
    "failed_with_receipt": "failed",
}


def configured_providers(integrations):
    """Providers whose integration has a saved/tested key. `railcall` is always local-configured."""
    out = {"railcall"}
    for items in (integrations or {}).values():
        if isinstance(items, list):
            for it in items:
                if it.get("status") in ("key_present", "tested"):
                    out.add(it.get("id"))
    return out


def resolve_status(cmd, configured):
    """Map a command to exactly one terminal status given which providers are configured."""
    if not cmd.get("wired"):
        return "not_wired_yet"
    if cmd.get("requires") and cmd.get("provider") not in configured:
        return "not_configured"
    mode = cmd.get("mode")
    if mode == "write_blocked":
        return "blocked_by_policy"
    if mode == "write_requires_approval":
        return "available_write_requires_approval"
    return "available_read_only"


def validate_inputs(cmd, inputs):
    """Semantic Firewall: the payload must satisfy the command's input schema. Returns None or an error
    string. A malformed payload is rejected HERE and never surfaced for human approval."""
    inputs = inputs or {}
    for field, spec in (cmd.get("input_schema") or {}).items():
        if spec.get("required") and (field not in inputs or inputs[field] in (None, "", [])):
            return "missing required field: " + field
        if field in inputs:
            t, v = spec.get("type"), inputs[field]
            ok = (t == "array" and isinstance(v, list)) or (t == "string" and isinstance(v, str)) or \
                 (t == "number" and isinstance(v, (int, float))) or (t == "object" and isinstance(v, dict)) or (t is None)
            if not ok:
                return "field '%s' must be %s" % (field, t)
    return None


def redact(inputs):
    """Keep field names + a hash; never store raw values in the receipt."""
    inputs = inputs or {}
    return {"fields": sorted(inputs.keys()),
            "inputs_hash": "sha256:" + hashlib.sha256(
                json.dumps(inputs, sort_keys=True, default=str).encode()).hexdigest()}


def make_receipt(cmd, inputs, intent, result_status, stamp, external_touched=False,
                 artifact=None, approval="none", note="", output=None):
    """Every command attempt -> a receipt. result_status is one of the 6 terminal statuses."""
    r = redact(inputs)
    body = {
        "schema": "railcall_command_receipt.v0",
        "timestamp": stamp,
        "user_intent": intent or "",
        "resolved_command_id": cmd.get("id") if cmd else None,
        "provider": cmd.get("provider") if cmd else None,
        "mode": cmd.get("mode") if cmd else None,
        "risk": cmd.get("risk") if cmd else None,
        "inputs_hash": r["inputs_hash"],
        "input_fields": r["fields"],
        "external_api_touched": bool(external_touched),
        "result_status": result_status,
        "artifact_path": artifact,
        "approval_requirement": approval,
        "execution_class": EXEC_CLASS.get(result_status, "none"),
        "note": note,
        "output": output,
    }
    body["integrity_hash"] = "sha256:" + hashlib.sha256(
        json.dumps({k: v for k, v in body.items() if k != "integrity_hash"},
                   sort_keys=True, default=str).encode()).hexdigest()
    return body
