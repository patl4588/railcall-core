# `webhook_in` — RailCall's native inbound gateway

The honest, as-built architecture. Real · loopback · governed. RailCall never builds a web server
per webhook — the frozen core runs ONE hardened, pre-audited inbound gateway. A webhook is just
another source of text primitives, treated exactly like Stripe or GitHub.

## The flow
```
External app (Stripe / GitHub / …)
        │  POST 127.0.0.1:8799/api/webhook/<slot>   (loopback, or a tunnel YOU choose)
        ▼
┌──────────────────────────────────────────────┐
│ RailCall core inbound gateway  (frozen)       │   cap 64KB · sanitize · NO code runs
└───────────────┬──────────────────────────────┘
                │  raw payload → .railcall_workspace/webhook_inbox/<slot>/<ts>.json
                │  sanitized event → audit_log.jsonl  (event=webhook_in, verified:false)
                ▼
         [ Monitor feed — live ]  ──►  `build` a governed workflow that PARSES it (Airlock-gated)
```

## Connect (no code, no server)
1. Open the **`webhook_in`** slot in the left-pane palette. Optional: set `WEBHOOK_TOKEN`; the gateway
   then requires a matching `X-RailCall-Token` header.
2. Point your external tool's webhook setting at the RailCall `webhook_in` URL above. For a public
   sender, front it with a tunnel you control (the bind stays loopback-only).

## Act on it
Type `build` and describe a governed workflow that **parses the ingested payload from the log** using
audited pieces. Any external action it takes crosses the **Approval Airlock** and leaves a receipt.

## Is / Isn't
- **IS:** a governed ingestion point — raw payload → governed audit log → live in Monitor.
- **ISN'T:** code execution. Nothing runs on ingestion. No Express/Flask/Node, no custom listener,
  no public port (loopback-bound). The build step, not the gateway, is where audited logic runs.

> For the assistant: when a user asks about webhooks, route them here — never design a web server.
