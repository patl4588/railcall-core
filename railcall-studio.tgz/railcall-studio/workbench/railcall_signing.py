#!/usr/bin/env python3
"""
RailCall receipt SIGNING layer (Ed25519, pure stdlib) — the install's signing identity.

What this adds on top of the existing sha256 receipt integrity:
  - on init, the workspace generates ONE Ed25519 keypair for this install.
  - the 32-byte PRIVATE seed lives ONLY in the 0600 vault keys.local.json under the reserved key
    "_railcall_signing_seed" (hex). It is treated exactly like a BYOK secret: never displayed, never
    logged, never transmitted, filtered out of every key-name listing.
  - the PUBLIC key is published to .railcall_workspace/signing_pubkey.json AND /api/signing/pubkey so a
    third party can verify receipts OFF-BOX.
  - sign_block(integrity_value) -> a {"alg","sig","key_id"} block. The signature is over the receipt's
    existing sha256 integrity value (hash/root). Tampering the body breaks the sha256 recompute; tampering
    the hash OR the signature breaks the Ed25519 verify. ADDITIVE — the sha256 field is untouched.
  - verify_against_install(integrity_value, sig_block) verifies the signature against the PINNED install
    public key loaded from signing_pubkey.json — NOT any pubkey carried in the receipt (that would be
    trivially forgeable). The auditor and /api/receipts/verify call this.

NO network. Loopback/offline only. Same path convention as studio_server: WS = <repo>/.railcall_workspace.
"""
import os
import json

import ed25519_pure as _ed   # pure-Python Ed25519, RFC 8032, zero pip

ALG = "ed25519"
SEED_VAULT_KEY = "_railcall_signing_seed"     # reserved vault key; redacted/filtered everywhere
RESERVED_VAULT_KEYS = (SEED_VAULT_KEY,)        # never surfaced as a BYOK integration name

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)


def _ws():
    return os.path.join(_ROOT, ".railcall_workspace")


def _vault_path():
    return os.path.join(_ws(), "keys.local.json")


def _pubkey_path():
    return os.path.join(_ws(), "signing_pubkey.json")


def _jload(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def is_reserved_vault_key(name):
    """True if `name` is a reserved signing-key slot that must never be surfaced as an integration."""
    return name in RESERVED_VAULT_KEYS


# ---------------------------------------------------------------------------
# keygen + publish (called once from seed_workspace)
# ---------------------------------------------------------------------------
def ensure_keypair():
    """If no signing seed exists in the 0600 vault, generate an Ed25519 keypair. Always (re)publish the
    PUBLIC key to signing_pubkey.json. Returns the public-key hex. The PRIVATE seed never leaves the vault.

    Best-effort/offline: any OS error degrades gracefully (returns None) without crashing boot — signing
    is additive, so a workspace that cannot persist a key simply emits unsigned (honest) receipts."""
    try:
        ws = _ws()
        os.makedirs(ws, exist_ok=True)
        try:
            os.chmod(ws, 0o700)
        except OSError:
            pass
        vpath = _vault_path()
        vault = _jload(vpath, {})
        seed_hex = vault.get(SEED_VAULT_KEY)
        if not seed_hex:
            seed = os.urandom(32)                       # 32-byte Ed25519 secret seed (CSPRNG)
            seed_hex = seed.hex()
            vault[SEED_VAULT_KEY] = seed_hex
            _save_vault_0600(vpath, vault)
        else:
            seed = bytes.fromhex(seed_hex)
        pub = _ed.publickey_from_seed(seed)
        _publish_pubkey(pub)
        return pub.hex()
    except Exception:
        return None


def _save_vault_0600(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)
    os.replace(tmp, path)
    try:
        os.chmod(path, 0o600)                            # owner-only — same rule as BYOK secrets
    except OSError:
        pass


def _publish_pubkey(pub_bytes):
    """Write the PUBLISHABLE public key (hex + key_id). World-readable on purpose — a verifier needs it."""
    doc = {
        "schema": "railcall_signing_pubkey.v1",
        "alg": ALG,
        "public_key_hex": pub_bytes.hex(),
        "key_id": _ed.key_id(pub_bytes),
        "note": ("Ed25519 PUBLIC key for this RailCall install. Receipt signatures verify against THIS key. "
                 "Safe to publish; the matching private seed never leaves the 0600 vault."),
    }
    path = _pubkey_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(doc, f, indent=2)
    os.replace(tmp, path)
    return doc


# ---------------------------------------------------------------------------
# load (private seed stays internal; public key is published)
# ---------------------------------------------------------------------------
def _load_seed():
    """Internal only — never exposed via any API/log. Returns 32 bytes or None."""
    vault = _jload(_vault_path(), {})
    seed_hex = vault.get(SEED_VAULT_KEY)
    if not seed_hex:
        return None
    try:
        seed = bytes.fromhex(seed_hex)
        return seed if len(seed) == 32 else None
    except Exception:
        return None


def published_pubkey():
    """The published public-key doc (public_key_hex + key_id + alg), or None if not yet generated.
    This is what /api/signing/pubkey returns and what the verifier PINS against."""
    doc = _jload(_pubkey_path(), None)
    if isinstance(doc, dict) and doc.get("public_key_hex"):
        return doc
    # fall back: derive from the seed if the published file is missing but a seed exists
    seed = _load_seed()
    if seed:
        try:
            return _publish_pubkey(_ed.publickey_from_seed(seed))
        except Exception:
            return None
    return None


def install_pubkey_bytes():
    """32-byte PINNED install public key (from signing_pubkey.json), or None."""
    doc = published_pubkey()
    if not doc:
        return None
    try:
        pk = bytes.fromhex(doc["public_key_hex"])
        return pk if len(pk) == 32 else None
    except Exception:
        return None


def install_key_id():
    doc = published_pubkey()
    return doc.get("key_id") if doc else None


# ---------------------------------------------------------------------------
# sign (generators) + verify (auditor)
# ---------------------------------------------------------------------------
def _integrity_bytes(integrity_value):
    """Canonical bytes signed/verified: the receipt's integrity hash STRING utf-8 encoded. The integrity
    value already covers the receipt body, so signing it seals the whole receipt transitively."""
    return str(integrity_value).encode("utf-8")


def sign_block(integrity_value):
    """Return a signature block for a receipt whose existing sha256 integrity == integrity_value.
       {"alg":"ed25519", "sig": <hex over the integrity value bytes>, "key_id": <short pubkey id>}
    Returns None if no signing key is available (caller then emits an honestly UNSIGNED receipt — never a
    fake signature). ADDITIVE: callers attach this UNDER a new "signature" field, leaving sha256 as-is."""
    seed = _load_seed()
    if not seed or not integrity_value:
        return None
    try:
        pub = _ed.publickey_from_seed(seed)
        sig = _ed.sign(_integrity_bytes(integrity_value), seed, pub)
        return {"alg": ALG, "sig": sig.hex(), "key_id": _ed.key_id(pub)}
    except Exception:
        return None


# verdict constants for the honest signed / unsigned / FAIL distinction
SIG_VERIFIED = "signed_and_verified"
SIG_UNSIGNED = "unsigned"
SIG_FAIL = "signature_fail"


def verify_against_install(integrity_value, sig_block):
    """Verify a receipt's signature block against the PINNED install public key (signing_pubkey.json),
    NOT any key embedded in the receipt. Returns one of:
        SIG_UNSIGNED  — no signature block present (legacy/honest; NOT a fail)
        SIG_VERIFIED  — signature present AND verifies against the install pubkey over integrity_value
        SIG_FAIL      — signature present but does NOT verify (forged / tampered / wrong key / no install key)
    """
    if not sig_block:
        return SIG_UNSIGNED
    if not isinstance(sig_block, dict):
        return SIG_FAIL
    sig_hex = sig_block.get("sig")
    alg = sig_block.get("alg")
    if alg != ALG or not sig_hex:
        return SIG_FAIL
    pin = install_pubkey_bytes()
    if not pin:
        # a receipt CLAIMS a signature but this install has no pinned public key to check it against ->
        # we cannot bless it as verified. Honest FAIL (never a fake green).
        return SIG_FAIL
    try:
        sig = bytes.fromhex(sig_hex)
    except Exception:
        return SIG_FAIL
    ok = _ed.verify(sig, _integrity_bytes(integrity_value), pin)
    return SIG_VERIFIED if ok else SIG_FAIL
