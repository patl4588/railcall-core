#!/usr/bin/env python3
"""
RailCall Studio — local Layer-2 Terminal server.  v0.1 SHELL.

LOOPBACK ONLY (127.0.0.1). The terminal + local folder stay the source of truth;
this server just *organizes* them. It persists a workspace (.railcall_workspace/),
serves the 3-pane Studio UI, exposes a real usage meter, an audit read, the BYOK
integrations store (incl. RailCall's MCP server → Claude/Cursor), and the existing
run/receipt bridge.

HONESTY / SECURITY (per directive):
  - binds 127.0.0.1 only, never 0.0.0.0
  - BYOK secrets stay on disk under the user's home; never sent anywhere by Studio
  - usage meter is REAL (calls /v1/balance); shows UNKNOWN when it can't verify — never faked
  - audit reads real receipts; PASS/UNKNOWN only, no fabricated green
  - changes NO production system (no Stripe/Render/env writes)
"""
import http.server
import socketserver
import json
import hashlib
import hmac
import os
import sys
import glob
import re
import time
import subprocess
import urllib.request
import urllib.parse
import urllib.error

import compose_engine  # local: the compose+compile engine (spec -> visual + real receipt)
import command_registry as cmdreg  # local: the Org API Command Registry v0 (typed commands + governance)
import approval_airlock as airlock  # local: Semantic Firewall + Approval Airlock + approval-binding receipts
import flow_engine  # local: the flow runtime — runs the RailCall-built workflow spec ON data (the motor)
import audit_workflow as auditor  # local: the independent auditor — per-receipt verification for the UI receipt cards

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
WS = os.path.join(ROOT, ".railcall_workspace")
HOST = "127.0.0.1"
PORT = int(os.environ.get("STUDIO_PORT", "8799"))
GATEWAY = os.environ.get("RAILCALL_GATEWAY_URL", "https://railcall-core.onrender.com").rstrip("/")
TOKEN = os.path.join(os.path.expanduser("~"), ".config", "railcall", "token.json")

ALLOWED = {  # the terminal may run ONLY these (no shell, no arbitrary input)
    "build":    [sys.executable, "mcp_server.py", "--build-workflow", "fixtures/lead_history.csv"],
    "workflow": [sys.executable, "mcp_server.py", "--build-workflow", "fixtures/lead_history.csv"],
}

# ---- integration metadata DB (BYOK). Doubles as the MCP discovery manifest: declares what each
#      integration needs, its risk, read/write capability, and the workflows it would unlock.
#      v0 = scaffold + HONEST statuses; keys stay local; deep per-connector API wiring lands later.
INTEGRATIONS_SEED = {
    "LLMs · BYOK": [
        {"id": "mcp", "name": "RailCall MCP → Claude / Cursor", "required": ["client"], "optional": [],
         "risk": "low", "read_write": "read", "workflows": ["stay_on_your_model", "expose_integrations_as_tools"],
         "hint": "Point your Claude/Cursor MCP config at this local server — stay on YOUR model + key."},
        {"id": "anthropic", "name": "Anthropic · Claude", "required": ["ANTHROPIC_API_KEY"], "optional": [],
         "risk": "medium", "read_write": "read", "workflows": ["chat", "compose_workflow"], "docs": "https://docs.anthropic.com"},
        {"id": "openai", "name": "OpenAI", "required": ["OPENAI_API_KEY"], "optional": ["OPENAI_ORG"],
         "risk": "medium", "read_write": "read", "workflows": ["chat", "compose_workflow"], "docs": "https://platform.openai.com/docs"},
        {"id": "groq", "name": "Groq · fast inference", "required": ["GROQ_API_KEY"], "optional": ["GROQ_MODEL"],
         "risk": "medium", "read_write": "read", "workflows": ["chat", "compose_workflow"], "docs": "https://console.groq.com/docs"},
        {"id": "xai", "name": "xAI · Grok", "required": ["XAI_API_KEY"], "optional": [],
         "risk": "medium", "read_write": "read", "workflows": ["chat"], "docs": "https://docs.x.ai"},
        {"id": "gemini", "name": "Google Gemini", "required": ["GEMINI_API_KEY"], "optional": [],
         "risk": "medium", "read_write": "read", "workflows": ["chat"], "docs": "https://ai.google.dev"},
    ],
    "Code & Repos": [
        {"id": "github", "name": "GitHub", "required": ["GITHUB_TOKEN", "GITHUB_OWNER", "GITHUB_REPO"],
         "optional": ["GITHUB_DEFAULT_BRANCH"], "risk": "medium", "read_write": "read",
         "workflows": ["create_issue_from_failed_audit", "create_pr_from_session", "show_changed_files"],
         "docs": "https://docs.github.com/rest"},
    ],
    "Messaging & Email": [
        {"id": "email", "name": "Email · SMTP (BYOK)",
         "required": ["SMTP_HOST", "SMTP_PORT", "SMTP_USER", "SMTP_PASS", "SMTP_FROM"],
         "optional": ["DRY_RUN"], "risk": "high", "read_write": "write",
         "workflows": ["send_followup_email", "send_receipt_on_payment"],
         "hint": "Your own SMTP creds, stored locally (0600). Set DRY_RUN=1 to compose+approve WITHOUT sending.",
         "docs": "https://docs.python.org/3/library/smtplib.html"},
    ],
    "Webhooks & Events": [
        {"id": "webhook", "name": "Webhook · outgoing", "required": ["WEBHOOK_URL"], "optional": ["WEBHOOK_SECRET"],
         "risk": "medium", "read_write": "write", "workflows": ["post_event_on_approval", "notify_on_receipt"],
         "hint": "POST governed events to any URL — every send still crosses the Approval Airlock.", "docs": ""},
        {"id": "webhook_in", "name": "Webhook · incoming", "required": ["WEBHOOK_PATH"], "optional": ["WEBHOOK_TOKEN"],
         "risk": "low", "read_write": "read", "workflows": ["ingest_event_into_workflow"],
         "hint": "Receive events into a workflow over a local loopback path.", "docs": ""},
    ],
    "CRM & Automation": [
        {"id": "salesforce", "name": "Salesforce", "required": ["SF_INSTANCE_URL", "SF_ACCESS_TOKEN"], "optional": [],
         "risk": "high", "read_write": "write", "workflows": ["sync_records", "create_opportunity", "update_account"],
         "hint": "Read/write Salesforce records — every write crosses the Approval Airlock.",
         "docs": "https://developer.salesforce.com/docs"},
        {"id": "airtable", "name": "Airtable", "required": ["AIRTABLE_TOKEN", "AIRTABLE_BASE"], "optional": ["AIRTABLE_TABLE"],
         "risk": "medium", "read_write": "write", "workflows": ["read_table", "append_rows"],
         "hint": "Read a base / append rows. Token stored locally · 0600.",
         "docs": "https://airtable.com/developers/web/api/introduction"},
        {"id": "zapier", "name": "Zapier", "required": ["ZAPIER_HOOK_URL"], "optional": [],
         "risk": "medium", "read_write": "write", "workflows": ["trigger_zap_on_event"],
         "hint": "Trigger a Zap via a catch-hook URL — governed + receipted.",
         "docs": "https://zapier.com/apps/webhook/integrations"},
    ],
    "Cloud & Deploy": [
        {"id": "render", "name": "Render", "required": ["RENDER_API_KEY"], "optional": ["RENDER_SERVICE_ID"],
         "risk": "medium", "read_write": "read", "workflows": ["deploy_visibility", "tail_logs"], "docs": "https://render.com/docs"},
        {"id": "supabase", "name": "Supabase", "required": ["SUPABASE_URL", "SUPABASE_KEY"], "optional": [],
         "risk": "high", "read_write": "read", "workflows": ["query_table", "row_counts"], "docs": "https://supabase.com/docs"},
        {"id": "postgres", "name": "Postgres", "required": ["DATABASE_URL"], "optional": [],
         "risk": "high", "read_write": "read", "workflows": ["query", "schema_introspect"], "docs": "https://www.postgresql.org/docs/"},
    ],
    "Comms": [
        {"id": "slack", "name": "Slack", "required": ["SLACK_BOT_TOKEN"], "optional": ["SLACK_CHANNEL"],
         "risk": "low", "read_write": "read", "workflows": ["build_alerts", "post_audit_summary"], "docs": "https://api.slack.com"},
        {"id": "discord", "name": "Discord", "required": ["DISCORD_BOT_TOKEN"], "optional": ["DISCORD_CHANNEL"],
         "risk": "low", "read_write": "read", "workflows": ["build_alerts"], "community": True, "docs": "https://discord.com/developers/docs"},
        {"id": "telegram", "name": "Telegram", "required": ["TELEGRAM_BOT_TOKEN"], "optional": ["TELEGRAM_CHAT_ID"],
         "risk": "low", "read_write": "read", "workflows": ["build_alerts"], "community": True, "docs": "https://core.telegram.org/bots/api"},
    ],
    "Docs & Workspace": [
        {"id": "microsoft", "name": "Microsoft Graph", "required": ["MS_CLIENT_ID", "MS_CLIENT_SECRET", "MS_TENANT_ID"],
         "optional": [], "risk": "medium", "read_write": "read", "workflows": ["export_docs", "teams_message"], "docs": "https://learn.microsoft.com/graph"},
        {"id": "google", "name": "Google Drive / Docs", "required": ["GOOGLE_OAUTH_JSON"], "optional": [],
         "risk": "medium", "read_write": "read", "workflows": ["export_docs"], "docs": "https://developers.google.com/drive"},
        {"id": "notion", "name": "Notion", "required": ["NOTION_TOKEN"], "optional": ["NOTION_DB_ID"],
         "risk": "low", "read_write": "read", "workflows": ["export_session_notes"], "docs": "https://developers.notion.com"},
    ],
    "Payments": [
        {"id": "stripe", "name": "Stripe", "required": ["STRIPE_SECRET_KEY"], "optional": ["STRIPE_WEBHOOK_SECRET"],
         "risk": "high", "read_write": "read", "workflows": ["payment_qa", "read_balance"], "docs": "https://stripe.com/docs/api"},
    ],
    "Monitoring": [
        {"id": "sentry", "name": "Sentry", "required": ["SENTRY_DSN"], "optional": ["SENTRY_AUTH_TOKEN"],
         "risk": "low", "read_write": "read", "workflows": ["error_feed"], "docs": "https://docs.sentry.io"},
        {"id": "uptimerobot", "name": "UptimeRobot", "required": ["UPTIMEROBOT_API_KEY"], "optional": [],
         "risk": "low", "read_write": "read", "workflows": ["uptime_status"], "docs": "https://uptimerobot.com/api"},
        {"id": "betterstack", "name": "Better Stack", "required": ["BETTERSTACK_TOKEN"], "optional": [],
         "risk": "low", "read_write": "read", "workflows": ["uptime_status", "incident_feed"], "docs": "https://betterstack.com/docs"},
    ],
}
COMMUNITY = {"url": "https://discord.gg/railcall", "label": "Join the RailCall developer community"}
RISK_RANK = {"low": 0, "medium": 1, "high": 2}


def _ig(iid, name, required, risk="medium", rw="read", workflows=None, docs="", optional=None):
    return {"id": iid, "name": name, "required": required, "optional": optional or [],
            "risk": risk, "read_write": rw, "workflows": workflows or [], "docs": docs}


# A much wider BYOK palette — the parts you BUILD with + automate against. Each is a catalog slot:
# paste a key, it vaults locally (0600). LLMs/github get a live read-only test; the rest save honestly
# as key_present until their per-connector actions wire in. Every WRITE still crosses the Approval Airlock.
INTEGRATIONS_SEED["LLMs · BYOK"] += [
    _ig("mistral", "Mistral AI", ["MISTRAL_API_KEY"], workflows=["chat", "compose"], docs="https://docs.mistral.ai"),
    _ig("cohere", "Cohere", ["COHERE_API_KEY"], workflows=["chat"], docs="https://docs.cohere.com"),
    _ig("deepseek", "DeepSeek", ["DEEPSEEK_API_KEY"], workflows=["chat", "compose"], docs="https://platform.deepseek.com"),
    _ig("perplexity", "Perplexity", ["PERPLEXITY_API_KEY"], workflows=["chat"], docs="https://docs.perplexity.ai"),
    _ig("openrouter", "OpenRouter", ["OPENROUTER_API_KEY"], workflows=["chat"], docs="https://openrouter.ai/docs"),
    _ig("together", "Together AI", ["TOGETHER_API_KEY"], workflows=["chat"], docs="https://docs.together.ai"),
    _ig("ollama", "Ollama · local", ["OLLAMA_HOST"], risk="low", workflows=["chat"], docs="https://ollama.com"),
    _ig("huggingface", "Hugging Face", ["HF_TOKEN"], workflows=["inference"], docs="https://huggingface.co/docs"),
]
INTEGRATIONS_SEED["Code & Repos"] += [
    _ig("gitlab", "GitLab", ["GITLAB_TOKEN", "GITLAB_PROJECT"], workflows=["create_issue", "show_changed_files"], docs="https://docs.gitlab.com/ee/api/"),
    _ig("bitbucket", "Bitbucket", ["BITBUCKET_TOKEN", "BITBUCKET_WORKSPACE"], workflows=["show_changed_files"], docs="https://developer.atlassian.com/bitbucket"),
    _ig("linear", "Linear", ["LINEAR_API_KEY"], rw="write", workflows=["create_issue", "sync_status"], docs="https://developers.linear.app"),
    _ig("jira", "Jira", ["JIRA_TOKEN", "JIRA_HOST", "JIRA_EMAIL"], rw="write", workflows=["create_issue"], docs="https://developer.atlassian.com/cloud/jira/"),
    _ig("vercel", "Vercel", ["VERCEL_TOKEN"], workflows=["deploy_visibility"], docs="https://vercel.com/docs/rest-api"),
    _ig("netlify", "Netlify", ["NETLIFY_TOKEN"], workflows=["deploy_visibility"], docs="https://docs.netlify.com/api/get-started/"),
]
INTEGRATIONS_SEED["Messaging & Email"] += [
    _ig("sendgrid", "SendGrid", ["SENDGRID_API_KEY"], risk="high", rw="write", workflows=["send_email"], docs="https://docs.sendgrid.com"),
    _ig("mailgun", "Mailgun", ["MAILGUN_API_KEY", "MAILGUN_DOMAIN"], risk="high", rw="write", workflows=["send_email"], docs="https://documentation.mailgun.com"),
    _ig("postmark", "Postmark", ["POSTMARK_TOKEN"], risk="high", rw="write", workflows=["send_email"], docs="https://postmarkapp.com/developer"),
    _ig("resend", "Resend", ["RESEND_API_KEY"], risk="high", rw="write", workflows=["send_email"], docs="https://resend.com/docs"),
    _ig("twilio", "Twilio · SMS", ["TWILIO_SID", "TWILIO_TOKEN", "TWILIO_FROM"], risk="high", rw="write", workflows=["send_sms"], docs="https://www.twilio.com/docs"),
]
INTEGRATIONS_SEED["Comms"] += [
    _ig("msteams", "Microsoft Teams", ["TEAMS_WEBHOOK_URL"], rw="write", workflows=["post_message"], docs="https://learn.microsoft.com/microsoftteams/platform/"),
    _ig("intercom", "Intercom", ["INTERCOM_TOKEN"], workflows=["read_conversations"], docs="https://developers.intercom.com"),
    _ig("zendesk", "Zendesk", ["ZENDESK_TOKEN", "ZENDESK_SUBDOMAIN", "ZENDESK_EMAIL"], workflows=["read_tickets"], docs="https://developer.zendesk.com"),
]
INTEGRATIONS_SEED["CRM & Automation"] += [
    _ig("hubspot", "HubSpot", ["HUBSPOT_TOKEN"], rw="write", workflows=["sync_contacts", "create_deal"], docs="https://developers.hubspot.com"),
    _ig("pipedrive", "Pipedrive", ["PIPEDRIVE_TOKEN"], rw="write", workflows=["sync_deals"], docs="https://developers.pipedrive.com"),
    _ig("zoho", "Zoho CRM", ["ZOHO_TOKEN"], rw="write", workflows=["sync_records"], docs="https://www.zoho.com/crm/developer/docs/"),
    _ig("make", "Make (Integromat)", ["MAKE_WEBHOOK_URL"], rw="write", workflows=["trigger_scenario"], docs="https://www.make.com/en/api-documentation"),
    _ig("n8n", "n8n", ["N8N_WEBHOOK_URL"], rw="write", workflows=["trigger_workflow"], docs="https://docs.n8n.io"),
]
INTEGRATIONS_SEED["Cloud & Deploy"] += [
    _ig("aws", "AWS", ["AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_REGION"], risk="high", workflows=["s3_list", "lambda_invoke"], docs="https://docs.aws.amazon.com"),
    _ig("gcp", "Google Cloud", ["GCP_SERVICE_ACCOUNT_JSON"], risk="high", workflows=["storage_list"], docs="https://cloud.google.com/apis/docs/overview"),
    _ig("azure", "Microsoft Azure", ["AZURE_CLIENT_ID", "AZURE_CLIENT_SECRET", "AZURE_TENANT_ID"], risk="high", workflows=["resource_list"], docs="https://learn.microsoft.com/rest/api/azure/"),
    _ig("cloudflare", "Cloudflare", ["CLOUDFLARE_TOKEN"], workflows=["dns_records", "purge_cache"], docs="https://developers.cloudflare.com/api/"),
    _ig("fly", "Fly.io", ["FLY_API_TOKEN"], workflows=["deploy_visibility", "tail_logs"], docs="https://fly.io/docs/"),
    _ig("railway", "Railway", ["RAILWAY_TOKEN"], workflows=["deploy_visibility"], docs="https://docs.railway.app"),
]
INTEGRATIONS_SEED["Docs & Workspace"] += [
    _ig("confluence", "Confluence", ["CONFLUENCE_TOKEN", "CONFLUENCE_HOST", "CONFLUENCE_EMAIL"], workflows=["export_pages"], docs="https://developer.atlassian.com/cloud/confluence/"),
    _ig("dropbox", "Dropbox", ["DROPBOX_TOKEN"], workflows=["list_files"], docs="https://www.dropbox.com/developers"),
    _ig("box", "Box", ["BOX_TOKEN"], workflows=["list_files"], docs="https://developer.box.com"),
    _ig("asana", "Asana", ["ASANA_TOKEN"], rw="write", workflows=["create_task"], docs="https://developers.asana.com"),
    _ig("trello", "Trello", ["TRELLO_KEY", "TRELLO_TOKEN"], rw="write", workflows=["create_card"], docs="https://developer.atlassian.com/cloud/trello/"),
]
INTEGRATIONS_SEED["Payments"] += [
    _ig("paypal", "PayPal", ["PAYPAL_CLIENT_ID", "PAYPAL_SECRET"], risk="high", workflows=["read_transactions"], docs="https://developer.paypal.com"),
    _ig("square", "Square", ["SQUARE_TOKEN"], risk="high", workflows=["read_payments"], docs="https://developer.squareup.com"),
    _ig("quickbooks", "QuickBooks", ["QB_TOKEN", "QB_REALM_ID"], risk="high", workflows=["read_invoices"], docs="https://developer.intuit.com"),
    _ig("xero", "Xero", ["XERO_TOKEN", "XERO_TENANT_ID"], risk="high", workflows=["read_invoices"], docs="https://developer.xero.com"),
    _ig("plaid", "Plaid", ["PLAID_CLIENT_ID", "PLAID_SECRET"], risk="high", workflows=["read_balances"], docs="https://plaid.com/docs/"),
]
INTEGRATIONS_SEED["Monitoring"] += [
    _ig("datadog", "Datadog", ["DD_API_KEY", "DD_APP_KEY"], workflows=["metrics_query", "incident_feed"], docs="https://docs.datadoghq.com/api/"),
    _ig("pagerduty", "PagerDuty", ["PAGERDUTY_TOKEN"], rw="write", workflows=["incident_feed", "trigger_incident"], docs="https://developer.pagerduty.com"),
    _ig("grafana", "Grafana", ["GRAFANA_TOKEN", "GRAFANA_HOST"], workflows=["dashboard_list"], docs="https://grafana.com/docs/grafana/latest/developers/http_api/"),
    _ig("newrelic", "New Relic", ["NEWRELIC_API_KEY"], workflows=["metrics_query"], docs="https://docs.newrelic.com/docs/apis/"),
]
INTEGRATIONS_SEED.update({
    "Databases": [
        _ig("mysql", "MySQL", ["MYSQL_URL"], risk="high", workflows=["query", "schema_introspect"], docs="https://dev.mysql.com/doc/"),
        _ig("mongodb", "MongoDB", ["MONGODB_URI"], risk="high", workflows=["query", "collection_counts"], docs="https://www.mongodb.com/docs/"),
        _ig("redis", "Redis", ["REDIS_URL"], risk="high", workflows=["read_keys"], docs="https://redis.io/docs/"),
        _ig("snowflake", "Snowflake", ["SNOWFLAKE_ACCOUNT", "SNOWFLAKE_TOKEN"], risk="high", workflows=["query"], docs="https://docs.snowflake.com"),
    ],
    "Marketing & Analytics": [
        _ig("mailchimp", "Mailchimp", ["MAILCHIMP_API_KEY"], rw="write", workflows=["sync_audience"], docs="https://mailchimp.com/developer/"),
        _ig("klaviyo", "Klaviyo", ["KLAVIYO_API_KEY"], rw="write", workflows=["sync_profiles"], docs="https://developers.klaviyo.com"),
        _ig("segment", "Segment", ["SEGMENT_WRITE_KEY"], rw="write", workflows=["track_event"], docs="https://segment.com/docs/"),
        _ig("posthog", "PostHog", ["POSTHOG_API_KEY", "POSTHOG_HOST"], workflows=["read_events", "funnels"], docs="https://posthog.com/docs/api"),
        _ig("mixpanel", "Mixpanel", ["MIXPANEL_TOKEN"], workflows=["read_events"], docs="https://developer.mixpanel.com"),
        _ig("ga4", "Google Analytics 4", ["GA4_PROPERTY_ID", "GA4_SERVICE_ACCOUNT_JSON"], workflows=["read_report"], docs="https://developers.google.com/analytics"),
    ],
})
# Wave 2 — even wider palette (the universal command-center play). Same honest rules: BYOK catalog
# slots, vault-stored 0600, key_present until per-connector actions wire, Airlock on every write.
INTEGRATIONS_SEED["LLMs · BYOK"] += [
    _ig("fireworks", "Fireworks AI", ["FIREWORKS_API_KEY"], workflows=["chat"], docs="https://docs.fireworks.ai"),
    _ig("replicate", "Replicate", ["REPLICATE_TOKEN"], workflows=["inference"], docs="https://replicate.com/docs"),
    _ig("elevenlabs", "ElevenLabs · voice", ["ELEVENLABS_API_KEY"], workflows=["tts"], docs="https://elevenlabs.io/docs"),
    _ig("deepgram", "Deepgram · speech", ["DEEPGRAM_API_KEY"], workflows=["transcribe"], docs="https://developers.deepgram.com"),
    _ig("assemblyai", "AssemblyAI", ["ASSEMBLYAI_API_KEY"], workflows=["transcribe"], docs="https://www.assemblyai.com/docs"),
    _ig("stability", "Stability AI", ["STABILITY_API_KEY"], workflows=["image_gen"], docs="https://platform.stability.ai/docs"),
]
INTEGRATIONS_SEED["Databases"] += [
    _ig("pinecone", "Pinecone · vectors", ["PINECONE_API_KEY"], workflows=["vector_query"], docs="https://docs.pinecone.io"),
    _ig("weaviate", "Weaviate", ["WEAVIATE_URL", "WEAVIATE_API_KEY"], workflows=["vector_query"], docs="https://weaviate.io/developers/weaviate"),
    _ig("qdrant", "Qdrant", ["QDRANT_URL", "QDRANT_API_KEY"], workflows=["vector_query"], docs="https://qdrant.tech/documentation/"),
    _ig("clickhouse", "ClickHouse", ["CLICKHOUSE_URL"], risk="high", workflows=["query"], docs="https://clickhouse.com/docs"),
    _ig("planetscale", "PlanetScale", ["PLANETSCALE_URL"], risk="high", workflows=["query"], docs="https://planetscale.com/docs"),
    _ig("neon", "Neon Postgres", ["NEON_DATABASE_URL"], risk="high", workflows=["query"], docs="https://neon.tech/docs"),
    _ig("elasticsearch", "Elasticsearch", ["ELASTIC_URL", "ELASTIC_API_KEY"], workflows=["search"], docs="https://www.elastic.co/guide/"),
]
INTEGRATIONS_SEED["Code & Repos"] += [
    _ig("circleci", "CircleCI", ["CIRCLECI_TOKEN"], workflows=["build_status"], docs="https://circleci.com/docs/api/"),
    _ig("jenkins", "Jenkins", ["JENKINS_URL", "JENKINS_USER", "JENKINS_TOKEN"], workflows=["build_status"], docs="https://www.jenkins.io/doc/book/using/remote-access-api/"),
    _ig("postman", "Postman", ["POSTMAN_API_KEY"], workflows=["collection_run"], docs="https://learning.postman.com/docs/developer/intro-api/"),
    _ig("retool", "Retool", ["RETOOL_API_TOKEN"], rw="write", workflows=["trigger_app"], docs="https://docs.retool.com"),
    _ig("firebase", "Firebase", ["FIREBASE_SERVICE_ACCOUNT_JSON"], risk="high", workflows=["read_collection"], docs="https://firebase.google.com/docs"),
]
INTEGRATIONS_SEED["Comms"] += [
    _ig("whatsapp", "WhatsApp Business", ["WHATSAPP_TOKEN", "WHATSAPP_PHONE_ID"], rw="write", workflows=["send_message"], docs="https://developers.facebook.com/docs/whatsapp"),
    _ig("vonage", "Vonage · SMS/voice", ["VONAGE_API_KEY", "VONAGE_API_SECRET"], risk="high", rw="write", workflows=["send_sms"], docs="https://developer.vonage.com"),
]
INTEGRATIONS_SEED["CRM & Automation"] += [
    _ig("dynamics", "Microsoft Dynamics 365", ["DYNAMICS_TOKEN", "DYNAMICS_ORG_URL"], rw="write", workflows=["sync_records"], docs="https://learn.microsoft.com/dynamics365/"),
    _ig("freshsales", "Freshsales", ["FRESHSALES_TOKEN", "FRESHSALES_DOMAIN"], rw="write", workflows=["sync_contacts"], docs="https://developers.freshworks.com/crm/api/"),
]
INTEGRATIONS_SEED["Marketing & Analytics"] += [
    _ig("brevo", "Brevo (Sendinblue)", ["BREVO_API_KEY"], rw="write", workflows=["send_campaign"], docs="https://developers.brevo.com"),
    _ig("activecampaign", "ActiveCampaign", ["AC_API_KEY", "AC_API_URL"], rw="write", workflows=["sync_contacts"], docs="https://developers.activecampaign.com"),
    _ig("hotjar", "Hotjar", ["HOTJAR_API_KEY"], workflows=["read_insights"], docs="https://help.hotjar.com"),
    _ig("plausible", "Plausible", ["PLAUSIBLE_API_KEY"], workflows=["read_stats"], docs="https://plausible.io/docs"),
    _ig("matomo", "Matomo", ["MATOMO_URL", "MATOMO_TOKEN"], workflows=["read_stats"], docs="https://developer.matomo.org"),
    _ig("metabase", "Metabase", ["METABASE_URL", "METABASE_TOKEN"], workflows=["run_question"], docs="https://www.metabase.com/docs/"),
]
INTEGRATIONS_SEED.update({
    "E-commerce": [
        _ig("shopify", "Shopify", ["SHOPIFY_TOKEN", "SHOPIFY_STORE"], rw="write", workflows=["read_orders", "update_inventory"], docs="https://shopify.dev/docs/api"),
        _ig("woocommerce", "WooCommerce", ["WOO_URL", "WOO_KEY", "WOO_SECRET"], rw="write", workflows=["read_orders"], docs="https://woocommerce.github.io/woocommerce-rest-api-docs/"),
        _ig("bigcommerce", "BigCommerce", ["BIGCOMMERCE_TOKEN", "BIGCOMMERCE_STORE_HASH"], rw="write", workflows=["read_orders"], docs="https://developer.bigcommerce.com"),
        _ig("magento", "Magento", ["MAGENTO_URL", "MAGENTO_TOKEN"], rw="write", workflows=["read_orders"], docs="https://developer.adobe.com/commerce/"),
        _ig("squarespace", "Squarespace Commerce", ["SQUARESPACE_TOKEN"], workflows=["read_orders"], docs="https://developers.squarespace.com"),
        _ig("etsy", "Etsy", ["ETSY_TOKEN"], workflows=["read_orders"], docs="https://developers.etsy.com"),
    ],
    "HR & People": [
        _ig("bamboohr", "BambooHR", ["BAMBOOHR_TOKEN", "BAMBOOHR_SUBDOMAIN"], workflows=["read_employees"], docs="https://documentation.bamboohr.com"),
        _ig("rippling", "Rippling", ["RIPPLING_TOKEN"], workflows=["read_employees"], docs="https://developer.rippling.com"),
        _ig("gusto", "Gusto", ["GUSTO_TOKEN"], risk="high", workflows=["read_payroll"], docs="https://docs.gusto.com"),
        _ig("deel", "Deel", ["DEEL_TOKEN"], risk="high", workflows=["read_contracts"], docs="https://developer.deel.com"),
        _ig("greenhouse", "Greenhouse", ["GREENHOUSE_TOKEN"], workflows=["read_candidates"], docs="https://developers.greenhouse.io"),
        _ig("workday", "Workday", ["WORKDAY_TOKEN", "WORKDAY_TENANT"], risk="high", workflows=["read_workers"], docs="https://community.workday.com"),
    ],
    "Finance & Accounting": [
        _ig("freshbooks", "FreshBooks", ["FRESHBOOKS_TOKEN"], risk="high", workflows=["read_invoices"], docs="https://www.freshbooks.com/api"),
        _ig("wave", "Wave", ["WAVE_TOKEN"], risk="high", workflows=["read_invoices"], docs="https://developer.waveapps.com"),
        _ig("sage", "Sage", ["SAGE_TOKEN"], risk="high", workflows=["read_ledger"], docs="https://developer.sage.com"),
        _ig("brex", "Brex", ["BREX_TOKEN"], risk="high", workflows=["read_transactions"], docs="https://developer.brex.com"),
        _ig("ramp", "Ramp", ["RAMP_TOKEN"], risk="high", workflows=["read_transactions"], docs="https://docs.ramp.com"),
        _ig("mercury", "Mercury", ["MERCURY_TOKEN"], risk="high", workflows=["read_transactions"], docs="https://docs.mercury.com"),
    ],
    "Support": [
        _ig("freshdesk", "Freshdesk", ["FRESHDESK_TOKEN", "FRESHDESK_DOMAIN"], workflows=["read_tickets"], docs="https://developers.freshdesk.com"),
        _ig("helpscout", "Help Scout", ["HELPSCOUT_TOKEN"], workflows=["read_conversations"], docs="https://developer.helpscout.com"),
        _ig("gorgias", "Gorgias", ["GORGIAS_TOKEN", "GORGIAS_DOMAIN"], workflows=["read_tickets"], docs="https://developers.gorgias.com"),
    ],
})


def _bulk(cat, items, risk="medium", rw="read"):
    """Catalog-only BYOK slots — recognizable tools you can connect; per-connector actions wire in
    later. Defaults filled; never duplicated against an already-seeded id."""
    have = {i["id"] for lst in INTEGRATIONS_SEED.values() for i in lst}
    out = INTEGRATIONS_SEED.setdefault(cat, [])
    for iid, name in items:
        if iid in have:
            continue
        out.append(_ig(iid, name, [iid.upper().replace("-", "_") + "_API_KEY"], risk=risk, rw=rw))
        have.add(iid)


_bulk("AI · Models", [("ai21", "AI21 Labs"), ("writer", "Writer"), ("voyage", "Voyage AI"), ("jina", "Jina AI"),
    ("cerebras", "Cerebras"), ("sambanova", "SambaNova"), ("octoai", "OctoAI"), ("anyscale", "Anyscale"),
    ("deepinfra", "DeepInfra"), ("novita", "Novita AI"), ("baseten", "Baseten"), ("modal", "Modal"),
    ("runpod", "RunPod"), ("lambdalabs", "Lambda Labs"), ("bedrock", "AWS Bedrock"), ("vertexai", "Google Vertex AI"),
    ("azureopenai", "Azure OpenAI"), ("hyperbolic", "Hyperbolic")])
_bulk("AI · Voice & Media", [("playht", "PlayHT"), ("murf", "Murf"), ("resemble", "Resemble AI"), ("whisper", "OpenAI Whisper"),
    ("runwayml", "Runway"), ("pika", "Pika"), ("lumaai", "Luma AI"), ("ideogram", "Ideogram"), ("leonardo", "Leonardo AI"),
    ("recraft", "Recraft"), ("suno", "Suno"), ("heygen", "HeyGen"), ("synthesia", "Synthesia")])
_bulk("Vector & Search", [("milvus", "Milvus"), ("pgvector", "pgvector"), ("vespa", "Vespa"), ("marqo", "Marqo"),
    ("lancedb", "LanceDB"), ("turbopuffer", "turbopuffer"), ("typesense", "Typesense"), ("meilisearch", "Meilisearch"),
    ("algolia", "Algolia")])
_bulk("DevOps & CI/CD", [("gitea", "Gitea"), ("azuredevops", "Azure DevOps"), ("buildkite", "Buildkite"), ("argocd", "Argo CD"),
    ("terraform", "Terraform Cloud"), ("pulumi", "Pulumi"), ("ansible", "Ansible Automation"), ("kubernetes", "Kubernetes"),
    ("dockerhub", "Docker Hub"), ("harness", "Harness"), ("sonarqube", "SonarQube"), ("snyk", "Snyk"),
    ("sourcegraph", "Sourcegraph"), ("ngrok", "ngrok"), ("tailscale", "Tailscale"), ("gitpod", "Gitpod"),
    ("codesandbox", "CodeSandbox"), ("replit", "Replit")])
_bulk("Cloud & Hosting", [("heroku", "Heroku"), ("digitalocean", "DigitalOcean"), ("linode", "Linode"), ("vultr", "Vultr"),
    ("hetzner", "Hetzner"), ("scaleway", "Scaleway"), ("oraclecloud", "Oracle Cloud"), ("ibmcloud", "IBM Cloud"),
    ("alibabacloud", "Alibaba Cloud"), ("koyeb", "Koyeb"), ("appwrite", "Appwrite"), ("nhost", "Nhost"),
    ("pocketbase", "PocketBase")])
_bulk("Databases", [("cockroachdb", "CockroachDB"), ("timescale", "TimescaleDB"), ("influxdb", "InfluxDB"),
    ("dynamodb", "DynamoDB"), ("fauna", "Fauna"), ("surrealdb", "SurrealDB"), ("bigquery", "BigQuery"),
    ("redshift", "Redshift"), ("databricks", "Databricks"), ("motherduck", "MotherDuck"), ("singlestore", "SingleStore"),
    ("couchbase", "Couchbase"), ("neo4j", "Neo4j"), ("cassandra", "Cassandra")], risk="high")
_bulk("Comms", [("mattermost", "Mattermost"), ("rocketchat", "Rocket.Chat"), ("zulip", "Zulip"), ("webex", "Webex"),
    ("zoom", "Zoom"), ("ringcentral", "RingCentral"), ("dialpad", "Dialpad"), ("aircall", "Aircall"), ("plivo", "Plivo"),
    ("sinch", "Sinch"), ("messagebird", "MessageBird"), ("telnyx", "Telnyx"), ("infobip", "Infobip"), ("line", "LINE")])
_bulk("CRM & Sales", [("close", "Close"), ("copper", "Copper"), ("insightly", "Insightly"), ("sugarcrm", "SugarCRM"),
    ("keap", "Keap"), ("attio", "Attio"), ("folk", "folk"), ("apollo", "Apollo.io"), ("outreach", "Outreach"),
    ("salesloft", "Salesloft"), ("gong", "Gong"), ("clari", "Clari"), ("hunter", "Hunter"), ("clearbit", "Clearbit"),
    ("zoominfo", "ZoomInfo")])
_bulk("Docs & Workspace", [("monday", "monday.com"), ("clickup", "ClickUp"), ("basecamp", "Basecamp"), ("wrike", "Wrike"),
    ("smartsheet", "Smartsheet"), ("todoist", "Todoist"), ("coda", "Coda"), ("gitbook", "GitBook"), ("guru", "Guru"),
    ("miro", "Miro"), ("figma", "Figma"), ("canva", "Canva"), ("lucidchart", "Lucidchart"), ("evernote", "Evernote"),
    ("onedrive", "OneDrive"), ("sharepoint", "SharePoint"), ("egnyte", "Egnyte")])
_bulk("Scheduling & E-sign", [("calendly", "Calendly"), ("calcom", "Cal.com"), ("savvycal", "SavvyCal"), ("acuity", "Acuity"),
    ("docusign", "DocuSign"), ("pandadoc", "PandaDoc"), ("hellosign", "Dropbox Sign"), ("signnow", "SignNow"),
    ("adobesign", "Adobe Acrobat Sign")])
_bulk("Forms & Surveys", [("typeform", "Typeform"), ("tally", "Tally"), ("jotform", "Jotform"), ("surveymonkey", "SurveyMonkey"),
    ("formstack", "Formstack"), ("fillout", "Fillout"), ("paperform", "Paperform"), ("googleforms", "Google Forms")])
_bulk("Payments & Fintech", [("adyen", "Adyen"), ("braintree", "Braintree"), ("checkoutcom", "Checkout.com"), ("mollie", "Mollie"),
    ("razorpay", "Razorpay"), ("paddle", "Paddle"), ("lemonsqueezy", "Lemon Squeezy"), ("chargebee", "Chargebee"),
    ("recurly", "Recurly"), ("zuora", "Zuora"), ("gocardless", "GoCardless"), ("wise", "Wise"), ("coinbase", "Coinbase"),
    ("gumroad", "Gumroad"), ("billcom", "Bill.com"), ("expensify", "Expensify")], risk="high")
_bulk("Marketing & Analytics", [("amplitude", "Amplitude"), ("heap", "Heap"), ("fullstory", "FullStory"), ("logrocket", "LogRocket"),
    ("rudderstack", "RudderStack"), ("snowplow", "Snowplow"), ("customerio", "Customer.io"), ("drip", "Drip"),
    ("convertkit", "ConvertKit"), ("beehiiv", "beehiiv"), ("mailerlite", "MailerLite"), ("getresponse", "GetResponse"),
    ("marketo", "Marketo"), ("pardot", "Pardot"), ("braze", "Braze"), ("iterable", "Iterable"), ("onesignal", "OneSignal"),
    ("optimizely", "Optimizely"), ("launchdarkly", "LaunchDarkly"), ("statsig", "Statsig")])
_bulk("Analytics & BI", [("looker", "Looker"), ("tableau", "Tableau"), ("powerbi", "Power BI"), ("sigma", "Sigma"),
    ("mode", "Mode"), ("hex", "Hex"), ("lightdash", "Lightdash"), ("preset", "Preset"), ("fathom", "Fathom Analytics"),
    ("pirsch", "Pirsch")])
_bulk("Monitoring & Observability", [("prometheus", "Prometheus"), ("honeycomb", "Honeycomb"), ("dynatrace", "Dynatrace"),
    ("splunk", "Splunk"), ("sumologic", "Sumo Logic"), ("rollbar", "Rollbar"), ("bugsnag", "Bugsnag"), ("raygun", "Raygun"),
    ("opsgenie", "Opsgenie"), ("incidentio", "incident.io"), ("statuspage", "Statuspage"), ("checkly", "Checkly"),
    ("pingdom", "Pingdom"), ("cronitor", "Cronitor"), ("healthchecks", "Healthchecks.io")])
_bulk("E-commerce & Logistics", [("wix", "Wix"), ("ecwid", "Ecwid"), ("prestashop", "PrestaShop"), ("medusa", "Medusa"),
    ("commercetools", "commercetools"), ("swell", "Swell"), ("snipcart", "Snipcart"), ("amazonseller", "Amazon Seller"),
    ("ebay", "eBay"), ("walmart", "Walmart"), ("faire", "Faire"), ("shipstation", "ShipStation"), ("shippo", "Shippo"),
    ("easypost", "EasyPost"), ("aftership", "AfterShip"), ("printful", "Printful"), ("printify", "Printify")])
_bulk("HR & People", [("adp", "ADP"), ("paychex", "Paychex"), ("paylocity", "Paylocity"), ("namely", "Namely"),
    ("justworks", "Justworks"), ("trinet", "TriNet"), ("remotecom", "Remote"), ("oyster", "Oyster"), ("hibob", "HiBob"),
    ("personio", "Personio"), ("factorial", "Factorial"), ("lattice", "Lattice"), ("cultureamp", "Culture Amp"),
    ("fifteenfive", "15Five"), ("ashby", "Ashby"), ("workable", "Workable"), ("smartrecruiters", "SmartRecruiters")])
_bulk("Finance & Accounting", [("netsuite", "NetSuite"), ("sageintacct", "Sage Intacct"), ("zohobooks", "Zoho Books"),
    ("freeagent", "FreeAgent"), ("myob", "MYOB"), ("qonto", "Qonto"), ("pennylane", "Pennylane")], risk="high")
_bulk("Support & Chat", [("front", "Front"), ("liveagent", "LiveAgent"), ("kayako", "Kayako"), ("groove", "Groove"),
    ("hiver", "Hiver"), ("gladly", "Gladly"), ("dixa", "Dixa"), ("crisp", "Crisp"), ("tidio", "Tidio"), ("drift", "Drift"),
    ("livechat", "LiveChat"), ("tawk", "tawk.to"), ("chatwoot", "Chatwoot"), ("missive", "Missive")])
_bulk("Storage & CDN", [("s3", "Amazon S3"), ("r2", "Cloudflare R2"), ("b2", "Backblaze B2"), ("wasabi", "Wasabi"),
    ("gcs", "Google Cloud Storage"), ("azureblob", "Azure Blob"), ("minio", "MinIO"), ("cloudinary", "Cloudinary"),
    ("imgix", "imgix"), ("imagekit", "ImageKit"), ("uploadcare", "Uploadcare"), ("bunny", "Bunny.net"), ("fastly", "Fastly")], risk="high")
_bulk("Auth & Security", [("auth0", "Auth0"), ("okta", "Okta"), ("clerk", "Clerk"), ("workos", "WorkOS"),
    ("supertokens", "SuperTokens"), ("stytch", "Stytch"), ("frontegg", "Frontegg"), ("descope", "Descope"), ("kinde", "Kinde"),
    ("keycloak", "Keycloak"), ("onelogin", "OneLogin"), ("duo", "Duo Security"), ("onepassword", "1Password"),
    ("bitwarden", "Bitwarden"), ("vault", "HashiCorp Vault"), ("doppler", "Doppler"), ("infisical", "Infisical")], risk="high")
_bulk("Maps & Location", [("googlemaps", "Google Maps"), ("mapbox", "Mapbox"), ("here", "HERE"), ("radar", "Radar"),
    ("geocodio", "Geocodio")])
# the remaining named entries from the priority-100 list (so every ranked slot exists)
_bulk("Code & Repos", [("github_actions", "GitHub Actions")])
_bulk("Databases", [("upstash", "Upstash Redis"), ("firestore", "Firestore")], risk="high")
_bulk("LLMs · BYOK", [("lmstudio", "LM Studio")])
_bulk("Vector & Search", [("chroma", "Chroma"), ("opensearch", "OpenSearch")])
_bulk("Browser & QA", [("playwright", "Playwright"), ("browserbase", "Browserbase"), ("browserless", "Browserless"),
    ("cypress", "Cypress"), ("puppeteer", "Puppeteer"), ("insomnia", "Insomnia"), ("k6", "k6 Load Testing"),
    ("lighthouse", "Lighthouse")])
_bulk("Auth & Security", [("entra", "Microsoft Entra ID"), ("cloudflare_zerotrust", "Cloudflare Zero Trust")], risk="high")
_bulk("Cloud & Hosting", [("cloudflare_workers", "Cloudflare Workers")])
# Phase-1 real OUTBOUND rail (opt-in, DRY-RUN by default): signup webhook -> append a row to YOUR
# Google Sheet via an Apps Script Web App URL (no OAuth). The single-op workflow Nick QAs.
INTEGRATIONS_SEED["Webhooks & Events"] += [
    _ig("google_sheet", "Google Sheets · signup→sheet (Apps Script)", ["SHEET_WEBHOOK_URL"], risk="medium",
        rw="write", workflows=["signup_to_sheet"], docs="https://developers.google.com/apps-script/guides/web")]

# Importance ranking (Pat's priority-100). Lower = more important; everything else sorts after at 999.
INTEGRATION_RANK = {
    "openai": 1, "anthropic": 2, "groq": 3, "gemini": 4, "github": 5, "github_actions": 6, "stripe": 7,
    "postgres": 8, "supabase": 9, "render": 10, "vercel": 11, "slack": 12, "discord": 13, "telegram": 14,
    "microsoft": 15, "google": 16, "sentry": 17, "betterstack": 18, "uptimerobot": 19, "notion": 20,
    "gitlab": 21, "bitbucket": 22, "linear": 23, "jira": 24, "confluence": 25, "msteams": 26, "email": 27,
    "sendgrid": 28, "postmark": 29, "resend": 30, "twilio": 31, "aws": 32, "gcp": 33, "azure": 34,
    "digitalocean": 35, "netlify": 36, "railway": 37, "fly": 38, "dockerhub": 39, "kubernetes": 40,
    "neon": 41, "planetscale": 42, "mysql": 43, "mongodb": 44, "redis": 45, "upstash": 46, "firebase": 47,
    "firestore": 48, "dynamodb": 49, "r2": 50, "s3": 51, "gcs": 52, "azureblob": 53, "cloudflare_workers": 54,
    "cloudflare": 55, "ollama": 56, "lmstudio": 57, "mistral": 58, "cohere": 59, "perplexity": 60, "xai": 61,
    "together": 62, "fireworks": 63, "replicate": 64, "huggingface": 65, "pinecone": 66, "qdrant": 67,
    "weaviate": 68, "chroma": 69, "elasticsearch": 70, "opensearch": 71, "playwright": 72, "browserbase": 73,
    "browserless": 74, "cypress": 75, "puppeteer": 76, "postman": 77, "insomnia": 78, "k6": 79, "lighthouse": 80,
    "onepassword": 81, "doppler": 82, "vault": 83, "infisical": 84, "tailscale": 85, "cloudflare_zerotrust": 86,
    "okta": 87, "auth0": 88, "clerk": 89, "entra": 90, "posthog": 91, "segment": 92, "mixpanel": 93,
    "hubspot": 94, "salesforce": 95, "intercom": 96, "zendesk": 97, "zapier": 98, "make": 99, "n8n": 100,
}

# Providers with a REAL safe read-only test today. DB (needs a driver) and OAuth (needs a consent flow)
# are honestly excluded; everything else is TEST_NOT_IMPLEMENTED.
REAL_TESTS = {
    "github", "github_actions", "openai", "anthropic", "groq", "gemini", "xai", "mistral", "deepseek",
    "together", "fireworks", "openrouter", "cohere", "huggingface", "replicate", "notion", "cloudflare",
    "gitlab", "stripe", "supabase", "telegram", "slack", "discord", "twilio", "linear", "uptimerobot",
    "microsoft", "render", "vercel", "netlify", "sentry", "betterstack", "digitalocean", "sendgrid",
    "hubspot", "airtable",
}
DRYRUN_SEND = {"slack", "discord", "telegram"}

# Terminal-native manuals for the first-20 providers. (name, placeholder, where-to-find) per key.
MAN = {
 "openai": {"desc": "Code generation, error explanation, docs, structured outputs, embeddings/search.",
   "req": [("OPENAI_API_KEY", "sk-...", "platform.openai.com → API keys")],
   "opt": [("OPENAI_ORG_ID", "org-...", ""), ("OPENAI_PROJECT_ID", "proj_...", ""), ("DEFAULT_OPENAI_MODEL", "gpt-4o-mini", "")],
   "can": ["Generate code", "Explain errors", "Produce docs", "Structured outputs", "Embeddings / search"],
   "danger": ["High spend if uncontrolled"],
   "flows": ["Generate README", "Explain test failure", "Draft architecture docs", "Convert terminal log to issue"]},
 "anthropic": {"desc": "Long-context reasoning, architecture review, codebase planning, large-document analysis.",
   "req": [("ANTHROPIC_API_KEY", "sk-ant-...", "console.anthropic.com → API keys")],
   "opt": [("DEFAULT_ANTHROPIC_MODEL", "claude-...", "")],
   "can": ["Long-context reasoning", "Architecture review", "Codebase planning", "Large document analysis"],
   "danger": ["High spend on very large contexts"],
   "flows": ["Architecture critique", "Plan implementation", "Review agent output", "Generate test strategy"]},
 "groq": {"desc": "Fast audit, red-team passes, low-latency suggestions, quick classification.",
   "req": [("GROQ_API_KEY", "gsk_...", "console.groq.com → API Keys")], "opt": [("GROQ_MODEL", "llama-3.3-70b-versatile", "")],
   "can": ["Fast audit", "Red-team pass", "Low-latency suggestions", "Quick classification"],
   "danger": [], "flows": ["Audit latest build", "Classify QA blocker", "Generate action queue"]},
 "gemini": {"desc": "Multimodal review, long-context review, Google-ecosystem assist.",
   "req": [("GEMINI_API_KEY", "AIza...", "aistudio.google.com → API key")], "opt": [],
   "can": ["Multimodal review", "Long-context review", "Google ecosystem assist"],
   "danger": [], "flows": ["Review screenshot", "Summarize docs", "Compare architecture options"]},
 "github": {"desc": "Read repo metadata, branches, issues/PRs (write only if explicitly enabled), attach commits to receipts.",
   "req": [("GITHUB_TOKEN", "ghp_...", "github.com → Settings → Developer settings → Tokens"), ("GITHUB_OWNER", "your-org", ""), ("GITHUB_REPO", "your-repo", "")],
   "opt": [("GITHUB_DEFAULT_BRANCH", "main", "")],
   "can": ["Read repo metadata", "List branches", "Create issue (if write enabled)", "Open PR (if write enabled)", "Attach commits to receipts"],
   "danger": ["Create issues / PRs", "Push commits (only if write enabled)"],
   "flows": ["Create issue from failed audit", "Open PR from session", "Summarize branch", "Attach receipt to commit"]},
 "github_actions": {"desc": "Read CI/workflow status, show results, trigger only if explicitly enabled later.",
   "req": [("GITHUB_TOKEN", "ghp_...", "GitHub → Tokens (repo + workflow scope)"), ("GITHUB_OWNER", "your-org", ""), ("GITHUB_REPO", "your-repo", "")],
   "opt": [], "can": ["Read workflow status", "Show CI result", "Trigger workflow (only if enabled later)"],
   "danger": ["Trigger workflow runs (disabled in v0)"], "flows": ["Check CI after build", "Attach CI status to QA ledger"]},
 "stripe": {"desc": "Checkout, payments, subscriptions, webhooks, entitlements.",
   "req": [("STRIPE_SECRET_KEY", "sk_live_...", "Dashboard → Developers → API keys → Secret key")],
   "opt": [("STRIPE_WEBHOOK_SECRET", "whsec_...", "Dashboard → Developers → Webhooks → Signing secret"),
           ("STRIPE_PRICE_ID", "price_...", ""), ("STRIPE_PRODUCT_ID", "prod_...", ""), ("STRIPE_SUCCESS_URL", "", ""), ("STRIPE_CANCEL_URL", "", "")],
   "can": ["Check live/test mode", "Inspect recent payments", "Verify webhook delivery", "Verify customer entitlement", "Attach payment proof to QA ledger"],
   "danger": ["Refund payment", "Modify subscription", "Create price", "Edit webhook"],
   "flows": ["Verify payment loop", "Diagnose localhost redirect", "Inspect webhook failures", "Generate payment incident report"]},
 "postgres": {"desc": "Read-only SQL: SELECT 1, schema introspection, verify rows, safe read queries.",
   "req": [("DATABASE_URL", "postgres://user:pass@host:5432/db", "your DB provider")], "opt": [("POSTGRES_SSLMODE", "require", "")],
   "can": ["SELECT 1", "Read schema", "Verify rows", "Run safe read-only queries"],
   "danger": ["INSERT", "UPDATE", "DELETE", "DROP", "migrations"],
   "flows": ["Verify key was created", "Check orphaned payments", "Inspect schema", "Export read-only QA evidence"]},
 "supabase": {"desc": "Read tables, check auth/storage, inspect edge-function status.",
   "req": [("SUPABASE_URL", "https://xxx.supabase.co", "Project → Settings → API"), ("SUPABASE_ANON_KEY", "eyJ...", "Project → Settings → API")],
   "opt": [("SUPABASE_SERVICE_ROLE_KEY", "eyJ... (HIGH RISK)", "Project → Settings → API")],
   "can": ["Read tables", "Check auth / storage", "Inspect edge function status"],
   "danger": ["Service-role key bypasses RLS — full read/write"],
   "flows": ["Verify customer row", "Check storage bucket", "Inspect auth users"]},
 "render": {"desc": "Read deploy status, service health, deploy logs.",
   "req": [("RENDER_API_KEY", "rnd_...", "Render → Account Settings → API Keys"), ("RENDER_SERVICE_ID", "srv-...", "Service → Settings")], "opt": [],
   "can": ["Read deploy status", "Check service health", "View deploy logs"],
   "danger": ["Env var edits", "Service restarts", "Deploy triggers"],
   "flows": ["Check latest deploy", "Diagnose failed service", "Confirm production health"]},
 "vercel": {"desc": "Read deploys, preview links, production status.",
   "req": [("VERCEL_TOKEN", "...", "Vercel → Settings → Tokens"), ("VERCEL_PROJECT_ID", "prj_...", "Project → Settings")], "opt": [("VERCEL_TEAM_ID", "team_...", "")],
   "can": ["Read deploys", "Preview links", "Production status"], "danger": ["Trigger deploys (disabled in v0)"],
   "flows": ["Attach preview link to session", "Check frontend deploy"]},
 "slack": {"desc": "Send build alerts, QA blocker reports, summaries. DRY-RUN by default — never sends without confirm.",
   "req": [("SLACK_BOT_TOKEN", "xoxb-...  (or SLACK_WEBHOOK_URL)", "api.slack.com/apps → OAuth")], "opt": [("SLACK_DEFAULT_CHANNEL", "#alerts", "")],
   "can": ["Send build alerts", "Send QA blocker reports", "Post summaries"], "danger": ["Posts to channels (DRY-RUN until confirmed)"],
   "flows": ["Send audit summary", "Notify team of blocker"]},
 "discord": {"desc": "Send build alerts, QA reports, community notifications. DRY-RUN by default.",
   "req": [("DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/...  (or DISCORD_BOT_TOKEN)", "Server → Integrations → Webhooks")], "opt": [("DISCORD_CHANNEL_ID", "", "")],
   "can": ["Send build alerts", "Send QA reports", "Community notifications"], "danger": ["Posts to channels (DRY-RUN until confirmed)"],
   "flows": ["Post build result", "Notify human QA blocker"]},
 "telegram": {"desc": "Mobile alerts, approval pings, QA blocker notifications. DRY-RUN by default.",
   "req": [("TELEGRAM_BOT_TOKEN", "123:ABC...", "@BotFather"), ("TELEGRAM_CHAT_ID", "-100...", "@userinfobot")], "opt": [],
   "can": ["Mobile alerts", "Approval pings", "QA blocker notifications"], "danger": ["Sends messages (DRY-RUN until confirmed)"],
   "flows": ["Send urgent P0 blocker", "Send deploy status"]},
 "microsoft": {"desc": "Microsoft Graph — OneDrive, SharePoint, Teams, Outlook, Word/Excel.",
   "req": [("MICROSOFT_TENANT_ID", "...", "Entra → App registrations"), ("MICROSOFT_CLIENT_ID", "...", "Entra → App registrations"), ("MICROSOFT_CLIENT_SECRET", "...", "Entra → Certificates & secrets")],
   "opt": [("MICROSOFT_GRAPH_SCOPES", "Files.Read Sites.Read.All", "")],
   "can": ["OneDrive", "SharePoint", "Teams", "Outlook", "Word / Excel docs"], "danger": ["Broad tenant access depending on scopes"],
   "flows": ["Export QA report to Word", "Search SharePoint docs", "Post Teams update"]},
 "google": {"desc": "Google Drive / Docs — export docs, read project docs, attach artifacts.",
   "req": [("GOOGLE_CLIENT_ID", "...apps.googleusercontent.com", "console.cloud.google.com → Credentials"), ("GOOGLE_CLIENT_SECRET", "...", "console.cloud.google.com → Credentials")],
   "opt": [("GOOGLE_DRIVE_FOLDER_ID", "", "")],
   "can": ["Export docs", "Read project docs", "Attach artifacts"], "danger": ["Drive write depending on scopes"],
   "flows": ["Export session summary", "Save audit report", "Import requirements doc"]},
 "sentry": {"desc": "Read errors, list releases, attach issues to sessions.",
   "req": [("SENTRY_AUTH_TOKEN", "...", "Sentry → Settings → Auth Tokens"), ("SENTRY_ORG", "your-org", ""), ("SENTRY_PROJECT", "your-project", "")], "opt": [],
   "can": ["Read errors", "List releases", "Attach issues to sessions"], "danger": [],
   "flows": ["Check latest production errors", "Link crash to build"]},
 "betterstack": {"desc": "Uptime, incidents, logs, heartbeats.",
   "req": [("BETTERSTACK_API_KEY", "...", "Better Stack → API tokens")], "opt": [("BETTERSTACK_HEARTBEAT_URL", "", "")],
   "can": ["Uptime", "Incidents", "Logs", "Heartbeats"], "danger": [],
   "flows": ["Check production uptime", "Attach incident to QA ledger"]},
 "uptimerobot": {"desc": "Uptime monitor status, response time, outage detection.",
   "req": [("UPTIMEROBOT_API_KEY", "u...", "UptimeRobot → My Settings → API")], "opt": [],
   "can": ["Uptime monitor status", "Response time", "Outage detection"], "danger": [],
   "flows": ["Check health endpoint monitor", "Attach uptime evidence"]},
 "notion": {"desc": "Create docs, export summaries, read project specs.",
   "req": [("NOTION_API_KEY", "secret_...", "notion.so/my-integrations")], "opt": [("NOTION_DATABASE_ID", "", "")],
   "can": ["Create docs", "Export summaries", "Read project specs"], "danger": ["Writes pages (Airlock-gated)"],
   "flows": ["Export session notes", "Create spec from workflow", "Save QA checklist"],
   "why": ["Export session notes + QA checklists", "Turn a workflow into a spec doc", "Read project specs into context"]},
 "google_sheet": {
   "desc": "Append rows to a Google Sheet via an Apps Script Web App URL — no OAuth required. "
           "The first real outbound rail in RailCall. DRY-RUN by default; live only with explicit opt-in.",
   "req": [("SHEET_WEBHOOK_URL",
            "https://script.google.com/macros/s/…/exec",
            "Google Sheets → Extensions → Apps Script → Deploy → Web App → copy the /exec URL")],
   "opt": [("SHEET_NAME", "Signups", "The tab name in your sheet (default: Signups)")],
   "can": ["Append a signup row (time · email · name · source)", "DRY-RUN preview without writing",
           "Real outbound write on explicit opt-in", "Full receipt + audit on every run"],
   "danger": ["Appends rows to a real spreadsheet (write action — cross the Approval Airlock)",
              "Share URL is credential-equivalent — anyone with it can write to your sheet"],
   "flows": ["signup_to_sheet", "customer event → sheet row", "QA evidence export → sheet"],
   "why": ["Land every customer signup in a real Google Sheet with zero backend code",
           "Build a live evidence trail alongside your product flow",
           "Let Nick verify the whole governed pipeline end-to-end"],
   "trouble": ["Apps Script not deployed as Web App (must be 'Anyone' access)",
               "Copied the /edit URL instead of the /exec URL",
               "Apps Script not saved before deploying",
               "Sheet tab name mismatch (default is 'Signups')",
               "URL works but row format is wrong — check the Apps Script console"]},
}

# Per-category manuals so EVERY provider has a useful terminal-native page — not just a name.
# why / can(capabilities) / danger / flows(workflows) / trouble(troubleshooting). MAN[id] overrides.
CAT_TEMPLATES = {
 "llm": {"why": ["Generate code, docs, and structured outputs", "Explain errors and failed tests",
        "Summarize logs and sessions", "Draft plans and architecture"],
   "can": ["Generate code", "Explain errors", "Summarize logs", "Write docs", "Classify failures", "Generate workflow specs"],
   "danger": ["Spend on uncontrolled usage", "Data exposure if you send sensitive context", "Model output is non-deterministic"],
   "flows": ["Explain a test failure", "Generate a README", "Audit a plan", "Summarize a session", "Draft architecture"],
   "trouble": ["Key missing or empty", "Key rejected (401) — wrong or revoked key", "Rate limited (429)",
        "Wrong base URL for a proxy / self-host", "Model name not available to your account"]},
 "vector": {"why": ["Semantic memory + retrieval for agents", "Power RAG over your own docs", "Find similar issues / logs"],
   "can": ["Upsert + query vectors", "Similarity search", "Inspect index stats"],
   "danger": ["Index writes (Airlock-gated)", "Cost on large upserts", "Data exposure of embedded content"],
   "flows": ["Build a knowledge index", "Retrieve context for a build", "Find duplicate incidents"],
   "trouble": ["Key rejected (401)", "Wrong environment / index name", "Dimension mismatch on upsert", "Region/host typo"]},
 "code": {"why": ["Read repo + CI state into context", "Open issues / PRs from a session", "Attach receipts to commits"],
   "can": ["Read repo metadata", "List branches", "Read CI status", "Create issue (if write enabled)", "Open PR (if write enabled)"],
   "danger": ["Push code", "Merge PR", "Delete branch", "Trigger workflow runs"],
   "flows": ["Create issue from a failed audit", "Open PR from a session", "Summarize a branch", "Check CI after a build"],
   "trouble": ["Token missing required scope", "Token rejected (401)", "Wrong owner / repo / project", "Org SSO not authorized for the token"]},
 "cloud": {"why": ["Read deploy + service health into context", "Inspect logs", "Link a preview URL to a session"],
   "can": ["Read service status", "Read deploys", "Read logs", "Inspect health", "Link preview URL"],
   "danger": ["Deploy", "Restart service", "Edit env vars", "Delete service"],
   "flows": ["Check the latest deploy", "Diagnose a failed service", "Confirm production health", "Attach a preview link"],
   "trouble": ["Token rejected (401/403)", "Wrong service / project / team id", "Region mismatch", "Token lacks read scope"]},
 "database": {"why": ["Verify rows + schema as QA evidence", "Run safe read-only queries", "Confirm a record was created"],
   "can": ["SELECT 1", "Read schema", "Inspect tables", "Verify rows", "Export read-only evidence"],
   "danger": ["INSERT", "UPDATE", "DELETE", "DROP", "migrations"],
   "flows": ["Verify a key was created", "Check orphaned records", "Inspect schema", "Export read-only QA evidence"],
   "trouble": ["Bad DATABASE_URL / host / port", "Auth failed — wrong user/password", "SSL required but not set",
        "Live test needs a DB driver (not bundled in v0)"]},
 "payments": {"why": ["Verify the payment loop end-to-end", "Inspect webhook delivery", "Attach payment proof to QA",
        "Diagnose failed checkout / redirect issues"],
   "can": ["Check live/test mode", "Inspect recent payments", "Verify webhook delivery", "Verify customer entitlement", "Attach payment proof"],
   "danger": ["Refund payment", "Cancel subscription", "Modify price", "Edit webhook"],
   "flows": ["Verify payment loop", "Diagnose localhost redirect", "Inspect webhook failures", "Generate payment incident report"],
   "trouble": ["Key missing", "Test key used against a live flow", "Webhook secret mismatch", "Reused an old checkout session", "Success URL points to localhost"]},
 "comms": {"why": ["Send build alerts + QA blockers (DRY-RUN by default)", "Post audit summaries", "Approval pings"],
   "can": ["Send build alerts", "Post QA blocker", "Post audit summary", "Post deploy status"],
   "danger": ["Send an external message", "Spam a channel", "Expose secrets in a message"],
   "flows": ["Send an audit summary", "Notify the team of a blocker", "Send a deploy status"],
   "trouble": ["Bot token vs webhook URL mismatch", "Token rejected (401)", "Bot not in the channel", "Missing scope (chat:write)", "Wrong chat / channel id"]},
 "crm": {"why": ["Sync records into context", "Read pipeline / people data", "Attach CRM evidence to QA"],
   "can": ["Read records", "Sync contacts / deals", "Read pipeline state"],
   "danger": ["Create / update records", "Delete records", "Change owners"],
   "flows": ["Sync contacts", "Read recent deals", "Generate a pipeline summary"],
   "trouble": ["Token rejected (401)", "Missing scope for the object", "Wrong subdomain / instance url", "API version mismatch"]},
 "docs": {"why": ["Export session summaries + QA reports", "Read requirements / specs into context", "Create handoffs"],
   "can": ["Export docs", "Read requirements", "Save a QA report", "Create a handoff", "Attach artifacts"],
   "danger": ["Write / overwrite docs", "Share private docs", "Change permissions"],
   "flows": ["Export a session summary", "Save an audit report", "Import a requirements doc"],
   "trouble": ["Token rejected (401)", "OAuth consent not granted", "Wrong workspace / database / folder id", "Missing share with the integration"]},
 "monitoring": {"why": ["Read incidents + uptime into context", "Attach outage proof to QA", "Check production health"],
   "can": ["Read incidents", "Check uptime", "Read errors", "Attach outage proof"],
   "danger": ["Mute alerts", "Delete a monitor", "Change alert routing"],
   "flows": ["Check production uptime", "Link a crash to a build", "Attach an incident to the QA ledger"],
   "trouble": ["Token rejected (401)", "Wrong org / project", "API key lacks read scope", "Rate limited"]},
 "analytics": {"why": ["Read product + funnel data into context", "Attach metrics to a report", "Track build events"],
   "can": ["Read events / funnels", "Read reports", "Track an event (if write enabled)"],
   "danger": ["Write events", "Change tracking plan", "Expose user data"],
   "flows": ["Read a funnel", "Pull a usage report", "Generate a metrics summary"],
   "trouble": ["Key rejected (401)", "Wrong project / property id", "Write key used for a read", "Rate limited"]},
 "ecommerce": {"why": ["Read orders + inventory into context", "Verify fulfillment state", "Attach order evidence to QA"],
   "can": ["Read orders", "Read inventory", "Read fulfillment status"],
   "danger": ["Update inventory", "Cancel / refund orders", "Edit products"],
   "flows": ["Read recent orders", "Verify an order", "Generate an order incident report"],
   "trouble": ["Token rejected (401)", "Wrong store / domain", "Missing API scope", "API version mismatch"]},
 "support": {"why": ["Read tickets + conversations into context", "Attach support evidence to QA", "Summarize an issue"],
   "can": ["Read tickets", "Read conversations", "Summarize an issue"],
   "danger": ["Reply to a customer", "Close / merge tickets", "Change assignment"],
   "flows": ["Read open tickets", "Summarize a conversation", "Link a ticket to a build"],
   "trouble": ["Token rejected (401)", "Wrong subdomain", "Missing scope", "Rate limited"]},
 "security": {"why": ["Validate auth / secret config", "Read users / sessions into context", "Verify token scopes"],
   "can": ["Read users / sessions", "Verify token", "Read config (read-only)"],
   "danger": ["Modify users", "Rotate / revoke secrets", "Change access policies"],
   "flows": ["Verify a token", "List users", "Audit access config"],
   "trouble": ["Token rejected (401)", "Wrong domain / tenant", "Insufficient scope", "Expired credential"]},
 "automation": {"why": ["Trigger governed events to/from other tools", "Receive payloads into a workflow", "Bridge long-tail apps"],
   "can": ["Receive a payload (webhook_in)", "Trigger an outbound event (Airlock-gated)"],
   "danger": ["Fire external automations", "Loop / spam triggers"],
   "flows": ["Ingest an event into a workflow", "Post a governed event on approval"],
   "trouble": ["Wrong webhook URL / path", "Missing signature / token", "Payload too large", "Loopback vs tunnel confusion"]},
 "qa": {"why": ["Drive browser checks + screenshots", "Run E2E / load tests as proof", "Validate links + performance"],
   "can": ["Run a browser check", "Capture a screenshot", "Run an API / load test"],
   "danger": ["Hit production endpoints under load", "Submit forms against live systems"],
   "flows": ["Screenshot a page", "Run a link check", "Run a smoke test"],
   "trouble": ["Token rejected (401)", "Browser session limit reached", "Target URL unreachable", "Timeouts on slow pages"]},
 "maps": {"why": ["Geocode + reverse-geocode addresses", "Validate location data", "Attach geo evidence"],
   "can": ["Geocode an address", "Reverse-geocode coordinates", "Validate a place"],
   "danger": ["Billable lookups at volume"],
   "flows": ["Geocode a batch", "Validate addresses"],
   "trouble": ["Key rejected (401/403)", "Referrer / IP restriction on the key", "Quota exceeded", "Billing not enabled"]},
 "scheduling": {"why": ["Read bookings + availability into context", "Confirm a meeting was scheduled", "Attach scheduling evidence to QA"],
   "can": ["Read scheduled events", "Check availability", "Read attendee details", "Confirm a booking", "List upcoming meetings"],
   "danger": ["Book / reschedule a meeting", "Cancel a booking", "Change availability rules"],
   "flows": ["Confirm a booking was created", "Read upcoming meetings", "Check availability for a slot"],
   "trouble": ["Token rejected (401)", "Wrong organization / event-type slug", "Missing scope for bookings", "Timezone mismatch"]},
 "esign": {"why": ["Track signature-request status into context", "Confirm a document was signed", "Attach a signed-agreement proof to QA"],
   "can": ["Read signature-request status", "Check who has signed", "Download a completed document", "Verify a signed agreement"],
   "danger": ["Send a signature request", "Void / cancel an envelope", "Resend / remind signers"],
   "flows": ["Confirm a contract was signed", "Check signature-request status", "Verify a signed agreement"],
   "trouble": ["Token rejected (401)", "Wrong account / template id", "Envelope not found", "Signer email mismatch"]},
 "featureflag": {"why": ["Read flag + experiment state into context", "Confirm a rollout targeting", "Attach flag config to QA"],
   "can": ["Read flag states", "Check a flag for a user/segment", "Read experiment results", "Read targeting rules"],
   "danger": ["Toggle a flag", "Change targeting / rollout %", "Start / stop an experiment"],
   "flows": ["Check whether a flag is on for a segment", "Read a rollout's targeting", "Read an experiment result"],
   "trouble": ["SDK/API key rejected (401)", "Wrong project / environment", "Flag key not found", "Read vs write key mismatch"]},
 "generic": {"why": ["Connect this tool with your own key (stored locally, 0600)", "Bring its data into a governed workflow",
        "Attach its output as QA proof"],
   "can": ["Connect with your key (local, 0600)", "Read data into a workflow (per-connector, wiring in progress)"],
   "danger": ["Write actions cross the Approval Airlock"],
   "flows": ["Read data into a workflow", "Attach output as proof"],
   "trouble": ["Key missing or empty", "Key rejected (401) — wrong or revoked key", "Endpoint / account id typo", "Live test not wired yet for this provider"]},
}


# Providers whose correct manual template can't be inferred from their (shared) category:
#   - e-sign tools live in "Scheduling & E-sign" alongside calendars → route by id to the esign template
#   - feature-flag / experimentation tools live in "Marketing & Analytics" → route by id to featureflag
_TMPL_ID_OVERRIDE = {
    "docusign": "esign", "pandadoc": "esign", "hellosign": "esign", "signnow": "esign", "adobesign": "esign",
    "launchdarkly": "featureflag", "statsig": "featureflag", "optimizely": "featureflag", "flagsmith": "featureflag",
}


def _tmpl_key(cat, iid=None):
    if iid and iid in _TMPL_ID_OVERRIDE:
        return _TMPL_ID_OVERRIDE[iid]
    c = (cat or "").lower()
    for needle, key in [("llm", "llm"), ("ai ·", "llm"), ("voice", "llm"), ("vector", "vector"),
                        ("code", "code"), ("devops", "code"), ("cloud", "cloud"), ("storage", "cloud"), ("cdn", "cloud"),
                        ("database", "database"), ("payment", "payments"), ("finance", "payments"),
                        ("comm", "comms"), ("messaging", "comms"), ("email", "comms"),
                        ("crm", "crm"), ("sales", "crm"), ("hr", "crm"), ("people", "crm"),
                        # scheduling/e-sign get dedicated templates (no longer the wrong 'docs' bucket); e-sign
                        # ids are caught by _TMPL_ID_OVERRIDE above, so the category 'scheduling' → scheduling.
                        ("scheduling", "scheduling"), ("e-sign", "scheduling"),
                        ("docs", "docs"), ("workspace", "docs"), ("form", "docs"),
                        ("monitor", "monitoring"), ("observ", "monitoring"), ("analytic", "analytics"), ("marketing", "analytics"), (" bi", "analytics"),
                        ("commerce", "ecommerce"), ("logistic", "ecommerce"), ("support", "support"), ("chat", "support"),
                        ("auth", "security"), ("security", "security"), ("webhook", "automation"), ("event", "automation"),
                        ("browser", "qa"), ("qa", "qa"), ("map", "maps"), ("location", "maps")]:
        if needle in c:
            return key
    return "generic"


def integration_audit(etype, data):
    """Append-only integration audit (.railcall_workspace/integration_audit.jsonl). NEVER logs secret values."""
    rec = {"time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "type": etype}
    rec.update(data or {})
    os.makedirs(WS, exist_ok=True)
    with open(os.path.join(WS, "integration_audit.jsonl"), "a", encoding="utf-8") as f:
        f.write(json.dumps(rec) + "\n")


def integration_manual(iid):
    """Full terminal-native manual for one provider: rich for the first-20, generic template otherwise.
    Status uses only the allowed vocabulary; secret VALUES are never returned."""
    meta = None
    for cat, items in jload(os.path.join(WS, "integrations.json"), {}).items():
        for it in (items if isinstance(items, list) else []):
            if it.get("id") == iid:
                meta = dict(it, category=cat)
                break
        if meta:
            break
    if not meta:
        return None
    stored = jload(os.path.join(WS, "keys.local.json"), {}).get(iid)
    def keyrow(t, secret=True):
        nm = t[0] if isinstance(t, (tuple, list)) else t
        ph = t[1] if isinstance(t, (tuple, list)) and len(t) > 1 else ""
        wh = t[2] if isinstance(t, (tuple, list)) and len(t) > 2 else ""
        present = bool(stored) and (nm in stored if isinstance(stored, dict) else True)
        return {"name": nm, "placeholder": ph, "where": wh, "present": present, "secret": secret}
    m = MAN.get(iid)
    tmpl = CAT_TEMPLATES.get(_tmpl_key(meta.get("category"), iid), CAT_TEMPLATES["generic"])
    if m:
        req = [keyrow(t) for t in m["req"]]
        opt = [keyrow(t) for t in m["opt"]]
        desc = m["desc"]
        can = m.get("can") or tmpl["can"]
        danger = m.get("danger", tmpl["danger"])
        flows = m.get("flows") or tmpl["flows"]
        why = m.get("why") or tmpl["why"]
        trouble = m.get("trouble") or tmpl["trouble"]
    else:
        req = [keyrow((k, "", "")) for k in meta.get("required", [])]
        opt = [keyrow((k, "", "")) for k in meta.get("optional", [])]
        nm_ = str(meta.get("name", iid))
        desc = meta.get("hint") or ("%s — connect it with your own key, stored locally (0600). "
                                    "Read-only by default; per-connector actions wire in incrementally." % nm_)
        can, danger, flows, why, trouble = tmpl["can"], tmpl["danger"], (meta.get("workflows") or tmpl["flows"]), tmpl["why"], tmpl["trouble"]
    # derived fields
    where = [k["name"] + " — " + k["where"] for k in req if k.get("where")]
    if not where:
        where = [(meta.get("docs") or "see the provider's API documentation")]
    primary = req[0]["name"] if req else "the API key"
    where0 = (" (" + req[0]["where"] + ")") if (req and req[0].get("where")) else ""
    setup = ["Open " + str(meta.get("name", iid)) + ".",
             "Create / copy " + primary + where0 + ".",
             "Paste it into " + primary + " below.",
             "Save — it stays local (0600), masked.",
             "Run `railcall test " + iid + "`."]
    impl = iid in REAL_TESTS
    method = ("real read-only API call" if impl
              else ("needs a DB driver (v0)" if iid in NO_DRIVER
                    else ("needs an OAuth consent flow" if iid in OAUTH_FLOW else "TEST_NOT_IMPLEMENTED")))
    test_conn = {"implemented": impl, "safe": True, "method": method,
                 "expected_success": "TESTED — key validated read-only" if impl else "",
                 "common_failures": trouble[:4]}
    test_beh = ("real read-only key check" if impl
                else ("connection test needs a DB driver (v0)" if iid in NO_DRIVER
                      else ("OAuth — needs a consent flow" if iid in OAUTH_FLOW else "TEST_NOT_IMPLEMENTED")))
    aud, ap = [], os.path.join(WS, "integration_audit.jsonl")   # recent events for this provider (no secret values)
    if os.path.exists(ap):
        for ln in open(ap, encoding="utf-8").read().splitlines():
            try:
                e = json.loads(ln)
            except Exception:
                continue
            if e.get("provider") == iid:
                aud.append({"time": e.get("time", ""), "type": e.get("type"), "result": e.get("result")})
    return {"id": iid, "name": meta.get("name"), "category": meta.get("category"),
            "audit_events": aud[-6:][::-1], "danger_level": str(meta.get("risk", "")).upper(),
            "status": str(meta.get("status", "not_configured")).upper(),
            "risk": str(meta.get("risk", "")).upper(), "access": meta.get("read_write", "read"),
            "description": desc, "why_connect": why,
            "required_keys": req, "optional_keys": opt, "where_to_get_keys": where, "setup_steps": setup,
            "capabilities": can, "dangerous_actions": danger, "suggested_workflows": flows, "troubleshooting": trouble,
            "commands": ["railcall connect " + iid, "railcall test " + iid, "railcall docs " + iid, "railcall workflows " + iid],
            "test_connection": test_conn, "test_behavior": test_beh,
            "last_test": meta.get("last_tested"), "secret_present": bool(stored),
            "docs": meta.get("docs", ""), "rank": INTEGRATION_RANK.get(iid, 999), "has_manual": bool(m)}


def jload(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def jsave(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)
    os.replace(tmp, path)   # atomic: never leaves a half-written state file behind


def save_secret(path, obj):
    """Atomic write + lock to owner-only (0600). The BYOK vault must not be readable by other processes."""
    jsave(path, obj)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def audit_log(event, data):
    """Append-only ledger of build/audit events (.railcall_workspace/audit_log.jsonl)."""
    rec = {"at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "event": event}
    rec.update(data or {})
    os.makedirs(WS, exist_ok=True)
    with open(os.path.join(WS, "audit_log.jsonl"), "a", encoding="utf-8") as f:
        f.write(json.dumps(rec) + "\n")


# Real states the airlock actually emits — the Monitor binds counters to THESE, never an invented taxonomy.
MONITOR_STATES = ["pending_approval", "approved_not_executed", "executed",
                  "blocked_by_policy", "failed_safely", "failed_with_receipt"]


def monitor_feed(limit=60):
    """Read-only tail of the real .railcall_workspace/audit_log.jsonl + counters over its REAL
    state vocabulary. No fabrication: every row is a past, signed ledger event; external is always
    false (this is a local file read, it never touches the network)."""
    lp = os.path.join(WS, "audit_log.jsonl")
    rows = []
    if os.path.exists(lp):
        for line in open(lp, encoding="utf-8").read().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                pass
    by_state = {s: 0 for s in MONITOR_STATES}
    by_kind = {}
    for r in rows:
        s = r.get("status") or r.get("result_status")
        if s in by_state:
            by_state[s] += 1
        k = r.get("event") or "event"
        by_kind[k] = by_kind.get(k, 0) + 1
    tail = []
    for r in rows[-limit:][::-1]:   # newest first
        tail.append({
            "at": r.get("at", ""),
            "event": r.get("event", "event"),
            "label": (r.get("command") or r.get("workflow") or r.get("integration")
                      or r.get("file") or r.get("id") or r.get("summary") or r.get("slot") or ""),
            "status": r.get("status") or r.get("result_status") or r.get("result") or "",
        })
    return {"total": len(rows), "by_state": by_state, "by_kind": by_kind,
            "events": tail, "external": False, "source": ".railcall_workspace/audit_log.jsonl"}


# ── Phase 6a: BYOK multi-model ROLE router (Layer B). Bind + LOCAL preflight only.
# Key NAMES never values; zero network calls in 6a (live provider ping is 6b).
LLM_PROVIDERS = ["anthropic", "openai", "groq", "gemini", "xai"]
ROUTER_ROLES = ["compose", "sweep", "audit"]
ROLE_DESC = {
    "compose": "plain-English -> workflow/UI recipe assembled from the audited library",
    "sweep":   "read-only deep scan across high-volume local files",
    "audit":   "fast JSON/schema validation + receipt parsing",
}


def _router_path():
    return os.path.join(WS, "role_bindings.json")


def router_state():
    """Layer-B bindings + honest states. Returns key NAMES only, never secrets. No network."""
    b = jload(_router_path(), {})
    vault = jload(os.path.join(WS, "keys.local.json"), {})
    bindable = [p for p in LLM_PROVIDERS if p in vault and vault.get(p)]
    roles = []
    for r in ROUTER_ROLES:
        bd = b.get(r, {})
        kid = bd.get("key_id") or ""
        if kid and kid in vault and vault.get(kid):
            state = bd.get("state", "bound")          # 6a only ever persists "bound"
        else:
            kid, state = "", "unbound"                # key vanished out-of-band -> honestly unbound
        roles.append({"role": r, "desc": ROLE_DESC[r], "key_id": kid, "state": state})
    return {"roles": roles, "bindable": bindable, "all_providers": LLM_PROVIDERS,
            "deterministic_floor": True, "external": False}


# ── Phase 6b: the Layer-B execution router. Unbound -> deterministic-local floor (ZERO network).
# Bound + opt_in -> BYOK provider call (STUBBED here; live call wires in 6c). Delegates to the
# FROZEN engine modules, never edits them.
def _sweep_floor(payload):
    """Deterministic local file scan — pure-local, zero network."""
    f = (payload or {}).get("file", "")
    path = f if os.path.isabs(f) else os.path.join(ROOT, f)
    if not f or not os.path.isfile(path):
        return {"ok": False, "error": "file not found (loopback-local read only)", "kind": "deterministic_scan"}
    rows, cols = 0, 0
    with open(path, encoding="utf-8", errors="replace") as fh:
        for i, line in enumerate(fh):
            if i == 0:
                cols = len(line.rstrip("\n").split(","))
            if line.strip():
                rows += 1
    return {"ok": True, "file": f, "rows": rows, "cols": cols, "kind": "deterministic_scan"}


def _audit_floor(payload):
    """Deterministic local integrity recompute of a provided receipt — pure-local, zero network."""
    rcpt = (payload or {}).get("receipt") or {}
    claimed = rcpt.get("integrity_root") or rcpt.get("integrity") or ""
    body = {k: v for k, v in rcpt.items() if k not in ("integrity_root", "integrity")}
    recomputed = "sha256:" + hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()
    return {"ok": True, "claimed": claimed, "recomputed": recomputed,
            "matches": bool(claimed) and claimed == recomputed, "kind": "deterministic_recompute"}


def _compose_floor(payload):
    """Deterministic local COMPILE of a provided spec (compile_spec is clock-free + pure-local).
    NOTE: free-text NL->spec needs Layer-A/BYOK reasoning — that step is NOT part of this network-free floor."""
    spec = (payload or {}).get("spec")
    stamp = (payload or {}).get("stamp") or "1970-01-01T00:00:00Z"
    if not spec:
        # User-facing, actionable (no internal jargon like "NL->spec / Layer-A/BYOK / local floor"): turning a
        # free-text description into a workflow needs a model. Tell them what to do, not how the router is layered.
        return {"ok": False, "needs": "Building from a description needs a model — pick one in the “build with” "
                "dropdown and paste its key in INTEGRATIONS, or start from a structured spec.",
                "kind": "deterministic_compile"}
    res = compose_engine.compile_spec(spec, ROOT, os.path.join(ROOT, "builds"),
                                      os.path.join(ROOT, "tests"), stamp)
    r = res["receipt"]
    return {"ok": True, "name": spec.get("name"), "result": r.get("result"),
            "integrity": r.get("integrity_root"), "kind": "deterministic_compile"}


_FLOORS = {"compose": _compose_floor, "sweep": _sweep_floor, "audit": _audit_floor}


def route(role, payload, opt_in=False, provider=None):
    """Phase 6b/6c execution router. Returns (result, meta). meta.external is False unless a BYOK call fires.
      unbound (default)            -> deterministic-local floor (pure-local, zero network)
      compose + opt_in + provider  -> explicit per-build model (the Builder's "build with" dropdown)
      compose + opt_in + bound     -> the ROUTER-bound model"""
    if role not in ROUTER_ROLES:
        return {"ok": False, "error": "unknown role"}, {"path": "error", "role": role, "external": False}
    vault = jload(os.path.join(WS, "keys.local.json"), {})
    if role == "compose" and opt_in and provider and vault.get(provider):
        return _compose_byok(payload, provider, vault[provider])   # explicit per-build model override
    binding = jload(_router_path(), {}).get(role) or {}
    kid = binding.get("key_id") or ""
    bound = bool(kid) and kid in vault and bool(vault.get(kid))
    if bound and opt_in and role == "compose":
        return _compose_byok(payload, kid, vault[kid])      # Layer-B: the user's key -> the provider, bounded to treasury
    return (_FLOORS[role](payload),
            {"path": "local_floor", "role": role, "bound": bound, "opted_in": bool(opt_in), "external": False})


# ── Phase 6c: BYOK Compose (Layer B). The user's key reaches ONLY their provider (no hidden proxy,
# unlike Layer A); it is the Authorization header for one call and is NEVER stored/logged/receipted.
# OpenAI-compatible providers only for now; anthropic/gemini use distinct APIs -> honest refusal.
BYOK_PROVIDERS = {
    "groq":   {"url": "https://api.groq.com/openai/v1/chat/completions", "model": "llama-3.3-70b-versatile"},
    "openai": {"url": "https://api.openai.com/v1/chat/completions",      "model": "gpt-4o-mini"},
    "xai":    {"url": "https://api.x.ai/v1/chat/completions",            "model": "grok-2-latest"},
}


def _byok_raw(provider, key):
    """Return a raw-completion callable on the USER's key, straight to the provider (transparent — no proxy)."""
    cfg = BYOK_PROVIDERS.get(provider)
    def call(messages):
        if not cfg:
            return ""
        payload = {"model": os.environ.get("BYOK_MODEL", cfg["model"]),
                   "messages": messages, "temperature": 0.2, "max_tokens": 900}
        req = urllib.request.Request(cfg["url"], data=json.dumps(payload).encode(), method="POST",
                                     headers={"Content-Type": "application/json",
                                              "Authorization": "Bearer " + key,   # the user's key, only to the provider
                                              "User-Agent": "RailCall-Studio/0.1"})
        with urllib.request.urlopen(req, timeout=45) as r:
            return json.loads(r.read().decode())["choices"][0]["message"]["content"]
    return call


def _emit_ui_receipt(spec, res, role, key_id, prompt, stamp):
    """railcall_ui_receipt.v0 — component provenance + WHO composed (role + key NAME, never the secret)."""
    r = res["receipt"]
    comps = [{"id": p.get("name"), "kind": p.get("kind"), "license": p.get("license"),
              "version": p.get("version"), "sha256": p.get("sha256")} for p in r.get("audited_pieces", [])]
    candidates = [u.get("label") for u in r.get("unaudited_steps", [])]   # non-treasury picks: flagged, never silently audited
    body = {"schema": "railcall_ui_receipt.v0", "ui_id": spec["name"], "from_workflow": spec["name"],
            "components": comps, "treasury_candidates": candidates,
            "role": role, "key_id": key_id, "prompt": (prompt or "")[:400],
            "license_clean": r.get("license_clean"), "result": r.get("result"),
            "external": True, "built_at": stamp, "workflow_integrity": r.get("integrity_root")}
    body["integrity_root"] = "sha256:" + hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()
    rel = os.path.join("tests", "ui_" + spec["name"] + "_receipt.json")
    with open(os.path.join(ROOT, rel), "w") as f:
        json.dump(body, f, indent=2)
    return {"path": rel, "components": comps, "treasury_candidates": candidates, "receipt": body}


def _compose_byok(payload, provider, key):
    """Layer-B BYOK compose: user's key -> provider -> spec (bounded to the treasury by compose_spec) ->
    compile -> railcall_ui_receipt.v0. Reuses the FROZEN engine; the bounding is inherent (compose_spec
    nulls any piece not in the audited list)."""
    if provider not in BYOK_PROVIDERS:
        return ({"ok": False, "error": "BYOK adapter for '%s' isn't wired yet — bind an OpenAI-compatible key "
                 "(groq/openai/xai)" % provider}, {"path": "byok_unsupported", "role": "compose", "external": False})
    messages = payload.get("messages") or []
    stamp = payload.get("stamp") or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    prompt = next((m.get("content", "") for m in reversed(messages) if m.get("role") == "user"), "")
    try:
        spec = compose_engine.compose_spec(messages, catalog(), _byok_raw(provider, key))
    except Exception as e:
        return ({"ok": False, "error": "the bound model call failed (%s) — retrying on the no-key build" % e,
                 "fellback": True}, {"path": "byok_failed", "role": "compose", "key_id": provider, "external": True})
    if not spec:
        return ({"ok": False, "error": "the bound model did not return a usable spec"},
                {"path": "byok", "role": "compose", "key_id": provider, "external": True})
    res = compose_engine.compile_spec(spec, ROOT, os.path.join(ROOT, "builds"), os.path.join(ROOT, "tests"), stamp)
    ui = _emit_ui_receipt(spec, res, "compose", provider, prompt, stamp)
    try:
        preview = render_ui_preview(spec, res)   # 6d: zero-CDN blueprint at /ui/<id>
    except Exception:
        preview = None
    return ({"ok": True, "name": spec["name"], "result": res["receipt"]["result"],
             "spec": spec, "receipt": res["receipt"],   # full shape so the Builder renders BYOK + local uniformly
             "components": [c["id"] for c in ui["components"]], "treasury_candidates": ui["treasury_candidates"],
             "ui_receipt": ui["path"], "preview": preview, "model": provider},
            {"path": "byok", "role": "compose", "key_id": provider, "external": True})


# ── Phase 6d: loopback UI preview. Render the governed build as a self-contained, zero-CDN HTML
# blueprint at builds/ui/<id>.html, served over loopback at /ui/<id>. A BLUEPRINT, not a deployed
# app — every panel is labeled with the audited component behind it. Renderer lives in the glue;
# compose_engine stays frozen.
def _esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


_UI_CSS = """*{box-sizing:border-box}body{margin:0;background:#02040a;color:#e8eef7;font:13px/1.55 ui-monospace,Menlo,monospace}
.bp{background:#0a0f16;border-bottom:1px solid #1e293b;padding:8px 16px;color:#8aa0b6;font-size:12px;letter-spacing:.02em}
.bp b{color:#a855f7}.bp .dry{color:#f5b54a}.wrap{max-width:1000px;margin:0 auto;padding:22px 18px}
.meta{color:#5b6b80;font-size:11px;margin:0 0 16px}
.canvas{border:1px solid #1e293b;border-radius:12px;background:#04070e;overflow:hidden}
.appbar{background:#0a0f16;border-bottom:1px solid #1e293b;padding:11px 16px;color:#cfe;font-size:14px;display:flex;align-items:center;gap:10px}
.appbar .dot{width:9px;height:9px;border-radius:99px;background:#a855f7;display:inline-block}
.main{padding:16px;display:flex;flex-direction:column;gap:14px}
.panel{border:1px solid #16202e;border-radius:10px;background:#050a12;padding:13px 14px}
.panel .h{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:10px}
.panel .lab{color:#e8eef7}.panel .kind{color:#5b6b80;font-size:10px;text-transform:uppercase;letter-spacing:.08em}
.cbadge{display:inline-block;font-size:10px;color:#06b6d4;border:1px solid #114250;background:#06141a;border-radius:99px;padding:2px 8px;white-space:nowrap}
.cbadge.warn{color:#f5b54a;border-color:#4a3a18;background:#16120a}
.field{height:30px;border:1px solid #1e293b;border-radius:6px;background:#0a0f16;margin-bottom:8px}
.btn{height:30px;border:1px solid #3b2a6a;border-radius:6px;background:#160f2a;color:#c4b5fd;display:inline-flex;align-items:center;padding:0 14px;font-size:12px}
.trow{height:26px;border:1px solid #16202e;border-radius:5px;background:#0a0f16;margin-bottom:6px}.trow.head{background:#11192a;border-color:#1e293b}
.tabs{display:flex;gap:6px}.tabs span{border:1px solid #1e293b;border-bottom:0;border-radius:6px 6px 0 0;padding:5px 12px;color:#8aa0b6;font-size:12px;background:#0a0f16}
.modal{border:1px dashed #3b2a6a;border-radius:8px;background:#0a0f16;color:#c4b5fd;padding:14px;text-align:center}
.cal{height:64px;border:1px solid #1e293b;border-radius:8px;background:#0a0f16}.ph{height:40px;border:1px dashed #1e293b;border-radius:8px;background:#070c14}
.prov{margin-top:18px;border:1px solid #1e293b;border-radius:10px;background:#050a12;padding:14px}
.prov .row{display:flex;justify-content:space-between;border-bottom:1px solid #0e1726;padding:6px 0}.prov .row:last-child{border-bottom:0}
.prov .k{color:#5b6b80}.prov .v{color:#8aa0b6;word-break:break-all}.pass{color:#22d3a5}.amber{color:#f5b54a}
.foot{color:#5b6b80;margin-top:16px;font-size:11px;line-height:1.6}"""


def _ui_block(label, piece, lic):
    p = (piece or "").lower()
    if any(k in p for k in ["form", "field", "input", "validated"]):
        kind, shape = "form", '<div class="field"></div><div class="field"></div><span class="btn">Submit</span>'
    elif any(k in p for k in ["table", "list", "batch", "row", "grid", "data"]):
        kind, shape = "table", '<div class="trow head"></div>' + '<div class="trow"></div>' * 3
    elif "tab" in p:
        kind, shape = "tabs", '<div class="tabs"><span>Tab</span><span>Tab</span><span>Tab</span></div>'
    elif any(k in p for k in ["dialog", "modal", "popover", "toast", "feedback", "alert"]):
        kind, shape = "overlay", '<div class="modal">action / confirmation</div>'
    elif any(k in p for k in ["date", "calendar", "schedule"]):
        kind, shape = "date", '<div class="cal"></div>'
    else:
        kind, shape = "panel", '<div class="ph"></div>'
    badge = ('<span class="cbadge">' + _esc(piece) + ' · ' + _esc(lic or "audited") + '</span>') if piece \
        else '<span class="cbadge warn">treasury candidate — needs audit</span>'
    return ('<div class="panel"><div class="h"><span class="lab">' + _esc(label) + '</span><span class="kind">'
            + kind + '</span></div>' + shape + '<div style="margin-top:9px">' + badge + '</div></div>')


def render_ui_preview(spec, result):
    """Self-contained zero-CDN HTML blueprint of the composed program's UI. Returns the /ui/<id> path."""
    r = result["receipt"]
    lic = {p.get("name"): p.get("license", "") for p in r.get("audited_pieces", [])}
    # a step is "audited" ONLY if its piece is actually in the result's audited set; otherwise it's a
    # treasury candidate (never badge a non-treasury piece as audited).
    panels = "".join(_ui_block(s.get("label", "section"),
                               (s.get("piece") if s.get("piece") in lic else None),
                               lic.get(s.get("piece"), ""))
                     for s in spec.get("steps", []))
    n_aud = len(r.get("audited_pieces", []))
    n_cand = len(r.get("unaudited_steps", []))
    res = r.get("result", "")
    rcls = "pass" if res == "PASS" else "amber"
    rows = "".join('<div class="row"><span class="k">' + k + '</span><span class="v ' + c + '">' + _esc(v) + '</span></div>'
                   for k, v, c in [
                       ("result", res, rcls),
                       ("audited components", str(n_aud), ""),
                       ("treasury candidates", str(n_cand), "amber" if n_cand else "pass"),
                       ("license clean", "yes" if r.get("license_clean") else "no", "pass" if r.get("license_clean") else "amber"),
                       ("external sockets", "0", "pass"),
                       ("build receipt", str(r.get("integrity_root", ""))[:34] + "…", ""),
                       ("built", str(r.get("built_at", "")), ""),
                   ])
    html = ("<!doctype html><html><head><meta charset=utf-8><title>" + _esc(spec.get("title", spec["name"]))
            + " · RailCall blueprint</title><style>" + _UI_CSS + "</style></head><body>"
            '<div class="bp"><b>RAILCALL // GOVERNED BLUEPRINT</b> · ' + _esc(spec.get("title", spec["name"]))
            + ' · <span class="dry">DRY-RUN · not a deployed app</span></div><div class="wrap">'
            '<div class="meta">composed from the pre-coded audited library · ' + str(n_aud)
            + ' audited components · external 0 · loopback only</div>'
            '<div class="canvas"><div class="appbar"><span class="dot"></span>' + _esc(spec.get("title", spec["name"]))
            + '</div><div class="main">' + (panels or '<div class="ph"></div>') + '</div></div>'
            '<div class="prov">' + rows + '</div>'
            '<p class="foot">This is a <b>governed blueprint</b> — a verified spec + UI bounded to audited, '
            'license-clean components and signed by a build receipt you can recompute. It is <b>not</b> a running '
            'deployed app: wiring the components into a live app is the next layer. Zero CDN · loopback only.</p>'
            '</div></body></html>')
    d = os.path.join(ROOT, "builds", "ui")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, spec["name"] + ".html"), "w", encoding="utf-8") as f:
        f.write(html)
    return "/ui/" + spec["name"]


def seed_workspace():
    os.makedirs(WS, exist_ok=True)
    try:
        os.chmod(WS, 0o700)   # workspace (incl. the BYOK vault) is owner-only at the OS level
    except OSError:
        pass
    kp = os.path.join(WS, "keys.local.json")
    if os.path.exists(kp):
        try:
            os.chmod(kp, 0o600)
        except OSError:
            pass
    if not os.path.exists(os.path.join(WS, "workspace.json")):
        jsave(os.path.join(WS, "workspace.json"),
              {"workspace_name": os.path.basename(ROOT), "version": "0.1", "active_session": "s1"})
    if not os.path.exists(os.path.join(WS, "sessions.json")):
        jsave(os.path.join(WS, "sessions.json"),
              [{"id": "s1", "name": "Lead routing v1", "status": "working", "folder": "builds/",
                "note": "4 nodes · 0 sockets · revisit Q3 conversions", "updated": time.time()}])
    if not os.path.exists(os.path.join(WS, "folder_notes.json")):
        jsave(os.path.join(WS, "folder_notes.json"),
              {"builds": "Generated dashboards, receipts & artifacts.",
               "tests": "Signed QA / airlock proof receipts.",
               "fixtures": "Source data for workflows.",
               "workbench": "The Studio kit itself."})
    if not os.path.exists(os.path.join(WS, "generated_links.json")):
        jsave(os.path.join(WS, "generated_links.json"),
              [{"label": "Health endpoint", "url": GATEWAY + "/health"},
               {"label": "Success page", "url": GATEWAY + "/success.html"}])
    # integration metadata DB — refresh metadata from the seed each boot, PRESERVE status + last_tested by id.
    # BUT reconcile against the vault: a persisted "tested"/"key_present" with NO key in keys.local.json is
    # STALE (key cleared/rotated out-of-band) and must NOT survive — it would make the picker advertise a
    # BYOK build with no key (fake green). Downgrade any such status to not_configured on boot. NO FAKE GREEN.
    ipath = os.path.join(WS, "integrations.json")
    cur = jload(ipath, {})
    vault = jload(os.path.join(WS, "keys.local.json"), {})
    prev = {x.get("id"): x for items in cur.values() if isinstance(items, list) for x in items}
    out = {}
    for cat, items in INTEGRATIONS_SEED.items():
        out[cat] = []
        for it in items:
            p = prev.get(it["id"], {})
            status = p.get("status", "not_configured")
            if status in ("tested", "key_present") and not vault.get(it["id"]):
                status = "not_configured"   # reconcile stale status to the vault truth
            out[cat].append(dict(it, status=status, last_tested=p.get("last_tested")))
    jsave(ipath, out)
    jsave(os.path.join(WS, "commands.json"), cmdreg.COMMANDS)   # inspectable command registry on disk


def fetch_balance():
    tok = jload(TOKEN, {})
    key = tok.get("api_key")
    cache = os.path.join(WS, "_balance_cache.json")
    if not key:
        return {"status": "UNKNOWN", "reason": "no api_key — run: railcall login <key>"}
    try:
        req = urllib.request.Request(f"{GATEWAY}/v1/balance?api_key={key}", headers={"User-Agent": "railcall-studio"})
        with urllib.request.urlopen(req, timeout=8) as r:
            d = json.loads(r.read().decode())
        res = {"status": "OK", "runs": d.get("runs_remaining"), "tier": d.get("tier"), "at": time.time()}
        jsave(cache, res)
        return res
    except Exception as e:
        c = jload(cache, None)
        if c:
            mins = int((time.time() - c.get("at", 0)) / 60)
            return {"status": "CACHED", "runs": c.get("runs"), "tier": c.get("tier"), "checked_min_ago": mins}
        return {"status": "UNKNOWN", "reason": f"gateway unreachable ({type(e).__name__})"}


def audit_state():
    fs = sorted(glob.glob(os.path.join(ROOT, "tests", "workflow_*receipt*.json")), key=os.path.getmtime)
    out = {"latest_build": "UNKNOWN", "external_sockets": "UNKNOWN", "integrity_root": None, "human_qa": "UNKNOWN"}
    if fs:
        d = jload(fs[-1], {})
        out["latest_build"] = d.get("result", "UNKNOWN")
        net = d.get("network") or {}
        out["external_sockets"] = net.get("sockets_opened_during_execution", "UNKNOWN")
        out["integrity_root"] = d.get("integrity_root")
    out["human_qa"] = "VERIFIED" if os.path.exists(os.path.join(ROOT, "builds", "human_qa_signoff.json")) else "UNKNOWN"
    return out


def _pick(key, *fields):
    """Pull a usable secret string from a key that is a str or a {FIELD: value} dict.
    When specific `fields` are named, require one of them — never guess another
    vault field (prevents the wrong secret being sent as a credential)."""
    if isinstance(key, str):
        return key
    if isinstance(key, dict):
        for f in fields:
            if key.get(f):
                return str(key[f])
        if not fields:                      # single unknown-name case only
            for v in key.values():
                if isinstance(v, str) and v:
                    return v
    return ""


def _probe(url, headers=None, method="GET", data=None, timeout=12, want=None):
    """One SAFE read-only HTTP call. 2xx (and `want` substring, if given) -> tested; 401/403 -> key rejected."""
    try:
        req = urllib.request.Request(url, data=data, method=method,
                                     headers=dict(headers or {}, **{"User-Agent": "RailCall-Studio/0.1"}))
        with urllib.request.urlopen(req, timeout=timeout) as r:
            if want is not None and want not in r.read(6000).decode("utf-8", "replace"):
                return "failed", "reached, but the key was not accepted"
            return "tested", "HTTP %d · key valid" % r.status
    except Exception as e:
        code = getattr(e, "code", None)
        if code in (401, 403):
            return "failed", "HTTP %d · key rejected" % code
        return "failed", ("HTTP %d" % code) if code else str(e)[:90]


# Single-key Bearer GET probes — read-only validation (mostly /models, /user, /account).
_BEARER = {
    "openai": "https://api.openai.com/v1/models", "groq": "https://api.groq.com/openai/v1/models",
    "xai": "https://api.x.ai/v1/models", "mistral": "https://api.mistral.ai/v1/models",
    "deepseek": "https://api.deepseek.com/models", "together": "https://api.together.xyz/v1/models",
    "fireworks": "https://api.fireworks.ai/inference/v1/models", "openrouter": "https://openrouter.ai/api/v1/key",
    "cohere": "https://api.cohere.com/v1/models", "huggingface": "https://huggingface.co/api/whoami-v2",
    "render": "https://api.render.com/v1/services?limit=1", "vercel": "https://api.vercel.com/v2/user",
    "netlify": "https://api.netlify.com/api/v1/user", "sentry": "https://sentry.io/api/0/organizations/",
    "betterstack": "https://uptime.betterstack.com/api/v2/monitors", "digitalocean": "https://api.digitalocean.com/v2/account",
    "sendgrid": "https://api.sendgrid.com/v3/scopes", "hubspot": "https://api.hubapi.com/account-info/v3/details",
    "airtable": "https://api.airtable.com/v0/meta/whoami",
}
NO_DRIVER = {"postgres", "mysql", "mongodb", "redis", "snowflake", "clickhouse", "planetscale", "neon", "cockroachdb"}
OAUTH_FLOW = {"google", "gcp"}


def test_integration(iid, key):
    """SAFE read-only connection test. Real validation where wired; honest FAILED / TEST_NOT_IMPLEMENTED otherwise.
    Never writes, never sends, never logs the secret value."""
    if not key:
        return "not_configured", "no key saved"
    # ---- multi-field / non-Bearer providers ----
    if iid in ("github", "github_actions"):
        c = key if isinstance(key, dict) else {"GITHUB_TOKEN": key}
        tok, owner, repo = c.get("GITHUB_TOKEN"), c.get("GITHUB_OWNER"), c.get("GITHUB_REPO")
        if not (tok and owner and repo):
            return "not_configured", "missing token / owner / repo"
        suffix = "/actions/workflows" if iid == "github_actions" else ""
        return _probe("https://api.github.com/repos/%s/%s%s" % (owner, repo, suffix),
                      {"Authorization": "Bearer " + tok, "Accept": "application/vnd.github+json"})
    if iid == "anthropic":
        return _probe("https://api.anthropic.com/v1/models", {"x-api-key": _pick(key), "anthropic-version": "2023-06-01"})
    if iid == "gemini":
        return _probe("https://generativelanguage.googleapis.com/v1beta/models?key=" + _pick(key), {})
    if iid == "replicate":
        return _probe("https://api.replicate.com/v1/account", {"Authorization": "Token " + _pick(key)})
    if iid == "notion":
        return _probe("https://api.notion.com/v1/users/me", {"Authorization": "Bearer " + _pick(key), "Notion-Version": "2022-06-28"})
    if iid == "cloudflare":
        return _probe("https://api.cloudflare.com/client/v4/user/tokens/verify", {"Authorization": "Bearer " + _pick(key)}, want='"success":true')
    if iid == "gitlab":
        return _probe("https://gitlab.com/api/v4/user", {"PRIVATE-TOKEN": _pick(key, "GITLAB_TOKEN")})
    if iid == "stripe":
        sk = _pick(key, "STRIPE_SECRET_KEY")
        return _probe("https://api.stripe.com/v1/balance", {"Authorization": "Bearer " + sk}) if sk else ("not_configured", "missing STRIPE_SECRET_KEY")
    if iid == "supabase":
        url, ak = _pick(key, "SUPABASE_URL"), _pick(key, "SUPABASE_ANON_KEY")
        if not (url and ak):
            return "not_configured", "missing url / anon key"
        return _probe(url.rstrip("/") + "/rest/v1/", {"apikey": ak, "Authorization": "Bearer " + ak})
    if iid == "telegram":
        tok = _pick(key, "TELEGRAM_BOT_TOKEN")
        return _probe("https://api.telegram.org/bot%s/getMe" % tok, {}, want='"ok":true') if tok else ("not_configured", "missing bot token")
    if iid == "slack":
        tok = _pick(key, "SLACK_BOT_TOKEN")
        if not tok or not tok.startswith("xox"):
            return "key_present", "webhook URL saved · a read-only token check needs a bot token (xoxb-)"
        return _probe("https://slack.com/api/auth.test", {"Authorization": "Bearer " + tok}, method="POST", want='"ok":true')
    if iid == "discord":
        tok = _pick(key, "DISCORD_BOT_TOKEN")
        if not tok or tok.startswith("http"):
            return "key_present", "webhook URL saved · a read-only check needs a bot token"
        return _probe("https://discord.com/api/v10/users/@me", {"Authorization": "Bot " + tok})
    if iid == "twilio":
        import base64
        sid, tok = _pick(key, "TWILIO_SID"), _pick(key, "TWILIO_TOKEN")
        if not (sid and tok):
            return "not_configured", "missing SID / token"
        auth = base64.b64encode(("%s:%s" % (sid, tok)).encode()).decode()
        return _probe("https://api.twilio.com/2010-04-01/Accounts/%s.json" % sid, {"Authorization": "Basic " + auth})
    if iid == "linear":
        return _probe("https://api.linear.app/graphql", {"Authorization": _pick(key, "LINEAR_API_KEY"), "Content-Type": "application/json"},
                      method="POST", data=b'{"query":"{ viewer { id } }"}', want='"viewer"')
    if iid == "uptimerobot":
        return _probe("https://api.uptimerobot.com/v2/getMonitors", {"Content-Type": "application/x-www-form-urlencoded"},
                      method="POST", data=("api_key=%s&format=json&limit=1" % _pick(key)).encode(), want='"stat":"ok"')
    if iid == "microsoft":
        tid, cid, sec = _pick(key, "MICROSOFT_TENANT_ID"), _pick(key, "MICROSOFT_CLIENT_ID"), _pick(key, "MICROSOFT_CLIENT_SECRET")
        if not (tid and cid and sec):
            return "not_configured", "missing tenant / client id / secret"
        from urllib.parse import quote
        data = ("client_id=%s&client_secret=%s&grant_type=client_credentials&scope=%s"
                % (quote(cid), quote(sec), quote("https://graph.microsoft.com/.default"))).encode()
        return _probe("https://login.microsoftonline.com/%s/oauth2/v2.0/token" % tid,
                      {"Content-Type": "application/x-www-form-urlencoded"}, method="POST", data=data, want="access_token")
    if iid in NO_DRIVER:
        return "key_present", "credential saved · live connection test needs a DB driver (not bundled in v0)"
    if iid in OAUTH_FLOW:
        return "key_present", "OAuth provider · key check needs a consent flow (TEST_NOT_IMPLEMENTED)"
    # ---- single-key Bearer GET probes ----
    sec = _pick(key)
    if iid in _BEARER and sec:
        return _probe(_BEARER[iid], {"Authorization": "Bearer " + sec})
    return "key_present", "key saved locally · live read-only test for this provider isn't wired yet"


# ── signup_to_sheet: RailCall's FIRST real outbound rail ────────────────────────────────────────
# DRY-RUN by default (dry_run=True). Goes live only when: dry_run=False + SHEET_WEBHOOK_URL in vault.
# The URL is a Google Apps Script Web App — no OAuth. Never logs the URL value in audit events.

def _latest_webhook_payload(slot="webhook_in"):
    """Read the most recent raw payload from the webhook_in inbox. Returns dict or None."""
    ibx = os.path.join(WS, "webhook_inbox", slot)
    if not os.path.isdir(ibx):
        return None
    files = sorted(glob.glob(os.path.join(ibx, "*.json")), key=os.path.getmtime)
    if not files:
        return None
    try:
        return json.load(open(files[-1], encoding="utf-8"))
    except Exception:
        return None


def _format_signup_row(payload, stamp=None):
    """Extract a clean row from an inbound payload. Handles common signup shapes.
    Returns [time, email, name, source, json_summary] — never raises."""
    p = payload or {}
    body = p.get("body") or p  # some payloads nest under 'body'
    if isinstance(body, str):
        try:
            body = json.loads(body)
        except Exception:
            body = {}
    u = body.get("user") if isinstance(body, dict) else {}
    if not isinstance(u, dict):
        u = {}
    email = (body.get("email") or body.get("Email") or u.get("email", "")) if isinstance(body, dict) else ""
    name = (body.get("name") or body.get("Name") or u.get("name", "")) if isinstance(body, dict) else ""
    source = (body.get("source") or body.get("event") or body.get("type") or "railcall_webhook")
    ts = stamp or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    summary = json.dumps(body, separators=(",", ":"))[:200] if isinstance(body, dict) else str(body)[:200]
    return [ts, str(email), str(name), str(source), summary]


# NO FAKE GREEN: do NOT auto-follow redirects on an outbound send. An Apps Script /edit URL (the
# documented mistake) 302s to accounts.google.com — urllib's default opener would silently follow it
# to a 200 sign-in page and the send would read as SENT. We use a no-redirect opener so a 3xx is seen
# as a 3xx, and we also surface the final host so a redirect that DID land elsewhere is caught.
class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None   # never follow — the caller treats any 3xx as a blocked/failed send


def _post_no_redirect(url, data, headers, timeout=15):
    """POST without following redirects. Returns (status, final_host, body_2000).
    A 3xx comes back as its real status (not the followed 200). final_host is the host actually hit."""
    opener = urllib.request.build_opener(_NoRedirect)
    req = urllib.request.Request(url, data=data, method="POST", headers=headers)
    try:
        with opener.open(req, timeout=timeout) as r:
            body = r.read(2000).decode("utf-8", "replace")
            return r.status, (urllib.parse.urlparse(r.geturl()).hostname or ""), body
    except urllib.error.HTTPError as e:   # 3xx/4xx/5xx land here with the no-redirect handler
        try:
            body = e.read(2000).decode("utf-8", "replace")
        except Exception:
            body = ""
        loc = e.headers.get("Location", "") if e.headers else ""
        host = (urllib.parse.urlparse(loc).hostname or urllib.parse.urlparse(url).hostname or "")
        return e.code, host, body


# Hosts that mean the script never ran (Google auth wall) — any final/redirect host here is a blocked send.
_SEND_BLOCKED_HOSTS = ("accounts.google.com",)


def _verify_send(target, status, resp):
    """Per-target success verification so we never report SENT on a 2xx-with-error-body.
    Returns (result, sent) where result is one of SENT / SENT_UNVERIFIED / SEND_FAILED.
    NO FAKE GREEN: SENT requires a real per-target success signal, not just HTTP 2xx."""
    try:
        st = int(status)
    except Exception:
        st = 0
    if st >= 300:
        return "SEND_FAILED", 0
    body = (resp or "").strip()
    if target == "slack":
        # Slack incoming webhooks return literally 'ok' on success.
        return ("SENT", 1) if body == "ok" else ("SENT_UNVERIFIED", 0)
    if target == "discord":
        # Discord returns 204 (or 200) with empty/JSON body; a JSON error carries code/message.
        if st in (200, 204):
            try:
                j = json.loads(body) if body else None
            except Exception:
                j = None
            if isinstance(j, dict) and (j.get("code") or j.get("message")):
                return "SENT_UNVERIFIED", 0
            return "SENT", 1
        return "SENT_UNVERIFIED", 0
    try:
        j = json.loads(body) if body else None
    except Exception:
        j = None
    if isinstance(j, dict) and (j.get("ok") is False or j.get("error") or j.get("errors")):
        return "SENT_UNVERIFIED", 0
    if target == "sheet":
        # A Google Sheet row append must PROVE the row landed — a bare 200 (or empty/HTML/foreign body)
        # is NOT proof. The QA-guide doPost returns {"ok":true,"appended":true} after appendRow(); we
        # require that explicit marker. Without it: SENT_UNVERIFIED (sent=0), never a SENT we can't back.
        if isinstance(j, dict) and j.get("appended") is True:
            return "SENT", 1
        return "SENT_UNVERIFIED", 0
    # generic / make / zapier: any 2xx without an explicit failure marker is a successful POST.
    return "SENT", 1


def send_to_sheet(sheet_url, row, dry_run=True):
    """POST one row to a Google Apps Script Web App URL.
    dry_run=True  → compose + receipt, zero external call, sent:0.
    dry_run=False → real POST; raises on failure.
    NEVER logs the sheet_url value in audit events (treated as a write credential)."""
    row_data = {"time": row[0], "email": row[1], "name": row[2], "source": row[3], "raw": row[4]}
    receipt = {
        "schema": "railcall_sheet_send.v0", "dry_run": dry_run,
        "row": row_data, "sent": 0, "external_api_touched": False,
        "target": "SHEET_WEBHOOK_URL (local vault)", "result": "DRY_RUN",
    }
    if dry_run:
        return receipt
    data = json.dumps(row_data).encode("utf-8")
    try:
        # NO redirect-follow: a /edit URL 302s to accounts.google.com; we must SEE that 302/host, not
        # silently follow it to a 200 sign-in page and report SENT (the row was never appended).
        status, final_host, resp = _post_no_redirect(sheet_url, data,
                                                      {"Content-Type": "application/json",
                                                       "User-Agent": "RailCall-Studio/0.1"})
        # A redirect (any 3xx) OR a final/redirect host of accounts.google.com means the script never ran.
        if 300 <= int(status) < 400 or any(h in (final_host or "") for h in _SEND_BLOCKED_HOSTS) \
           or any(s in resp for s in ("accounts.google.com/ServiceLogin", "accounts.google.com/signin",
                                      "accounts.google.com/v3/signin", "ServiceLogin", "Sign in - Google Accounts")):
            receipt.update({"result": "SEND_BLOCKED", "http_status": status, "sent": 0,
                            "external_api_touched": True, "response_snippet": resp[:120],
                            "error": "the URL redirected to a Google sign-in (a /edit URL, not your /exec "
                                     "script) — set the Web App 'Who has access' to Anyone, copy the /exec "
                                     "URL, and redeploy (no row was appended)"})
            raise RuntimeError(receipt["error"])
        result, sent = _verify_send("sheet", status, resp)
        receipt.update({"sent": sent, "external_api_touched": True, "result": result,
                        "http_status": status, "response_snippet": resp[:120]})
        if result != "SENT":
            receipt["error"] = ("destination returned %s but no append confirmation "
                                "({\"ok\":true,\"appended\":true}) — no row confirmed" % status)
    except Exception as e:
        if receipt.get("result") != "SEND_BLOCKED":
            receipt.update({"result": "SEND_FAILED", "error": str(e)[:140]})
        e.receipt = receipt   # carry the honest failure receipt so the caller can surface it in /status
        raise
    return receipt


def run_signup_to_sheet(dry_run=True, payload_override=None):
    """Execute the signup→sheet workflow. Returns {ok, receipt, row, dry_run, error?}."""
    vault = jload(os.path.join(WS, "keys.local.json"), {})
    sheet_url_raw = vault.get("google_sheet")
    sheet_url = (_pick(sheet_url_raw, "SHEET_WEBHOOK_URL") if isinstance(sheet_url_raw, dict) else
                 (sheet_url_raw if isinstance(sheet_url_raw, str) else ""))
    if not sheet_url and not dry_run:
        return {"ok": False, "error": "SHEET_WEBHOOK_URL not saved — paste it in the google_sheet integration first."}
    payload = payload_override or _latest_webhook_payload()
    if not payload:
        payload = {"email": "test@example.com", "name": "Test User", "event": "customer.signup",
                   "_note": "demo row — no real webhook received yet"}
    stamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    row = None
    try:
        row = _format_signup_row(payload, stamp)
        rc = send_to_sheet(sheet_url or "DRY_RUN_NO_URL", row, dry_run=dry_run)
    except Exception as e:
        fail_rc = getattr(e, "receipt", None) or {"schema": "railcall_sheet_send.v0", "dry_run": dry_run,
                                                  "result": "SEND_FAILED", "sent": 0,
                                                  "external_api_touched": True, "error": str(e)[:140]}
        fres = fail_rc.get("result", "SEND_FAILED")   # SEND_BLOCKED or SEND_FAILED — the honest outcome
        # Emit a sheet_send event too (not only sheet_send_failed) so /status last_send reflects the
        # blocked/failed attempt and the UI badge turns red — a failed live send must NOT read as DRY_RUN.
        integration_audit("sheet_send", {"provider": "google_sheet", "dry_run": dry_run,
                                         "result": fres, "sent": 0,
                                         "external_api_touched": fail_rc.get("external_api_touched", True),
                                         "secret_value_logged": False})
        integration_audit("sheet_send_failed", {"provider": "google_sheet",
                                                "result": fres, "error": str(e)[:120],
                                                "secret_value_logged": False})
        audit_log("signup_to_sheet", {"dry_run": dry_run, "result": fres,
                                      "email": (row[1] if row else ""), "source": (row[3] if row else ""),
                                      "external_api_touched": fail_rc.get("external_api_touched", True)})
        return {"ok": False, "dry_run": dry_run, "row": row, "receipt": fail_rc, "error": str(e)[:140]}
    integration_audit("sheet_send", {"provider": "google_sheet", "dry_run": dry_run,
                                     "result": rc.get("result"), "sent": rc.get("sent", 0),
                                     "external_api_touched": rc.get("external_api_touched", False),
                                     "secret_value_logged": False})
    audit_log("signup_to_sheet", {"dry_run": dry_run, "result": rc.get("result"),
                                  "email": row[1], "source": row[3],
                                  "external_api_touched": rc.get("external_api_touched", False)})
    return {"ok": True, "dry_run": dry_run, "row": row, "receipt": rc}


# ── webhook_out: send a governed test event to ANY non-API webhook URL ───────────────────────────
# No API key, no OAuth — just a URL you paste (Slack/Discord/Sheet/generic; Make/Zapier catch-hooks use the generic shape).
# DRY-RUN by default; the URL is transient (never stored, never logged).
WEBHOOK_TARGETS = {
    "slack":   {"label": "Slack (incoming webhook)",  "shape": lambda m, t: {"text": m}},
    "discord": {"label": "Discord (webhook)",          "shape": lambda m, t: {"content": m}},
    "sheet":   {"label": "Google Sheet (Apps Script)", "shape": lambda m, t: {"time": t, "email": "", "name": "", "source": "railcall_test", "raw": m}},
    "generic": {"label": "Generic JSON",               "shape": lambda m, t: {"event": "railcall_test", "message": m, "time": t}},
}


def send_webhook(url, target, message, dry_run=True):
    """POST a shaped test payload to any webhook URL. dry_run=True → compose+receipt, zero network.
    Honest result: SENT / SEND_BLOCKED (Google sign-in page) / SEND_FAILED. Never logs the URL value."""
    tgt = target if target in WEBHOOK_TARGETS else "generic"
    stamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    payload = WEBHOOK_TARGETS[tgt]["shape"](message, stamp)
    receipt = {"schema": "railcall_webhook_out.v0", "target": tgt, "dry_run": dry_run,
               "payload": payload, "sent": 0, "external_api_touched": False, "result": "DRY_RUN"}
    if dry_run:
        return receipt
    data = json.dumps(payload).encode("utf-8")
    try:
        # No redirect-follow (same reason as send_to_sheet): a 3xx to a Google sign-in must read BLOCKED.
        status, final_host, resp = _post_no_redirect(url, data,
                                                      {"Content-Type": "application/json",
                                                       "User-Agent": "RailCall-Studio/0.1"})
        if 300 <= int(status) < 400 or any(h in (final_host or "") for h in _SEND_BLOCKED_HOSTS) \
           or any(s in resp for s in ("accounts.google.com/ServiceLogin", "accounts.google.com/signin",
                                      "accounts.google.com/v3/signin", "ServiceLogin", "Sign in - Google Accounts")):
            receipt.update({"result": "SEND_BLOCKED", "http_status": status, "sent": 0,
                            "external_api_touched": True, "response_snippet": resp[:120],
                            "error": "the URL redirected to a Google sign-in — set the Web App 'Who has access' to Anyone"})
            raise RuntimeError(receipt["error"])
        result, sent = _verify_send(tgt, status, resp)
        receipt.update({"sent": sent, "external_api_touched": True, "result": result,
                        "http_status": status, "response_snippet": resp[:120]})
        if result != "SENT":
            receipt["error"] = "destination returned %s but no %s success signal" % (status, tgt)
    except Exception as e:
        if receipt.get("result") != "SEND_BLOCKED":
            receipt.update({"result": "SEND_FAILED", "error": str(e)[:140]})
        e.receipt = receipt
        raise
    return receipt


def run_webhook_out(url, target, message=None, dry_run=True):
    """Tester entrypoint. URL is transient (from the request, never stored). Returns {ok, receipt, ...}."""
    msg = message or "RailCall test event ✓"
    try:
        rc = send_webhook(url or "DRY_RUN_NO_URL", target, msg, dry_run=dry_run)
    except Exception as e:
        rc = getattr(e, "receipt", None)
        integration_audit("webhook_out_failed", {"provider": "webhook_out", "target": target,
                                                 "result": (rc or {}).get("result", "failed"),
                                                 "secret_value_logged": False})
        audit_log("webhook_out", {"target": target, "dry_run": dry_run,
                                  "result": (rc or {}).get("result", "failed")})
        out = {"ok": False, "target": target, "dry_run": dry_run, "error": str(e)[:140]}
        if rc:
            out["receipt"] = rc
        return out
    integration_audit("webhook_out", {"provider": "webhook_out", "target": target, "dry_run": dry_run,
                                      "result": rc.get("result"), "secret_value_logged": False})
    audit_log("webhook_out", {"target": target, "dry_run": dry_run, "result": rc.get("result"),
                              "external_api_touched": rc.get("external_api_touched", False)})
    return {"ok": True, "target": target, "dry_run": dry_run, "receipt": rc}


def data_tables():
    """The 'developer database' view — metadata only, NEVER secret values."""
    sess = jload(os.path.join(WS, "sessions.json"), [])
    ints = jload(os.path.join(WS, "integrations.json"), {})
    wfs = []
    wdir = os.path.join(WS, "workflows")
    if os.path.isdir(wdir):
        for f in sorted(os.listdir(wdir)):
            if f.endswith(".json"):
                w = jload(os.path.join(wdir, f), {})
                wfs.append({"id": w.get("id") or os.path.splitext(f)[0], "status": w.get("status"), "steps": len(w.get("steps", [])),
                            "needs_audit": len(w.get("needs_audit", [])), "updated": w.get("updated")})
    arts = [{"path": "builds/" + os.path.basename(p), "type": "html", "bytes": os.path.getsize(p)}
            for p in sorted(glob.glob(os.path.join(ROOT, "builds", "*.html")))]
    key_names = list(jload(os.path.join(WS, "keys.local.json"), {}).keys())   # NAMES only, never values
    evs = []
    lp = os.path.join(WS, "audit_log.jsonl")
    if os.path.exists(lp):
        for line in open(lp, encoding="utf-8").read().splitlines()[-40:]:
            try:
                evs.append(json.loads(line))
            except Exception:
                pass
    return {
        "sessions": [{"id": s.get("id"), "name": s.get("name"), "status": s.get("status"),
                      "folder": s.get("folder"), "commands": len(s.get("commands", []))} for s in sess],
        "workflows": wfs,
        "artifacts": arts,
        "integrations": [{"id": it.get("id"), "category": cat, "status": it.get("status"),
                          "risk": it.get("risk"), "read_write": it.get("read_write"), "last_tested": it.get("last_tested")}
                         for cat, items in ints.items() for it in items],
        "keys_metadata": [{"integration": k, "stored": "local · 0600", "value": "••••••"} for k in key_names],
        "audit_events": list(reversed(evs)),
    }


def suggestions():
    """Next-best-actions derived from REAL workspace state — not generic AI fluff."""
    out = []
    a = audit_state()
    ints = jload(os.path.join(WS, "integrations.json"), {})
    flat = [it for items in ints.values() if isinstance(items, list) for it in items]
    if a.get("latest_build") in ("PARTIAL", "FAIL"):
        out.append({"id": "audit_latest", "title": "Audit the latest build",
                    "reason": "Latest build is %s — re-verify the receipt." % a["latest_build"],
                    "action_type": "command", "action": "build", "risk": "safe · local"})
    na = 0
    wdir = os.path.join(WS, "workflows")
    if os.path.isdir(wdir):
        for f in os.listdir(wdir):
            if f.endswith(".json"):
                na += len(jload(os.path.join(wdir, f), {}).get("needs_audit", []))
    if na:
        out.append({"id": "grow_business", "title": "Grow an audited component for unaudited steps",
                    "reason": "%d workflow step(s) have no audited piece yet." % na,
                    "action_type": "prompt", "action": "what audited component could cover my unaudited steps?",
                    "risk": "safe · local"})
    untested = [it for it in flat if it.get("status") == "key_present"]
    if untested:
        out.append({"id": "test_conn", "title": "Test a configured integration",
                    "reason": "%d integration(s) have a key saved but were never tested." % len(untested),
                    "action_type": "ui", "action": "Connect → Test connection", "risk": "safe · read-only"})
    if not any(it.get("status") in ("key_present", "tested") for it in flat):
        out.append({"id": "connect_one", "title": "Connect your first integration",
                    "reason": "No integrations configured yet — BYOK stays local.",
                    "action_type": "ui", "action": "open the Connect tab", "risk": "safe"})
    if a.get("human_qa") == "UNKNOWN" and a.get("latest_build") not in ("UNKNOWN", None):
        out.append({"id": "human_qa", "title": "Record human QA sign-off",
                    "reason": "Human QA is UNKNOWN for the latest build.",
                    "action_type": "ui", "action": "add builds/human_qa_signoff.json", "risk": "safe"})
    jsave(os.path.join(WS, "suggestions.json"), out)
    return out


# ---- Org API Command Registry v0: execution orchestration (governance-first) ----
def now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def receipts_index():
    """Both command receipts (.railcall_workspace/receipts/cmd_*.json) and workflow receipts (tests/)."""
    out = []
    rdir = os.path.join(WS, "receipts")
    if os.path.isdir(rdir):
        for f in sorted(os.listdir(rdir), reverse=True):
            if f.endswith(".json"):
                d = jload(os.path.join(rdir, f), {})
                out.append({"id": "cmd/" + f, "kind": "command", "status": d.get("result_status"),
                            "command": d.get("resolved_command_id"), "provider": d.get("provider"),
                            "external": d.get("external_api_touched"), "time": d.get("timestamp"),
                            "integrity": d.get("integrity_hash")})
    for p in sorted(glob.glob(os.path.join(ROOT, "tests", "workflow_*receipt*.json")), key=os.path.getmtime, reverse=True):
        d = jload(p, {})
        if str(d.get("schema", "")).startswith("railcall_workflow"):
            out.append({"id": "wf/" + os.path.basename(p), "kind": "workflow", "status": d.get("result"),
                        "command": d.get("workflow_id"), "provider": "railcall", "external": False,
                        "time": d.get("built_at"), "integrity": d.get("integrity_root")})
    # flow receipts: WS/flow_receipts/*.json (schema railcall_flow_receipt.v0)
    fdir = os.path.join(WS, "flow_receipts")
    if os.path.isdir(fdir):
        for f in sorted(os.listdir(fdir), reverse=True):
            if not f.endswith(".json"):
                continue
            d = jload(os.path.join(fdir, f), {})
            if str(d.get("schema", "")).startswith("railcall_flow_receipt"):
                out.append({"id": "flow/" + f, "kind": "flow",
                            "status": ("queued" if d.get("actions_queued") else "DRY_RUN"),
                            "command": d.get("workflow"), "provider": "railcall",
                            "external": d.get("external_api_touched", False),
                            "time": d.get("at"), "integrity": d.get("integrity")})
    # batch receipts: WS/batch_receipts/*.json (schema railcall_batch_receipt.v1)
    bdir = os.path.join(WS, "batch_receipts")
    if os.path.isdir(bdir):
        for f in sorted(os.listdir(bdir), reverse=True):
            if not f.endswith(".json"):
                continue
            d = jload(os.path.join(bdir, f), {})
            if str(d.get("schema", "")).startswith("railcall_batch_receipt"):
                out.append({"id": "batch/" + f, "kind": "batch",
                            "status": d.get("mode", "DRY_RUN"),
                            "command": d.get("workflow"), "provider": "railcall",
                            "external": d.get("external_api_touched", False),
                            "time": d.get("at"), "integrity": d.get("integrity")})
    return out


def read_receipt(rid):
    rid = str(rid or "")
    if rid.startswith("cmd/"):
        p = os.path.join(WS, "receipts", os.path.basename(rid[4:]))
    elif rid.startswith("wf/"):
        p = os.path.join(ROOT, "tests", os.path.basename(rid[3:]))
    elif rid.startswith("flow/"):
        p = os.path.join(WS, "flow_receipts", os.path.basename(rid[5:]))
    elif rid.startswith("batch/"):
        p = os.path.join(WS, "batch_receipts", os.path.basename(rid[6:]))
    else:
        return None
    return jload(p, None) if os.path.exists(p) else None


_RECEIPT_SEQ = [0]


def _persist_receipt(rc):
    # every attempt is durable + unique: ts + command + payload-hash prefix + status + a monotonic suffix,
    # and we loop until the name is free so rapid identical repeats never overwrite each other.
    ts = rc["timestamp"].replace(":", "").replace("-", "")
    cid = (rc.get("resolved_command_id") or "unknown").replace(".", "_")
    ph = (rc.get("payload_hash") or "nohash").replace("sha256:", "")[:8]
    st = rc.get("result_status", "unknown")
    rdir = os.path.join(WS, "receipts")
    os.makedirs(rdir, exist_ok=True)
    while True:
        _RECEIPT_SEQ[0] += 1
        fn = "cmd_%s_%s_%s_%s_%04d.json" % (ts, cid, ph, st, _RECEIPT_SEQ[0])
        if not os.path.exists(os.path.join(rdir, fn)):
            break
    jsave(os.path.join(WS, "receipts", fn), rc)
    audit_log("command", {"command": rc.get("resolved_command_id"), "status": rc.get("result_status"),
                          "external_api_touched": rc.get("external_api_touched")})
    return "cmd/" + fn


# local read-only handlers — the ONLY things v0 actually executes. Each returns (output_dict, artifact_or_None).
def _h_build(inputs, stamp):
    spec = compose_engine.compose_spec(inputs.get("messages", []), catalog(), groq_raw)
    if not spec:
        raise RuntimeError("could not compose a workflow from that conversation")
    res = compose_engine.compile_spec(spec, ROOT, os.path.join(ROOT, "builds"), os.path.join(ROOT, "tests"), stamp)
    return {"workflow": spec["name"], "result": res["receipt"]["result"]}, res["artifact"]


def _h_audit(inputs, stamp):
    p = subprocess.run([sys.executable, os.path.join(HERE, "audit_workflow.py")],
                       cwd=ROOT, capture_output=True, text=True, timeout=120)
    tail = [l for l in p.stdout.strip().splitlines() if l][-1:] if p.stdout else []
    return {"auditor_exit": p.returncode, "result": ("PASS" if p.returncode == 0 else "FAIL"),
            "summary": (tail[0] if tail else "")}, None


def _h_receipts(inputs, stamp):
    return {"receipts": receipts_index()}, None


def _h_set_status(inputs, stamp):
    """A governed LOCAL write — only reachable AFTER the Approval Airlock binds the human's approval."""
    sid, status = inputs.get("session_id"), inputs.get("status")
    sess = jload(os.path.join(WS, "sessions.json"), [])
    hit = False
    for s in sess:
        if s.get("id") == sid:
            s["status"] = status
            s["updated"] = time.time()
            hit = True
    if not hit:
        raise RuntimeError("no session %r" % sid)
    jsave(os.path.join(WS, "sessions.json"), sess)
    return {"ok": True, "session_id": sid, "status": status}, None


def _h_set_stage_map(inputs, stamp):
    """Governed LOCAL write — persist a stage_map INTO the workflow spec + build receipt, re-rendered via the
    SAME compile path so integrity_root is recomputed + sha-pinned. The mapping is then reusable on any future
    data with that vocabulary (flow runs read spec['stage_map'] -> source 'spec'). Reachable ONLY after the
    Approval Airlock binds the human's approval."""
    wf = inputs.get("workflow")
    sm = inputs.get("stage_map")
    if not wf or not isinstance(sm, dict):
        raise RuntimeError("need workflow + a stage_map object")
    rec = jload(os.path.join(ROOT, "tests", "workflow_" + wf + "_receipt.json"), {})
    spec = rec.get("spec")
    if not spec:
        raise RuntimeError("no built workflow %r" % wf)
    spec["stage_map"] = {str(k).strip().lower(): v for k, v in sm.items() if k}
    res = compose_engine.compile_spec(spec, ROOT, os.path.join(ROOT, "builds"), os.path.join(ROOT, "tests"), stamp)
    return {"ok": True, "workflow": wf, "stage_map_keys": sorted(spec["stage_map"].keys()),
            "integrity_root": res["receipt"]["integrity_root"]}, res["artifact"]


def _h_github_list_issues(inputs, stamp):
    """First real EXTERNAL read connector. Uses the BYOK github creds; reaches the GitHub API (read-only).
    A read needs no approval, but the receipt honestly records external_api_touched = true."""
    creds = jload(os.path.join(WS, "keys.local.json"), {}).get("github") or {}
    if isinstance(creds, str):
        creds = {"GITHUB_TOKEN": creds}
    tok, owner, repo = creds.get("GITHUB_TOKEN"), creds.get("GITHUB_OWNER"), creds.get("GITHUB_REPO")
    if not (tok and owner and repo):
        raise RuntimeError("missing GITHUB_TOKEN / GITHUB_OWNER / GITHUB_REPO")
    state = inputs.get("state") or "open"
    url = "https://api.github.com/repos/%s/%s/issues?state=%s&per_page=20" % (owner, repo, state)
    req = urllib.request.Request(url, headers={"Authorization": "Bearer " + tok,
                                               "User-Agent": "RailCall-Studio/0.1",
                                               "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=20) as r:
        data = json.loads(r.read().decode())
    issues = [{"number": i.get("number"), "title": i.get("title"), "state": i.get("state")}
              for i in data if isinstance(i, dict) and "pull_request" not in i][:20]
    return {"repo": "%s/%s" % (owner, repo), "count": len(issues), "issues": issues}, None


def _h_email_send(inputs, stamp):
    """Governed EXTERNAL write — reachable ONLY after the Approval Airlock binds a human approval to THIS exact payload.
    Sends a real email via the user's BYOK SMTP creds. Honors a DRY_RUN flag (cred or env) so the full
    approve->execute->receipt loop is provable WITHOUT transmitting. Never sends unless creds present AND dry-run off."""
    creds = jload(os.path.join(WS, "keys.local.json"), {}).get("email") or {}
    if not isinstance(creds, dict):
        raise RuntimeError("email creds must be SMTP fields, not a single key")
    to, subject, body = inputs.get("to"), inputs.get("subject"), inputs.get("body")
    if not (to and subject and body):
        raise RuntimeError("missing to / subject / body")
    dry = str(creds.get("DRY_RUN") or os.environ.get("RAILCALL_EMAIL_DRYRUN") or "").strip().lower() in ("1", "true", "yes", "on")
    if dry:
        return {"sent": False, "dry_run": True, "to": to, "subject": subject,
                "note": "DRY RUN — composed + approved + receipted, NOT transmitted"}, None
    host, sender = creds.get("SMTP_HOST"), creds.get("SMTP_FROM")
    user, pw = creds.get("SMTP_USER"), creds.get("SMTP_PASS")
    port = int(creds.get("SMTP_PORT") or 587)
    if not (host and sender and user and pw):
        raise RuntimeError("missing SMTP_HOST / SMTP_USER / SMTP_PASS / SMTP_FROM")
    import smtplib, ssl
    from email.message import EmailMessage
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = sender, to, subject
    msg.set_content(body)
    ctx = ssl.create_default_context()
    if port == 465:
        with smtplib.SMTP_SSL(host, port, timeout=30, context=ctx) as s:
            s.login(user, pw); s.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=30) as s:
            s.ehlo(); s.starttls(context=ctx); s.login(user, pw); s.send_message(msg)
    return {"sent": True, "to": to, "subject": subject, "transport": "smtp:%d" % port}, None


def _h_set_email_template(inputs, stamp):
    """Governed LOCAL write — persist an email_template INTO the workflow spec + build receipt (re-compiled,
    sha-pinned), so batch drafts use the user's own subject/body. Reachable only after the Approval Airlock."""
    wf = inputs.get("workflow")
    tmpl = inputs.get("email_template")
    if not wf or not isinstance(tmpl, dict):
        raise RuntimeError("need workflow + an email_template object")
    rec = jload(os.path.join(ROOT, "tests", "workflow_" + wf + "_receipt.json"), {})
    spec = rec.get("spec")
    if not spec:
        raise RuntimeError("no built workflow %r" % wf)
    spec["email_template"] = {"subject": str(tmpl.get("subject", "")), "body": str(tmpl.get("body", ""))}
    res = compose_engine.compile_spec(spec, ROOT, os.path.join(ROOT, "builds"), os.path.join(ROOT, "tests"), stamp)
    return {"ok": True, "workflow": wf, "integrity_root": res["receipt"]["integrity_root"]}, res["artifact"]


def _batch_load(inputs):
    """Resolve (spec, rows, sender) for a batch from {workflow, data}. Shared by preview (manifest) + execute."""
    wf, data = inputs.get("workflow"), inputs.get("data")
    spec = jload(os.path.join(ROOT, "tests", "workflow_" + str(wf) + "_receipt.json"), {}).get("spec") if wf else None
    if not spec:
        raise RuntimeError("no built workflow %r" % wf)
    fp, _w = _find_upload(os.path.basename(str(data or "")))
    if not fp:
        cand = os.path.join(ROOT, "fixtures", os.path.basename(str(data or "")))
        fp = cand if os.path.isfile(cand) else None
    if not fp:
        raise RuntimeError("data file not found: %s" % data)
    rows = flow_engine.rows_from_csv(open(fp, encoding="utf-8", errors="ignore").read())
    creds = jload(os.path.join(WS, "keys.local.json"), {}).get("email") or {}
    sender = (creds.get("SMTP_FROM") or creds.get("SMTP_USER")) if isinstance(creds, dict) else None
    return spec, rows, (sender or "ar@your-domain.example")


def _h_email_batch(inputs, stamp):
    """Governed DRY-RUN batch: compose N follow-up drafts from the workflow's template + data, write ONE batch
    receipt over the full manifest, send NOTHING. Reachable only after the Approval Airlock binds this payload."""
    spec, rows, sender = _batch_load(inputs)
    manifest, drafts = flow_engine.batch_manifest(spec, rows, sender)
    batch = {"schema": "railcall_batch_receipt.v1", "workflow": spec.get("name"),
             "data": os.path.basename(str(inputs.get("data"))), "at": stamp, "mode": "DRY_RUN",
             "sent": 0, "external_api_touched": False, "count": manifest["count"],
             "skipped": manifest.get("skipped", 0),
             "total_amount": manifest["total_amount"], "from": sender,
             "subject_template": manifest["subject_template"], "body_template": manifest["body_template"],
             "batch_hash": manifest["batch_hash"], "drafts": drafts,
             "note": ("N governed follow-up drafts composed from the workflow's template + approved as a SET; "
                      "DRY-RUN — nothing transmitted (sent=0, external_api_touched=false).")}
    batch["integrity"] = "sha256:" + hashlib.sha256(
        json.dumps({k: v for k, v in batch.items() if k != "integrity"}, sort_keys=True, default=str).encode()).hexdigest()
    os.makedirs(os.path.join(WS, "batch_receipts"), exist_ok=True)
    ref = "batch_%s_%s.json" % (spec.get("name"), re.sub(r"[^0-9]", "", stamp))
    jsave(os.path.join(WS, "batch_receipts", ref), batch)
    return {"sent": False, "dry_run": True, "count": manifest["count"], "skipped": manifest.get("skipped", 0),
            "total_amount": manifest["total_amount"], "batch_hash": manifest["batch_hash"], "batch_receipt": ref}, None


# wired command handlers. railcall.* are local (no external touch); github.*/email.* really reach the provider.
LOCAL_HANDLERS = {"workflow.build": _h_build, "workflow.audit": _h_audit, "receipts.list": _h_receipts,
                  "workspace.set_session_status": _h_set_status, "github.list_issues": _h_github_list_issues,
                  "email.send_followup": _h_email_send, "workflow.set_stage_map": _h_set_stage_map,
                  "workflow.set_email_template": _h_set_email_template, "email.send_batch": _h_email_batch}


def _pending():
    return jload(os.path.join(WS, "pending_approvals.json"), {})


def _pending_save(p):
    jsave(os.path.join(WS, "pending_approvals.json"), p)


def validate_command(cmd_id, inputs, claimed=None, intent=""):
    """Semantic Firewall on demand. On failure -> failed_with_receipt (with the missing/invalid fields)."""
    cmd = cmdreg.CMD_BY_ID.get(cmd_id)
    ok, errors = airlock.validate(cmd, inputs, claimed)
    if not ok:
        rc = airlock.make_receipt(cmd, inputs, intent, "failed_with_receipt", now_iso(),
                                  note="validation failed: " + "; ".join(errors))
        rc["receipt_id"] = _persist_receipt(rc)
        return {"ok": False, "status": "validation_failed", "errors": errors, "receipt": rc}
    return {"ok": True, "status": "valid", "errors": []}


# DRY-RUN-only commands whose execution composes a manifest + writes a receipt and TRANSMITS NOTHING
# (no SMTP/socket). For these, a missing provider key must NOT dead-end the demo at not_configured: the
# Approval Airlock + batch manifest + Batch Confirmed card are a pure local DRY-RUN that sends nothing,
# so they open without a key. The LIVE send (email.send_followup) is NOT here and stays gated on a
# configured+tested key. This override lives in glue ON PURPOSE — command_registry.py is frozen, and its
# requires/provider declaration (the contract a real send needs) stays truthful and untouched.
DRY_RUN_NO_KEY = {"email.send_batch"}


def resolve_status_for(cmd, configured):
    """resolve_status, but a DRY-RUN-only command (sends nothing) reaches the Airlock even with no provider
    key: not_configured is upgraded to available_write_requires_approval for that command ONLY. Every other
    command — including the LIVE send — is unchanged. NO FAKE GREEN: nothing actually transmits on this path."""
    st = cmdreg.resolve_status(cmd, configured)
    if st == "not_configured" and (cmd or {}).get("id") in DRY_RUN_NO_KEY \
            and (cmd or {}).get("mode") == "write_requires_approval":
        return "available_write_requires_approval"
    return st


def preview_command(cmd_id, inputs, intent=""):
    """Produce the deterministic airlock card. Writes a pending_approval receipt for writes. No execution."""
    stamp = now_iso()
    cmd = cmdreg.CMD_BY_ID.get(cmd_id)
    ok, errors = airlock.validate(cmd, inputs)
    if not ok:
        rc = airlock.make_receipt(cmd, inputs, intent, "failed_with_receipt", stamp,
                                  note="validation failed: " + "; ".join(errors))
        rc["receipt_id"] = _persist_receipt(rc)
        return {"ok": False, "status": "validation_failed", "errors": errors, "receipt": rc}
    configured = cmdreg.configured_providers(jload(os.path.join(WS, "integrations.json"), {}))
    status = resolve_status_for(cmd, configured)
    card = airlock.airlock_card(cmd, inputs, status, stamp)
    prov = cmd.get("provider")
    if prov and prov != "railcall":   # honest warning: a saved-but-never-tested provider can't confirm it will work
        for cat in jload(os.path.join(WS, "integrations.json"), {}).values():
            for it in (cat or []):
                if it.get("id") == prov and it.get("status") == "key_present" and not it.get("last_tested"):
                    card["warning"] = ("%s key present but never tested — Test it in the Connect tab before approving real sends" % prov)
    if cmd.get("id") == "email.send_batch":   # the human approves the MANIFEST (N drafts, total, templates, batch hash)
        try:
            _spec, _rows, _sender = _batch_load(inputs or {})
            card["manifest"], _d = flow_engine.batch_manifest(_spec, _rows, _sender)
        except Exception as e:
            card["manifest_error"] = str(e)[:120]
    if status == "available_write_requires_approval":
        p = _pending()
        p[card["idempotency_key"]] = {"command_id": cmd_id, "payload_hash": card["payload_hash"],
                                      "status": "pending_approval", "created": stamp, "approval": None}
        _pending_save(p)
        rc = airlock.make_receipt(cmd, inputs, intent, "pending_approval", stamp)
        rc["receipt_id"] = _persist_receipt(rc)
        return {"ok": True, "status": "pending_approval", "card": card, "requires_approval": True}
    return {"ok": True, "status": status, "card": card, "requires_approval": False}


def approve_command(cmd_id, inputs, method, intent=""):
    """Bind a human approval to the EXACT payload. method = ui_click | terminal_confirm."""
    stamp = now_iso()
    cmd = cmdreg.CMD_BY_ID.get(cmd_id)
    ok, errors = airlock.validate(cmd, inputs)
    if not ok:
        return {"ok": False, "status": "validation_failed", "errors": errors}
    configured = cmdreg.configured_providers(jload(os.path.join(WS, "integrations.json"), {}))
    if resolve_status_for(cmd, configured) != "available_write_requires_approval":
        return {"ok": False, "error": "this command does not require approval"}
    if method not in ("ui_click", "terminal_confirm"):
        return {"ok": False, "error": "approval must be an explicit ui_click or terminal_confirm"}
    idem = airlock.idempotency_key(cmd_id, inputs)
    approval = airlock.bind_approval(cmd_id, inputs, method, stamp)
    p = _pending()
    p.setdefault(idem, {"command_id": cmd_id, "payload_hash": approval["approved_payload_hash"], "created": stamp})
    p[idem]["approval"] = approval
    p[idem]["status"] = "approved_not_executed"
    _pending_save(p)
    rc = airlock.make_receipt(cmd, inputs, intent, "approved_not_executed", stamp, approval=approval)
    rc["receipt_id"] = _persist_receipt(rc)
    return {"ok": True, "status": "approved_not_executed", "approval_id": idem,
            "payload_hash": approval["approved_payload_hash"], "receipt": rc}


def execute_command(cmd_id, inputs, intent=""):
    """Execute under the airlock. Reads run if valid+configured. Writes run ONLY with an approval bound to
    THIS exact payload — else blocked_by_policy. EVERY path writes a receipt."""
    stamp = now_iso()
    cmd = cmdreg.CMD_BY_ID.get(cmd_id)
    ok, errors = airlock.validate(cmd, inputs)
    if not ok:
        rc = airlock.make_receipt(cmd, inputs, intent, "failed_with_receipt", stamp,
                                  note="validation failed: " + "; ".join(errors))
        rc["receipt_id"] = _persist_receipt(rc)
        return rc
    configured = cmdreg.configured_providers(jload(os.path.join(WS, "integrations.json"), {}))
    status = resolve_status_for(cmd, configured)
    if status == "available_read_only" and cmd_id in LOCAL_HANDLERS:        # read: no approval needed
        ext = cmd.get("provider") != "railcall"     # an external read (e.g. github) honestly touches the API
        try:
            output, artifact = LOCAL_HANDLERS[cmd_id](inputs or {}, stamp)
            rc = airlock.make_receipt(cmd, inputs, intent, "executed", stamp, external_touched=ext,
                                      artifact=artifact, output=output, post_result=output)
        except Exception as e:
            rc = airlock.make_receipt(cmd, inputs, intent, "failed_with_receipt", stamp, external_touched=ext,
                                      note=str(e)[:160])
        rc["receipt_id"] = _persist_receipt(rc)
        return rc
    if status == "available_write_requires_approval":                       # write: must be approved for THIS payload
        idem = airlock.idempotency_key(cmd_id, inputs)
        ph = airlock.payload_hash(cmd_id, inputs)
        pend = _pending().get(idem)
        approval = pend.get("approval") if pend else None
        if not approval or approval.get("approved_payload_hash") != ph:
            rc = airlock.make_receipt(cmd, inputs, intent, "blocked_by_policy", stamp, approval=approval,
                                      note="no human approval bound to this exact payload — nothing executed")
            rc["receipt_id"] = _persist_receipt(rc)
            return rc
        if cmd_id not in LOCAL_HANDLERS:                                     # approved but not wired (e.g. external)
            rc = airlock.make_receipt(cmd, inputs, intent, "not_wired_yet", stamp, approval=approval,
                                      note="approved, but this command's execution isn't wired yet")
            rc["receipt_id"] = _persist_receipt(rc)
            return rc
        try:
            output, artifact = LOCAL_HANDLERS[cmd_id](inputs or {}, stamp)
            ext = (cmd.get("provider") != "railcall") and not (isinstance(output, dict) and output.get("dry_run"))
            rc = airlock.make_receipt(cmd, inputs, intent, "executed", stamp, approval=approval,
                                      external_touched=ext,
                                      artifact=artifact, output=output, post_result=output)
            p = _pending()
            if idem in p:
                p[idem]["status"] = "executed"
                _pending_save(p)
        except Exception as e:
            rc = airlock.make_receipt(cmd, inputs, intent, "failed_safely", stamp, approval=approval,
                                      note="execution failed: " + str(e)[:140])
        rc["receipt_id"] = _persist_receipt(rc)
        return rc
    note = {"not_configured": "required secrets are missing",
            "not_wired_yet": "command declared but not implemented yet",
            "blocked_by_policy": "refused by policy"}.get(status, "not executable in v0")
    rc = airlock.make_receipt(cmd, inputs, intent, status, stamp, note=note)
    rc["receipt_id"] = _persist_receipt(rc)
    return rc


def commands_list():
    configured = cmdreg.configured_providers(jload(os.path.join(WS, "integrations.json"), {}))
    return [dict(c, status=resolve_status_for(c, configured)) for c in cmdreg.COMMANDS]


# Natural-language synonyms a user types that don't literally appear in id/name/category/manual text.
# Keyed by a substring of the (lowercased) category; the values are appended to the search blob so e.g.
# typing "calendar" finds Calendly even though its category is "Scheduling & E-sign". Provider-id overrides
# cover cases the category misses (feature-flag tools live under Marketing & Analytics). Recall-only — never
# changes what a provider DOES, just whether the obvious word finds it.
_SEARCH_CAT_SYNONYMS = {
    "scheduling": "calendar calendars scheduling schedule booking appointments meeting meetings availability esign e-sign signature signatures sign electronic-signature",
    "e-sign":     "signature signatures sign esign e-sign electronic-signature contract docusign",
    "support":    "helpdesk help-desk support ticket tickets ticketing customer-support service-desk",
    "monitor":    "logging logs log observability monitoring metrics tracing apm incidents uptime",
    "observ":     "logging logs log observability monitoring metrics tracing apm",
    "comm":       "video voice call calls calling conferencing meeting telephony sms messaging chat",
    "messaging":  "video voice sms chat messaging call calls",
    "email":      "email mail smtp newsletter",
    "marketing":  "feature-flag feature-flags feature flag feature flags featureflag flags experimentation ab-test a/b-test analytics funnel rollout toggles",
    "analytic":   "analytics funnel metrics events dashboard reporting feature-flag flags experimentation",
    "docs":       "spreadsheet spreadsheets sheet sheets document documents wiki notes knowledge-base",
    "workspace":  "spreadsheet sheet document docs wiki notes",
    "form":       "form forms survey questionnaire",
    "database":   "database db sql spreadsheet table query rows",
    "code":       "git repository repo version-control ci pipeline code",
    "cloud":      "deploy deployment hosting server cdn storage bucket infrastructure",
    "payment":    "payment payments billing invoice checkout subscription stripe",
    "crm":        "crm contacts leads pipeline deals sales customers",
    "auth":       "auth authentication login sso identity oauth users sessions",
    "security":   "auth security secret token identity sso users",
}
_SEARCH_ID_SYNONYMS = {
    "launchdarkly": "feature-flag feature-flags feature flag feature flags flags rollout toggles experimentation",
    "statsig":      "feature-flag feature-flags feature flag feature flags flags experimentation ab-test rollout",
    "optimizely":   "feature-flag feature-flags feature flag feature flags flags experimentation ab-test a/b-test",
    "flagsmith":    "feature-flag feature-flags feature flag feature flags flags rollout toggles",
}


def _search_blob(iid, name, cat, meta=None):
    """Compact searchable text: id + name + category + (manual desc) + capability/workflow keywords +
    the integration's own workflow ids and key names (per Nick's QA — search the full index, not just id/name).
    Plus a synonym layer so common user terms (calendar/helpdesk/logging/signature/video/feature flag/spreadsheet)
    find the obvious providers even when the literal word isn't in the id/name/category."""
    t = CAT_TEMPLATES.get(_tmpl_key(cat, iid), CAT_TEMPLATES["generic"])
    parts = [iid or "", name or "", cat or ""]
    m = MAN.get(iid)
    if m:
        parts.append(m.get("desc", ""))
        parts += [k[0] for k in m.get("req", []) if k] + [k[0] for k in m.get("opt", []) if k]
    if meta:
        parts += [str(w) for w in (meta.get("workflows") or [])]
        parts += [str(k) for k in (meta.get("required") or [])] + [str(k) for k in (meta.get("optional") or [])]
    parts += t["can"][:5] + t["why"][:3] + t["flows"][:3]
    cl = (cat or "").lower()
    for needle, syn in _SEARCH_CAT_SYNONYMS.items():
        if needle in cl:
            parts.append(syn)
    if iid in _SEARCH_ID_SYNONYMS:
        parts.append(_SEARCH_ID_SYNONYMS[iid])
    return " ".join(parts).lower()


def integrations_list():
    ints = jload(os.path.join(WS, "integrations.json"), {})
    vault = jload(os.path.join(WS, "keys.local.json"), {})   # ground truth for whether a key actually exists
    flat = []
    for cat, items in ints.items():
        for it in (items if isinstance(items, list) else []):
            iid = it.get("id")
            # vault_key_present = a key REALLY exists in keys.local.json. The picker must trust THIS, not a
            # persisted "tested"/"key_present" status that can go stale if the key was cleared/rotated
            # out-of-band — otherwise it advertises a BYOK build (your key · your cost) with no key. NO FAKE GREEN.
            kpresent = bool(vault.get(iid))
            flat.append({"id": iid, "name": it.get("name"), "category": cat,
                         "status": it.get("status"), "available": it.get("status") in ("key_present", "tested"),
                         "vault_key_present": kpresent,
                         "risk": it.get("risk"), "read_write": it.get("read_write"),
                         "rank": INTEGRATION_RANK.get(iid, 999), "search": _search_blob(iid, it.get("name"), cat, it)})
    return flat


# ---- local file import (loopback). Files stay in .railcall_workspace/uploads/, NEVER transmitted anywhere. ----
def _safe_name(raw):
    return re.sub(r"[^A-Za-z0-9._ -]", "_", os.path.basename(str(raw)))[:120] or "file"


UPLOAD_DESTS = ("uploads", "fixtures", "builds", "tests")   # whitelist — where an upload may land


def _dest_dir(dest):
    if dest == "fixtures":
        return os.path.join(ROOT, "fixtures")
    if dest == "builds":
        return os.path.join(ROOT, "builds")
    if dest == "tests":
        return os.path.join(ROOT, "tests")
    return os.path.join(WS, "uploads")


def _find_upload(name):
    nm = _safe_name(name)
    for label in UPLOAD_DESTS:
        p = os.path.join(_dest_dir(label), nm)
        if os.path.isfile(p):
            return p, label
    return None, None


def _count_rows(p):
    try:
        n = sum(1 for ln in open(p, encoding="utf-8", errors="ignore") if ln.strip())
        return max(0, n - 1) if p.lower().endswith((".csv", ".tsv")) else n   # CSV/TSV: exclude the header row
    except Exception:
        return None


def _columns(line, name):
    delim = "\t" if name.lower().endswith(".tsv") else ","
    return [c.strip() for c in line.split(delim)][:24]


def uploads_list():
    out, seen = [], set()
    for label in ("uploads", "fixtures"):      # the two data-input destinations
        d = _dest_dir(label)
        if os.path.isdir(d):
            for f in sorted(os.listdir(d)):
                p = os.path.join(d, f)
                if os.path.isfile(p) and not f.startswith(".") and f not in seen:
                    seen.add(f)
                    rows = _count_rows(p) if f.lower().endswith((".csv", ".tsv", ".txt")) else None
                    out.append({"name": f, "where": label, "bytes": os.path.getsize(p), "rows": rows})
    return out


def save_upload(body):
    safe = _safe_name(body.get("name", "file"))
    dest = body.get("dest", "uploads")
    if dest not in UPLOAD_DESTS:
        dest = "uploads"
    udir = _dest_dir(dest)
    os.makedirs(udir, exist_ok=True)
    out = os.path.join(udir, safe)
    content = body.get("content", "") or ""
    if body.get("b64"):
        import base64
        try:
            data = base64.b64decode(content.split(",", 1)[-1])
        except Exception:
            return {"ok": False, "error": "could not decode file"}
        if len(data) > 5 * 1024 * 1024:
            return {"ok": False, "error": "file too large (max 5MB)"}
        with open(out, "wb") as f:
            f.write(data)
        audit_log("upload", {"file": safe, "dest": dest, "bytes": len(data), "kind": "binary"})
        return {"ok": True, "name": safe, "dest": dest, "bytes": len(data), "kind": "binary",
                "note": "stored locally · export to CSV to extract rows"}
    if len(content) > 5 * 1024 * 1024:
        return {"ok": False, "error": "file too large (max 5MB)"}
    with open(out, "w", encoding="utf-8") as f:
        f.write(content)
    lines = [ln for ln in content.splitlines() if ln.strip()]
    cols = _columns(lines[0], safe) if lines else []
    delim = "\t" if safe.lower().endswith(".tsv") else ","
    nrows = max(0, len(lines) - 1) if safe.lower().endswith((".csv", ".tsv")) else len(lines)  # data rows, not header
    audit_log("upload", {"file": safe, "dest": dest, "bytes": len(content.encode("utf-8")), "kind": "text", "rows": nrows})
    return {"ok": True, "name": safe, "dest": dest, "bytes": len(content.encode("utf-8")), "kind": "text",
            "rows": nrows, "columns": cols, "preview": [ln.split(delim)[:12] for ln in lines[:6]]}


def upload_preview(name):
    p, where = _find_upload(name)
    if not p:
        return {"error": "not found"}
    if not name.lower().endswith((".csv", ".tsv", ".txt", ".json", ".md")):
        return {"name": name, "where": where, "binary": True}
    try:
        lines = [ln for ln in open(p, encoding="utf-8", errors="ignore") if ln.strip()][:50]
    except Exception:
        return {"name": name, "where": where, "binary": True}
    delim = "\t" if name.lower().endswith(".tsv") else ","
    cols = _columns(lines[0], name) if lines else []
    return {"name": name, "where": where, "columns": cols,
            "rows": [ln.rstrip("\n").split(delim)[:12] for ln in lines]}


# ---- v0.2 workspace persistence: sessions remember their command history + notes on disk ----
def active_id():
    return jload(os.path.join(WS, "workspace.json"), {}).get("active_session")


def append_command(cmd, ok, exit_code):
    sess = jload(os.path.join(WS, "sessions.json"), [])
    aid = active_id()
    for s in sess:
        if s.get("id") == aid:
            s.setdefault("commands", []).append({"cmd": cmd, "ok": ok, "exit": exit_code, "at": time.time()})
            s["updated"] = time.time()
    jsave(os.path.join(WS, "sessions.json"), sess)


# ---- conversational terminal: RailCall's assistant. To the user it IS RailCall — the
#      inference engine (currently Groq) and the model are NEVER surfaced. The moat is the
#      curated, growing code library + picking the best match from it, not the model.
_CATALOG = {"_ts": 0}


def build_catalog():
    """Catalog = the AUDITED treasury ONLY — license-screened, sha256-pinned, smoke-tested OSS.
    The old un-audited internal modules (workflow_primitives) are deliberately EXCLUDED."""
    comps, combos = [], []
    ci = os.path.join(ROOT, "library", "ui", "ui_component_index.json")
    if os.path.exists(ci):
        for c in jload(ci, {}).get("components", []):
            if not c.get("component_name"):
                continue
            comps.append({"name": c.get("component_name"), "role": c.get("role"),
                          "license": c.get("license"), "version": c.get("version"),
                          "smoke": c.get("smoke_test_result")})
    cc = os.path.join(ROOT, "library", "combo_candidates.json")
    if os.path.exists(cc):
        for c in jload(cc, {}).get("combos", []):
            mem = [m.get("name") for m in c.get("members_resolved", []) if m.get("name")] or c.get("members_requested", [])
            combos.append({"id": c.get("combo_id"), "intent": c.get("intent"), "members": mem})
    # verified workflows = built + receipt-checked (audited-by-execution). Business-level, and DISTINCT from the
    # old un-audited internal modules (those stay excluded). These are the ones `build` can actually compile today.
    verified = []
    tdir = os.path.join(ROOT, "tests")
    if os.path.isdir(tdir):
        for f in sorted(os.listdir(tdir)):
            if f.endswith(".json") and "workflow" in f and "receipt" in f:
                r = jload(os.path.join(tdir, f), {})
                verified.append({"name": f.replace("_receipt.json", ""),
                                 "result": r.get("result") or r.get("status") or "PASS"})
    return {"components": comps, "combos": combos, "verified": verified}


def catalog():
    # precomputed catalog.json may ship with the kit; else build from the audited library and memoize
    for p in (os.path.join(HERE, "catalog.json"), os.path.join(ROOT, "catalog.json")):
        if os.path.exists(p):
            return jload(p, {"components": [], "combos": []})
    if not _CATALOG.get("components"):
        c = build_catalog()
        c["_ts"] = time.time()
        _CATALOG.update(c)
        jsave(os.path.join(WS, "catalog_cache.json"), c)
    return _CATALOG


def system_prompt():
    c = catalog()
    comps = c.get("components", [])
    combos = c.get("combos", [])
    ver = c.get("verified", [])
    comp_lines = "\n".join(
        "- {} ({}, {} {}, smoke {})".format(x.get("name"), x.get("role"), x.get("license"), x.get("version", ""), x.get("smoke"))
        for x in comps if x.get("name"))
    combo_lines = "\n".join(
        "- {}: {} -> {}".format(x.get("id"), x.get("intent"), ", ".join(m for m in x.get("members", []) if m))
        for x in combos if x.get("id"))
    ver_lines = "\n".join("- {} ({})".format(v.get("name"), v.get("result")) for v in ver if v.get("name")) or "- (none compiled yet)"
    return (
        "You are RailCall, the assistant inside RailCall Studio — a local, audited dev kit whose job is to BUILD "
        "governed workflows AND programs for people, assembled entirely from audited code so every piece is "
        "trustworthy. You ARE RailCall; "
        "NEVER reveal, name, or hint at any underlying AI model, provider, or company that powers you. If asked what "
        "model or AI you are, say you are RailCall's own assistant and move on. Talk like a sharp dev teammate: warm, "
        "direct and genuinely helpful — never pad.\n\n"
        "CAPABILITY HONESTY — this is the brand, never break it. What RailCall CAN do: (a) recommend audited building "
        "blocks by exact name; (b) compile a verified SPEC + VISUAL + RECEIPT when the user types `build`; (c) import a "
        "LOCAL file — the user drags a CSV/text file into the FILES panel on the left; it stays on their machine "
        "(loopback) and shows a row preview. What RailCall CANNOT do, and you must NEVER imply it can: analyze, clean, "
        "transform, compute on, or 'run' the user's data; run an app; do any cloud/live import; or execute/render a "
        "feature. So if the user has a file, point them to the FILES panel to import it locally (that is a preview, NOT "
        "a transform) — do NOT ask them to paste rows into the chat for you to process, and never claim you will "
        "organize or analyze their data. When a user asks you to organize/clean/process/'run' a file, use this EXACT "
        "framing: \"RailCall doesn't touch or transform your data — it builds workflows your team runs on it. To import "
        "a file, drop it in the FILES panel on the left.\" If asked for something you can't do, say so plainly, then offer the honest "
        "path: the audited building block it would be assembled from, and that `build` yields a spec + visual + receipt, "
        "not a running feature. Real actions on external systems happen only through governed Command Center commands "
        "(receipts + human approval), never through this chat.\n\n"
        "When a user asks what you can do, lead with the OUTCOME — governed workflows, websites, and programs you "
        "compose from pre-audited building blocks: turn a plain-English description into a verified spec + visual + "
        "signed receipt (a blueprint, not a deployed app). For a workflow you also run data through it, queue the "
        "next actions, gate risky writes behind the Approval Airlock, and leave a receipt for every step. Name "
        "specific components/combos only when they're relevant to a concrete build — do NOT open with a front-end "
        "library list.\n"
        "Your building blocks are a PRE-CODED, pre-audited LIBRARY — real components and combos ripped from "
        "permissive open source (MIT/Apache/ISC and similar) and license-screened, version-pinned, sha256-locked, "
        "and smoke-tested AHEAD OF TIME. You GRAB pieces from this library and assemble them; you do NOT write code "
        "from scratch and you do NOT audit on the fly. Only `build` from the pieces listed below — NEVER invent "
        "names and NEVER use the old un-audited internal modules.\n\n"
        f"PRE-CODED LIBRARY — components ({len(comps)}):\n{comp_lines}\n\n"
        f"PRE-CODED LIBRARY — combos ({len(combos)}):\n{combo_lines}\n\n"
        f"VERIFIED WORKFLOWS — already compiled + receipt-checked ({len(ver)}):\n{ver_lines}\n\n"
        "NATIVE INTEGRATIONS — never build infrastructure. RailCall has a left-pane palette of NATIVE integration "
        "slots (LLMs, webhook_in, Stripe, GitHub, Slack, Postgres, and ~80 more). These ARE the connection layer — "
        "you must NEVER invent, or tell the user to write, server/hosting/listener code (no Express, Flask, raw "
        "sockets, opening ports, or custom webhook servers). To connect an external tool, the user picks its native "
        "slot on the left and pastes a key (vaulted locally, 0600); every WRITE out crosses the Approval Airlock.\n"
        "WEBHOOKS specifically: RailCall's frozen core already runs the inbound gateway — there is nothing to build. "
        "The user points their external tool (Stripe/GitHub/etc.) at the native webhook_in endpoint, "
        "POST 127.0.0.1:8799/api/webhook/<slot> (loopback, or a tunnel they choose). The core ingests the raw "
        "payload into the governed audit log instantly — it appears LIVE in the Monitor feed — as an UNVERIFIED "
        "event; no code runs. So when asked 'how do I set up a webhook' or 'handle incoming webhooks', do NOT design "
        "a web server or mention Express/Flask/Node. Say: (1) open the webhook_in slot in the left pane and point "
        "your tool at the RailCall webhook_in URL; (2) the payload lands in the governed log, live in Monitor; (3) "
        "then `build` a governed workflow that PARSES that payload from the log using audited pieces and routes any "
        "action through the Approval Airlock. A webhook is just another source of text primitives — treated exactly "
        "like Stripe or GitHub.\n\n"
        "How to help: when the user describes a workflow, map it to the audited combos/components above, naming the "
        "exact pieces and their license + smoke status. Then tell them to type `build` — RailCall assembles those "
        "audited pieces into a workflow spec, compiles it to a visual, and emits a cryptographic receipt (license-clean, "
        "external_sockets=0, integrity root). Be straight: `build` produces a VERIFIED SPEC + VISUAL + RECEIPT from "
        "audited code — not yet a running, deployed app. Any step with no audited piece is shown honestly as 'needs "
        "audit', never faked. Never tell the user to go write custom code themselves — assembling from audited code is "
        "your job."
    )


def groq_key():
    return jload(os.path.join(WS, "keys.local.json"), {}).get("groq") or os.environ.get("GROQ_API_KEY")


def groq_chat(messages):
    key = groq_key()
    if not key:
        return {"reply": "RailCall's assistant is offline right now — try again in a moment.",
                "configured": False}
    payload = {"model": os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile"),
               "messages": [{"role": "system", "content": system_prompt()}] + messages[-12:],
               "temperature": 0.4, "max_tokens": 700}
    try:
        # endpoint is env-overridable so the shipped kit can route through RailCall's own proxy (provider stays hidden)
        url = os.environ.get("LLM_API_URL", "https://api.groq.com/openai/v1/chat/completions")
        req = urllib.request.Request(url,
                                     data=json.dumps(payload).encode(), method="POST",
                                     headers={"Content-Type": "application/json", "Authorization": "Bearer " + key,
                                              "User-Agent": "RailCall-Studio/0.1"})  # Cloudflare 403s Python-urllib's default UA
        with urllib.request.urlopen(req, timeout=30) as r:
            d = json.loads(r.read().decode())
        return {"reply": d["choices"][0]["message"]["content"].strip(), "configured": True}
    except Exception:
        return {"reply": "RailCall hit a snag reaching its library just now — try again.",
                "configured": True, "error": True}


def groq_raw(messages):
    """Raw model call returning the assistant text — used by the compose engine for strict-JSON specs.
    Same hidden backend + UA fix; provider is never surfaced."""
    key = groq_key()
    if not key:
        return ""
    payload = {"model": os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile"),
               "messages": messages, "temperature": 0.2, "max_tokens": 900}
    try:
        url = os.environ.get("LLM_API_URL", "https://api.groq.com/openai/v1/chat/completions")
        req = urllib.request.Request(url, data=json.dumps(payload).encode(), method="POST",
                                     headers={"Content-Type": "application/json", "Authorization": "Bearer " + key,
                                              "User-Agent": "RailCall-Studio/0.1"})
        with urllib.request.urlopen(req, timeout=45) as r:
            return json.loads(r.read().decode())["choices"][0]["message"]["content"]
    except Exception:
        return ""


class H(http.server.BaseHTTPRequestHandler):
    # Per-connection deadline: bounds a stalled / lying-Content-Length read so one connection cannot wedge a
    # worker indefinitely. NOTE: the server is threaded (see _Srv below), so a stalled connection no longer
    # starves OTHER clients during this window — this timeout only caps how long that one stalled socket ties
    # up its own worker thread before being dropped. Kept modest to shrink the per-stall footprint.
    timeout = 15
    ALLOWED_HOSTS = {"127.0.0.1:%d" % PORT, "localhost:%d" % PORT, "127.0.0.1", "localhost"}

    def _guard(self):
        # DNS-rebinding defense for the loopback-only API: Host (and any Origin/Referer) must be loopback.
        host = (self.headers.get("Host") or "").strip().lower()
        if host not in self.ALLOWED_HOSTS:
            self._send(403, {"ok": False, "error": "host not allowed (loopback only)"})
            return False
        for h in ("Origin", "Referer"):
            v = self.headers.get(h)
            if v:
                try:
                    netloc = urllib.parse.urlsplit(v).netloc.lower()
                except Exception:
                    netloc = ""
                base = netloc.split(":")[0]
                if base not in ("127.0.0.1", "localhost"):
                    self._send(403, {"ok": False, "error": "cross-origin blocked (loopback only)"})
                    return False
        return True

    def _send(self, code, body, ctype="application/json"):
        b = body if isinstance(body, (bytes, bytearray)) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(b)

    def _file(self, rel, ctype):
        p = os.path.join(HERE, rel)
        if not os.path.isfile(p):
            return self._send(404, {"error": "not found"})
        with open(p, "rb") as f:
            self._send(200, f.read(), ctype)

    def _serve_qa_guide(self):
        """Nick's QA guide — served locally, zero CDN."""
        html = b"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>RailCall QA Guide \xe2\x80\x94 signup\xe2\x86\x92sheet</title>
<style>
:root{--bg:#0a0e15;--bd:#1b2531;--base:#c2cedd;--head:#0d121c;--pass:#7fd06a;--warn:#f0b24a;
 --acc:#7fb0e8;--cyan:#5fcbb0;--dim:#5d6c80;--red:#ef9090;--dry:#54c8b0}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--base);
 font:14px/1.7 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;padding:32px}
h1{color:var(--cyan);font-size:18px;margin:0 0 4px}h2{color:var(--acc);font-size:13px;margin:28px 0 6px;
 border-bottom:1px solid var(--bd);padding-bottom:4px}p{color:var(--dim);margin:4px 0 10px}
pre{background:#080c12;border:1px solid var(--bd);border-radius:6px;padding:14px 16px;
 overflow-x:auto;font-size:12.5px;color:var(--base);line-height:1.55;margin:8px 0 14px}
code{color:var(--cyan)}kbd{background:#111827;border:1px solid var(--bd);border-radius:4px;
 padding:2px 7px;font-family:inherit;font-size:12px;color:var(--acc)}
.ok{color:var(--pass)}.warn{color:var(--warn)}.dim{color:var(--dim)}.dry{color:var(--dry)}
.step{display:flex;gap:12px;margin:10px 0}
.num{width:26px;height:26px;border-radius:50%;background:#0e2a20;color:var(--pass);
 display:flex;align-items:center;justify-content:center;flex:none;font-size:12px;font-weight:600}
.sc{background:#0a1520;border-left:3px solid var(--cyan);padding:10px 14px;margin:10px 0;border-radius:0 6px 6px 0}
.flag{display:inline-block;border:1px solid var(--bd);border-radius:4px;padding:2px 8px;
 font-size:11px;margin:2px;color:var(--warn);background:#16120a}
a{color:var(--acc)}
</style></head><body>
<h1>RailCall Studio \xe2\x80\x94 QA Guide</h1>
<p class="dim">Nick\xe2\x80\x99s copy-paste checklist: customer signup \xe2\x86\x92 webhook_in \xe2\x86\x92 Monitor \xe2\x86\x92 Google Sheet row.</p>
<p>
<span class="flag">LOCAL</span><span class="flag">BYOK</span><span class="flag">DRY-RUN default</span><span class="flag">NO SENDS until you flip live</span>
</p>

<h2>STEP 1 \xe2\x80\x94 Set up your Google Sheet (2 min)</h2>
<div class="step"><div class="num">1</div><div>Open your Google Sheet (or create a new one).</div></div>
<div class="step"><div class="num">2</div><div>Click <kbd>Extensions</kbd> \xe2\x86\x92 <kbd>Apps Script</kbd>.</div></div>
<div class="step"><div class="num">3</div><div>Delete any starter code. Paste this exactly:</div></div>
<pre><code>function doPost(e) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName("Signups") || ss.insertSheet("Signups");
  var row = JSON.parse(e.postData.contents);
  sh.appendRow([
    row.time  || new Date().toISOString(),
    row.email || "",
    row.name  || "",
    row.source || "railcall",
    row.raw   || ""
  ]);
  return ContentService
    .createTextOutput(JSON.stringify({ok: true, appended: true}))
    .setMimeType(ContentService.MimeType.JSON);
}</code></pre>
<div class="step"><div class="num">4</div><div>Click <kbd>Save</kbd> (floppy disk icon).</div></div>
<div class="step"><div class="num">5</div><div>Click <kbd>Deploy</kbd> \xe2\x86\x92 <kbd>New deployment</kbd>.<br>
  Type: <strong>Web App</strong><br>
  Execute as: <strong>Me</strong><br>
  Who has access: <strong>Anyone</strong><br>
  Click <kbd>Deploy</kbd> \xe2\x86\x92 <kbd>Authorize access</kbd> \xe2\x86\x92 allow.</div></div>
<div class="step"><div class="num">6</div><div><strong>Copy the Web App URL</strong> \xe2\x80\x94 it looks like:<br>
<code>https://script.google.com/macros/s/AKfycb.../exec</code><br>
<span class="warn">Copy the /exec URL, NOT the /edit URL.</span></div></div>

<h2>STEP 2 \xe2\x80\x94 Paste the URL into RailCall Studio</h2>
<div class="step"><div class="num">1</div><div>Open <a href="http://127.0.0.1:8799/v2">http://127.0.0.1:8799/v2</a></div></div>
<div class="step"><div class="num">2</div><div>Left pane \xe2\x86\x92 <kbd>INTEGRATIONS</kbd> \xe2\x86\x92 type <kbd>google_sheet</kbd> in the search box.</div></div>
<div class="step"><div class="num">3</div><div>Click <strong>google_sheet</strong> \xe2\x86\x92 paste your <code>/exec</code> URL into <code>SHEET_WEBHOOK_URL</code> \xe2\x86\x92 press Enter.<br>
Status becomes <span class="ok">KEY_PRESENT</span>. The URL stays local (0600), never transmitted.</div></div>

<h2>STEP 3 \xe2\x80\x94 Fire a test signup</h2>
<p>Paste this in your terminal:</p>
<pre><code>curl -s http://127.0.0.1:8799/api/webhook/webhook_in \\
  -H 'Content-Type: application/json' \\
  -d '{"email":"nick@test.com","name":"Nick","event":"customer.signup"}'</code></pre>
<p>Expected response: <code class="ok">{"ok": true, "bytes": ...}</code></p>
<p>Now check the <strong>Monitor</strong> tab in Studio \xe2\x80\x94 you should see a <code>webhook_in</code> event appear within 2 seconds.</p>

<h2>STEP 4 \xe2\x80\x94 Dry-run the workflow (safe, nothing sent)</h2>
<div class="step"><div class="num">1</div><div>Left pane \xe2\x86\x92 <kbd>WORKFLOWS</kbd> \xe2\x86\x92 click <strong>signup_to_sheet</strong>.</div></div>
<div class="step"><div class="num">2</div><div>Click <kbd>\xe2\x96\xb6 dry-run now</kbd>.</div></div>
<div class="step"><div class="num">3</div><div>Expected: result = <span class="dry">DRY_RUN</span>, row preview shows nick@test.com, <strong>no external call made</strong>.<br>
Right pane shows <code>external touched: false</code> and <code>secret_value_logged: false</code>.</div></div>

<h2>STEP 5 \xe2\x80\x94 Send live (row really appears in your sheet)</h2>
<div class="step"><div class="num">1</div><div>Same <strong>signup_to_sheet</strong> pane.</div></div>
<div class="step"><div class="num">2</div><div>Click <kbd style="background:#160f00;color:#f0b24a;border-color:#4a3a16">\xe2\x96\xb6 send live row</kbd>.</div></div>
<div class="step"><div class="num">3</div><div>Expected: result = <span class="ok">SENT</span>, HTTP 200.<br>
Open your Google Sheet \xe2\x80\x94 the <strong>Signups</strong> tab should have a new row:<br>
<code>[timestamp] [nick@test.com] [Nick] [customer.signup] [raw json]</code></div></div>

<h2>STEP 6 \xe2\x80\x94 Verify the audit trail</h2>
<div class="sc">
<p style="margin:0">Right pane of signup_to_sheet shows:<br>
<span class="ok">secret_value_logged: false</span><br>
<span class="ok">writes: Airlock-gated</span><br>
<span class="ok">LOCAL \xc2\xb7 DRY-RUN: enforced</span></p>
</div>
<p>Check the Monitor tab \xe2\x80\x94 you should see a <code>signup_to_sheet</code> event with <code>external_api_touched: true</code> for the live run.</p>

<h2>TROUBLESHOOTING</h2>
<pre><span class="warn">URL not configured</span>      \xe2\x86\x92 re-paste the /exec URL in google_sheet integration
<span class="warn">No webhook payload</span>     \xe2\x86\x92 run the curl command in Step 3 first
<span class="warn">SEND_FAILED / 302</span>      \xe2\x86\x92 wrong URL (copied /edit not /exec); redeploy the Apps Script
<span class="warn">Rows not appearing</span>     \xe2\x86\x92 check Apps Script console (View \xe2\x86\x92 Logs) for errors
<span class="warn">403 Forbidden</span>          \xe2\x86\x92 "Who has access" must be set to Anyone; redeploy
<span class="warn">Tab name wrong</span>         \xe2\x86\x92 rename your sheet tab to "Signups" or update the Apps Script</pre>

<h2>WHAT THIS QA PROVES</h2>
<pre><span class="ok">\xe2\x9c\x93</span> webhook ingest \xe2\x80\x94 payload lands in governed log (loopback, no code runs on ingest)
<span class="ok">\xe2\x9c\x93</span> Monitor feed \xe2\x80\x94 event visible live within 2s
<span class="ok">\xe2\x9c\x93</span> dry-run \xe2\x80\x94 row composed + receipt emitted, zero external calls
<span class="ok">\xe2\x9c\x93</span> live send \xe2\x80\x94 row actually appears in Google Sheet (first real outbound rail)
<span class="ok">\xe2\x9c\x93</span> right pane proof \xe2\x80\x94 secret_value_logged=false, writes=Airlock-gated
<span class="ok">\xe2\x9c\x93</span> audit trail \xe2\x80\x94 every event in integration_audit.jsonl, no secret values
<span class="dim">\xe2\x9c\x97</span> live test requires the /exec URL \xe2\x80\x94 dry-run works without it</pre>

<p style="margin-top:32px;color:var(--dim);font-size:12px">
LOCAL \xc2\xb7 BYOK \xc2\xb7 DRY-RUN \xc2\xb7 NO SENDS \xe2\x80\x94 Studio at <a href="http://127.0.0.1:8799/v2">http://127.0.0.1:8799/v2</a>
</p>
</body></html>"""
        # Make the guide port-aware: the Studio links become relative (always same origin as the served
        # guide), and the copy-paste curl + footer use the ACTUAL bound port — not a hardcoded 8799 that is
        # dead on a custom STUDIO_PORT. start.command serves this guide on the chosen port, so links must follow.
        html = (html.replace(b'href="http://127.0.0.1:8799/v2"', b'href="/v2"')
                    .replace(b"http://127.0.0.1:8799", ("http://127.0.0.1:%d" % PORT).encode()))
        self._send(200, html, "text/html; charset=utf-8")

    def _serve_qa_pack(self):
        """Render QA_PACK_NICK.md in-browser (zero-CDN, minimal markdown -> HTML)."""
        md_path = os.path.join(ROOT, "QA_PACK_NICK.md")
        if not os.path.isfile(md_path):
            return self._send(404, {"error": "QA pack not found"})
        import html as _h
        lines = open(md_path, encoding="utf-8").read().split("\n")
        out, in_code, in_tbl = [], False, False
        for ln in lines:
            if ln.startswith("```"):
                if in_code:
                    out.append("</code></pre>"); in_code = False
                else:
                    out.append("<pre><code>"); in_code = True
                continue
            if in_code:
                out.append(_h.escape(ln)); continue
            if ln.startswith("|") and "|" in ln[1:]:
                cells = [c.strip() for c in ln.strip().strip("|").split("|")]
                if set("".join(cells)) <= set("-: "):
                    continue  # separator row
                if not in_tbl:
                    out.append("<table>"); in_tbl = True
                tag = "th" if all(c and not c[0].isdigit() for c in cells[:1]) and cells[0] in ("#", "Do this") else "td"
                out.append("<tr>" + "".join("<%s>%s</%s>" % (tag, _h.escape(c), tag) for c in cells) + "</tr>")
                continue
            elif in_tbl:
                out.append("</table>"); in_tbl = False
            s = _h.escape(ln)
            if ln.startswith("# "):
                out.append("<h1>" + s[2:] + "</h1>")
            elif ln.startswith("## "):
                out.append("<h2>" + s[3:] + "</h2>")
            elif ln.startswith("### "):
                out.append("<h3>" + s[4:] + "</h3>")
            elif ln.startswith("---"):
                out.append("<hr>")
            elif ln.strip() == "":
                out.append("<br>")
            else:
                s = s.replace("`", " ").replace("**", "")  # light cleanup
                out.append("<p>" + s + "</p>")
        if in_tbl:
            out.append("</table>")
        body = ("<!doctype html><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
                "<title>RailCall QA Pack</title><style>"
                "body{margin:0;background:#0a0e15;color:#c2cedd;font:14px/1.7 ui-monospace,Menlo,Consolas,monospace;padding:30px;max-width:920px}"
                "h1{color:#5fcbb0;font-size:19px}h2{color:#7fb0e8;font-size:14px;border-bottom:1px solid #1b2531;padding-bottom:5px;margin-top:26px}"
                "h3{color:#7fd06a;font-size:13px}pre{background:#080c12;border:1px solid #1b2531;border-radius:6px;padding:12px 14px;overflow-x:auto;font-size:12.5px;color:#c2cedd}"
                "table{width:100%;border-collapse:collapse;margin:10px 0;font-size:12.5px}td,th{border:1px solid #1b2531;padding:6px 9px;text-align:left;vertical-align:top}"
                "th{color:#7fb0e8;background:#0d121c}hr{border:0;border-top:1px solid #1b2531;margin:18px 0}p{margin:3px 0}a{color:#7fb0e8}br{line-height:0.5}"
                "</style>" + "\n".join(out)).encode("utf-8")
        self._send(200, body, "text/html; charset=utf-8")

    def do_GET(self):
        if not self._guard():
            return
        path = self.path.split("?")[0]
        if path in ("/", "/studio.html"):
            return self._file("studio.html", "text/html; charset=utf-8")
        if path in ("/v2", "/studio_v2.html"):   # studio-ui-v2 shell (additive · same engine + APIs)
            return self._file("studio_v2.html", "text/html; charset=utf-8")
        if path in ("/qa_guide", "/qa_guide.html"):
            return self._serve_qa_guide()
        if path in ("/qa_pack", "/qa_pack.md"):
            return self._serve_qa_pack()
        if path == "/vendor/xterm.js":
            return self._file("vendor/xterm.js", "application/javascript")
        if path == "/vendor/xterm.css":
            return self._file("vendor/xterm.css", "text/css")
        if path == "/api/usage":
            return self._send(200, fetch_balance())
        if path == "/api/audit":
            return self._send(200, audit_state())
        if path == "/api/data":
            return self._send(200, data_tables())
        if path == "/api/suggestions":
            return self._send(200, {"suggestions": suggestions()})
        if path == "/api/uploads":
            return self._send(200, {"uploads": uploads_list()})
        if path == "/api/flow/sources":   # built workflows + data files, for the Flow tab dropdowns
            wfs = []
            for p in sorted(glob.glob(os.path.join(ROOT, "tests", "workflow_*receipt*.json")), key=os.path.getmtime, reverse=True):
                d = jload(p, {})
                if d.get("spec"):
                    wfs.append({"name": d.get("workflow_id"), "title": d.get("title"), "result": d.get("result")})
            data = [u["name"] for u in uploads_list() if str(u.get("name", "")).lower().endswith((".csv", ".tsv"))]
            return self._send(200, {"workflows": wfs, "data": data})
        if path == "/api/upload_preview":
            from urllib.parse import urlparse, parse_qs, unquote
            nm = unquote((parse_qs(urlparse(self.path).query).get("name") or [""])[0])
            return self._send(200, upload_preview(nm))
        if path == "/api/uploads_raw":   # download a local file back out (data OUT)
            from urllib.parse import urlparse, parse_qs, unquote
            nm = _safe_name(unquote((parse_qs(urlparse(self.path).query).get("name") or [""])[0]))
            fp, _w = _find_upload(nm)
            if fp:
                with open(fp, "rb") as f:
                    data = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Disposition", 'attachment; filename="%s"' % nm)
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            return self._send(404, {"error": "not found"})
        if path == "/api/workflow/signup_to_sheet/status":
            vault = jload(os.path.join(WS, "keys.local.json"), {})
            raw = vault.get("google_sheet")
            url = _pick(raw, "SHEET_WEBHOOK_URL") if isinstance(raw, dict) else (raw if isinstance(raw, str) else "")
            last = _latest_webhook_payload()
            last_email = ""
            if last:
                b2 = last.get("body") or last
                if isinstance(b2, str):
                    try: b2 = json.loads(b2)
                    except Exception: b2 = {}
                last_email = b2.get("email", "") if isinstance(b2, dict) else ""
            last_send = None
            ap = os.path.join(WS, "integration_audit.jsonl")
            if os.path.exists(ap):
                for ln in reversed(open(ap).read().splitlines()):
                    try:
                        e = json.loads(ln)
                        if e.get("type") == "sheet_send": last_send = e; break
                    except Exception: pass
            return self._send(200, {"url_configured": bool(url), "has_webhook_payload": bool(last),
                                    "last_webhook_email": last_email, "last_send": last_send})
        if path == "/api/integrations/list":
            return self._send(200, {"integrations": integrations_list()})
        if path == "/api/commands/list":
            return self._send(200, {"commands": commands_list(), "statuses": sorted(cmdreg.TERMINAL_STATUSES)})
        if path == "/api/receipts/list":
            return self._send(200, {"receipts": receipts_index()})
        if path == "/api/monitor":
            return self._send(200, monitor_feed())
        if path == "/api/router":
            return self._send(200, router_state())
        if path == "/api/webhook/inbox":   # 6d+: live depth of the webhook_in inbox (unparsed raw payloads)
            from urllib.parse import urlparse, parse_qs
            slot = re.sub(r"[^a-z0-9_]+", "_", ((parse_qs(urlparse(self.path).query).get("slot") or ["webhook_in"])[0]).lower())
            ibx = os.path.join(WS, "webhook_inbox", slot)
            files = sorted(glob.glob(os.path.join(ibx, "*.json"))) if os.path.isdir(ibx) else []
            return self._send(200, {"slot": slot, "count": len(files),
                                    "recent": [os.path.basename(f) for f in files[-5:]],
                                    "url": "http://127.0.0.1:%d/api/webhook/%s" % (PORT, slot), "external": False})
        if path == "/api/integration/manual":   # terminal-native provider manual (no secret values)
            from urllib.parse import urlparse, parse_qs
            iid = re.sub(r"[^a-z0-9_]+", "_", ((parse_qs(urlparse(self.path).query).get("id") or [""])[0]).lower())
            mn = integration_manual(iid)
            return self._send(200 if mn else 404, mn or {"error": "unknown integration"})
        if path == "/api/receipts/read":
            from urllib.parse import urlparse, parse_qs, unquote
            rid = unquote((parse_qs(urlparse(self.path).query).get("id") or [""])[0])
            r = read_receipt(rid)
            return self._send(200 if r else 404, r or {"error": "not found"})
        if path == "/api/workspace":
            return self._send(200, {
                "workspace": jload(os.path.join(WS, "workspace.json"), {}),
                "sessions": jload(os.path.join(WS, "sessions.json"), []),
                "folder_notes": jload(os.path.join(WS, "folder_notes.json"), {}),
                "links": jload(os.path.join(WS, "generated_links.json"), []),
                "integrations": jload(os.path.join(WS, "integrations.json"), {}),
                "community": COMMUNITY,
                "artifacts": [os.path.basename(p) for p in sorted(glob.glob(os.path.join(ROOT, "builds", "*.html")))],
                "workflows": self._workflows(),
            })
        if path.startswith("/ui/"):       # 6d: serve the governed UI blueprint over loopback
            name = os.path.basename(path[len("/ui/"):])
            if not name.endswith(".html"):
                name += ".html"
            p = os.path.join(ROOT, "builds", "ui", name)
            if os.path.isfile(p):
                with open(p, "rb") as f:
                    return self._send(200, f.read(), "text/html; charset=utf-8")
            return self._send(404, {"error": "no preview yet — build it first"})
        if path.startswith("/builds/"):
            name = os.path.basename(path[len("/builds/"):])
            p = os.path.join(ROOT, "builds", name)
            if name.endswith(".html") and os.path.isfile(p):
                with open(p, "rb") as f:
                    return self._send(200, f.read(), "text/html; charset=utf-8")
            return self._send(404, {"error": "not found"})
        return self._send(404, {"error": "not found"})

    def _workflows(self):
        wf = []
        for p in sorted(glob.glob(os.path.join(ROOT, "tests", "workflow_*receipt*.json")), key=os.path.getmtime, reverse=True):
            d = jload(p, {})
            if d:
                wf.append({"id": d.get("workflow_id"), "result": d.get("result"),
                           "nodes": len(d.get("nodes", [])), "steps": d.get("nodes", []),
                           "trigger": d.get("trigger"), "root": str(d.get("integrity_root", ""))[7:15]})
        return wf

    def do_POST(self):
        if not self._guard():
            return
        path = self.path.split("?")[0]
        n = int(self.headers.get("Content-Length", "0") or 0)
        MAX_BODY = 6 * 1024 * 1024
        if n > MAX_BODY:
            return self._send(413, {"ok": False, "error": "request body too large"})
        remaining, chunks = n, []
        while remaining > 0:
            piece = self.rfile.read(min(remaining, 65536))
            if not piece:
                break
            chunks.append(piece)
            remaining -= len(piece)
        raw = b"".join(chunks)
        body_src = raw or b"{}"
        try:
            body = json.loads(body_src)
        except Exception:
            body = {}
        if path.startswith("/api/webhook/"):
            # NATIVE webhook_in gateway. Loopback-bound. Ingest ONLY: cap + sanitize, store the raw payload
            # to a local inbox, and append a sanitized event to the governed audit log (live in Monitor).
            # NO code executes here — a governed workflow parses the payload later, airlock-gated.
            slot = re.sub(r"[^a-z0-9_]+", "_", os.path.basename(path[len("/api/webhook/"):]).lower()) or "webhook_in"
            payload = (raw or b"")[:65536]             # hard cap: never ingest more than 64KB (truthful byte count)
            creds = jload(os.path.join(WS, "keys.local.json"), {}).get(slot)
            tok = creds.get("WEBHOOK_TOKEN") if isinstance(creds, dict) else None
            if tok and not hmac.compare_digest(str(self.headers.get("X-RailCall-Token") or ""), str(tok)):
                return self._send(401, {"ok": False, "error": "webhook token mismatch"})
            if not payload:
                return self._send(400, {"ok": False, "error": "empty payload"})
            summary = "(non-json payload)"
            try:
                d = json.loads(payload)
                if isinstance(d, dict):
                    summary = str(d.get("type") or d.get("event") or d.get("action")
                                  or (list(d.keys())[:1] or [""])[0]) or "(json)"
            except Exception:
                pass
            ibx = os.path.join(WS, "webhook_inbox", slot)
            os.makedirs(ibx, exist_ok=True)
            fname = time.strftime("%Y%m%dT%H%M%S", time.gmtime()) + ("_%06d" % (time.time_ns() % 1000000)) + ".json"
            with open(os.path.join(ibx, fname), "wb") as f:
                f.write(payload)
            audit_log("webhook_in", {"slot": slot, "bytes": len(payload), "verified": False, "summary": summary[:80]})
            return self._send(200, {"ok": True, "ingested": True, "slot": slot, "bytes": len(payload),
                                    "note": "logged as an unverified inbound event (live in Monitor); a governed "
                                            "workflow parses it next — no code ran"})
        if path == "/api/run":
            cmd = str(body.get("cmd", "")).strip().replace("railcall ", "")
            if cmd not in ALLOWED:
                return self._send(200, {"ok": False, "cmd": cmd, "stdout": "",
                                        "stderr": f"not allowed: {cmd!r} (whitelist: {list(ALLOWED)})", "exit": 126})
            try:
                p = subprocess.run(ALLOWED[cmd], cwd=ROOT, capture_output=True, text=True, timeout=60)
                append_command(cmd, p.returncode == 0, p.returncode)   # persist into the active session
                return self._send(200, {"ok": p.returncode == 0, "cmd": cmd, "stdout": p.stdout, "stderr": p.stderr, "exit": p.returncode})
            except Exception as e:
                return self._send(200, {"ok": False, "stdout": "", "stderr": str(e), "exit": 1})
        if path == "/api/chat":          # conversational terminal → RailCall's assistant (picks code from the library)
            return self._send(200, groq_chat(body.get("messages", [])))
        if path == "/api/build":         # THE core loop: conversation -> validated spec -> visual + REAL receipt
            stamp = body.get("stamp") or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            msgs = body.get("messages", [])
            if not isinstance(msgs, list):   # fail CLOSED with JSON, never crash the connection on a bad body
                return self._send(200, {"ok": False, "error": "messages must be a list"})
            # Turning a free-text description into a spec needs a compose model. With NO key the build can
            # NEVER succeed from a description — so say that plainly instead of "run build again" (a dead loop).
            if not groq_key():
                return self._send(200, {"ok": False, "needs_model": True,
                    "error": "Building from a description needs a model — pick one in the “build with” dropdown "
                             "and paste its key in INTEGRATIONS, or start from one of the starter workflows."})
            spec = compose_engine.compose_spec(msgs, catalog(), groq_raw)
            if not spec:
                return self._send(200, {"ok": False,
                    "error": "couldn't compose a workflow from that — try describing the trigger, the steps, and who/what handles each, then build again."})
            try:
                result = compose_engine.compile_spec(spec, ROOT, os.path.join(ROOT, "builds"),
                                                     os.path.join(ROOT, "tests"), stamp)
            except Exception as e:
                return self._send(200, {"ok": False, "error": "compile failed: " + str(e)})
            append_command("build " + spec["name"], result["receipt"]["result"] != "UNAUDITED", 0)
            rec = result["receipt"]      # persist a structured workflow record + ledger the build
            jsave(os.path.join(WS, "workflows", spec["name"] + ".json"), {
                "id": spec["name"], "title": rec.get("title"), "trigger": rec.get("trigger"),
                "status": rec["result"], "steps": rec.get("nodes", []),
                "audited_pieces": [p["name"] for p in rec.get("audited_pieces", [])],
                "needs_audit": [u["label"] for u in rec.get("unaudited_steps", [])],
                "artifact": rec.get("artifact"), "integrity_root": rec.get("integrity_root"), "updated": stamp})
            audit_log("build", {"workflow": spec["name"], "result": rec["result"],
                                "audited_pieces": len(rec.get("audited_pieces", [])),
                                "needs_audit": len(rec.get("unaudited_steps", [])),
                                "external_sockets": rec.get("external_sockets"),
                                "integrity_root": rec.get("integrity_root")})
            try:
                preview = render_ui_preview(spec, result)   # 6d: zero-CDN blueprint at /ui/<id>
            except Exception:
                preview = None
            return self._send(200, {"ok": True, "preview": preview, **result})
        if path == "/api/flow/run":      # run the RailCall-BUILT workflow ON data — build + run are ONE workflow
            wf = body.get("workflow")
            spec = None
            if wf:
                spec = jload(os.path.join(ROOT, "tests", "workflow_" + wf + "_receipt.json"), {}).get("spec")
            if not spec:                 # else the most recently built workflow
                fs = sorted(glob.glob(os.path.join(ROOT, "tests", "workflow_*receipt*.json")), key=os.path.getmtime)
                if fs:
                    spec = jload(fs[-1], {}).get("spec")
            if not spec:
                return self._send(200, {"ok": False, "error": "no built workflow found — build one first"})
            data_file = os.path.basename(body.get("data", "ar_pipeline.csv"))
            fp, _w = _find_upload(data_file)
            if not fp:
                cand = os.path.join(ROOT, "fixtures", data_file)
                fp = cand if os.path.isfile(cand) else None
            if not fp:
                return self._send(200, {"ok": False, "error": "data file not found: " + data_file})
            rows = flow_engine.rows_from_csv(open(fp, encoding="utf-8", errors="ignore").read())
            res = flow_engine.run_spec(spec, rows, now_iso(), stage_map=body.get("stage_map"))
            jsave(os.path.join(WS, "flow_receipts", "flow_" + (spec.get("name") or "wf") + ".json"), res["receipt"])
            audit_log("flow_run", {"workflow": spec.get("name"), "records": res["receipt"]["records_processed"],
                                   "actions_queued": res["receipt"]["actions_queued"],
                                   "stage_map_source": res["receipt"].get("stage_map_source")})
            return self._send(200, {"ok": True, **res})
        if path == "/api/flow/automap":   # propose a stage_map: distinct data statuses x workflow steps (deterministic)
            wf = body.get("workflow")
            spec = jload(os.path.join(ROOT, "tests", "workflow_" + wf + "_receipt.json"), {}).get("spec") if wf else None
            if not spec:
                return self._send(200, {"ok": False, "error": "no built workflow found — build one first"})
            data_file = os.path.basename(body.get("data", "ar_pipeline.csv"))
            fp, _w = _find_upload(data_file)
            if not fp:
                cand = os.path.join(ROOT, "fixtures", data_file)
                fp = cand if os.path.isfile(cand) else None
            if not fp:
                return self._send(200, {"ok": False, "error": "data file not found: " + data_file})
            rows = flow_engine.rows_from_csv(open(fp, encoding="utf-8", errors="ignore").read())
            steps = [s.get("label", "") for s in spec.get("steps", [])]
            return self._send(200, {"ok": True, "steps": steps,
                                    "statuses": flow_engine.distinct_statuses(rows),
                                    "proposed": flow_engine.propose_stage_map(rows, steps),
                                    "spec_stage_map": spec.get("stage_map") or {}})
        if path == "/api/commands/validate":   # Semantic Firewall on demand; failure -> failed_with_receipt
            return self._send(200, validate_command(body.get("command_id"), body.get("inputs", {}),
                                                    body.get("claimed"), body.get("intent", "")))
        if path == "/api/commands/preview":     # deterministic airlock card (+ a pending_approval receipt for writes)
            return self._send(200, preview_command(body.get("command_id"), body.get("inputs", {}), body.get("intent", "")))
        if path == "/api/commands/approve":     # bind an explicit human approval to the exact payload
            return self._send(200, approve_command(body.get("command_id"), body.get("inputs", {}),
                                                   body.get("method", "ui_click"), body.get("intent", "")))
        if path == "/api/commands/execute":     # governed execute — writes require a matching approval, every path -> receipt
            return self._send(200, {"ok": True, "receipt": execute_command(body.get("command_id"),
                                                                           body.get("inputs", {}), body.get("intent", ""))})
        if path == "/api/receipts/verify":   # run the INDEPENDENT auditor on one receipt -> a live verdict for its UI card
            # Prefer verify-BY-ID: the server reloads the CANONICAL receipt bytes from disk and audits those.
            # This is both safer (a client can't pre-mutate the body it asks us to bless) and avoids a JS
            # JSON round-trip silently corrupting integrity — e.g. a whole-number float like 145185.0 comes
            # back from the browser as int 145185, which would otherwise FALSE-FAIL the integrity recompute.
            # A raw {"receipt": {...}} body is still honored (tests, ad-hoc tamper probes).
            rid = body.get("id")
            if rid is not None:
                rc = read_receipt(rid)
                if not isinstance(rc, dict):
                    return self._send(200, {"ok": True, "verdict": "UNKNOWN", "checks": [],
                                            "error": "receipt id not found: %r" % (rid,)})
            else:
                rc = body.get("receipt")
            if not isinstance(rc, dict):
                return self._send(200, {"ok": True, "verdict": "UNKNOWN", "error": "receipt must be an object", "checks": []})
            sch = rc.get("schema")
            # A RECOGNIZED schema MUST produce a verdict from the auditor's checks. If the auditor raises on a
            # malformed-but-recognized receipt, that is a granular FAIL (a failing check naming the error) —
            # NEVER an UNKNOWN-with-empty-checks collapse that could read as "couldn't tell". Only a schema we
            # have NO auditor for is honestly UNKNOWN (empty checks, with a reason). No fake-green either way.
            recognized = sch in ("railcall_command_receipt.v1", "railcall_flow_receipt.v0",
                                  "railcall_batch_receipt.v1", "railcall_workflow_receipt.v1")
            if not recognized:
                return self._send(200, {"ok": True, "verdict": "UNKNOWN", "checks": [],
                                        "error": "no auditor for schema %r" % (sch,)})
            try:
                if sch == "railcall_command_receipt.v1":
                    checks = auditor.audit_command_receipt(rc)
                elif sch == "railcall_flow_receipt.v0":
                    checks = auditor.audit_flow_receipt(rc)
                elif sch == "railcall_batch_receipt.v1":
                    checks = auditor.audit_batch_receipt(rc)
                else:   # railcall_workflow_receipt.v1
                    comps, combos, sha = auditor.load_treasury()
                    checks = auditor.audit_receipt(rc, comps, combos, sha, standalone=not (comps or combos))
            except Exception as e:
                # recognized receipt the auditor could not process -> FAIL CLOSED with the specific reason
                checks = [("auditor could not verify this receipt (malformed)", False,
                           "%s: %s" % (type(e).__name__, str(e)[:120]))]
            allok = all(o for _, o, _ in checks) if checks else None
            verdict = "PASS" if allok else ("FAIL" if allok is False else "UNKNOWN")
            return self._send(200, {"ok": True, "verdict": verdict, "checks": [[n, bool(o)] for n, o, _ in checks]})
        if path == "/api/upload":         # local file in (loopback). Stays on disk; NEVER transmitted anywhere.
            return self._send(200, save_upload(body))
        if path == "/api/workflow/signup_to_sheet":
            # FIRST REAL OUTBOUND RAIL. dry_run=true (default) → compose+receipt, zero external.
            # dry_run=false + SHEET_WEBHOOK_URL in vault → real POST to the Apps Script endpoint.
            dry = body.get("dry_run", True)
            override = body.get("payload")  # optional test payload
            res = run_signup_to_sheet(dry_run=bool(dry), payload_override=override)
            return self._send(200, res)
        if path == "/api/webhook_out/test":
            # send a governed test event to ANY webhook URL (Slack/Discord/Make/Sheet/generic).
            # url is transient — used for this call only, never stored, never logged.
            url = (body.get("url") or "").strip()
            target = body.get("target", "generic")
            msg = body.get("message")
            dry = body.get("dry_run", True)
            if not dry and not (url.startswith("https://") or url.startswith("http://127.0.0.1") or url.startswith("http://localhost")):
                return self._send(200, {"ok": False, "error": "that doesn't look like a valid webhook URL — use https://… (or http://localhost… for a local test)"})
            return self._send(200, run_webhook_out(url, target, msg, dry_run=bool(dry)))
        if path == "/api/workflow/signup_to_sheet/status":
            vault = jload(os.path.join(WS, "keys.local.json"), {})
            raw = vault.get("google_sheet")
            url = _pick(raw, "SHEET_WEBHOOK_URL") if isinstance(raw, dict) else (raw if isinstance(raw, str) else "")
            last = _latest_webhook_payload()
            last_email = ""
            if last:
                body2 = last.get("body") or last
                if isinstance(body2, str):
                    try: body2 = json.loads(body2)
                    except Exception: body2 = {}
                last_email = body2.get("email", "") if isinstance(body2, dict) else ""
            # read last sheet_send audit event
            last_send = None
            ap = os.path.join(WS, "integration_audit.jsonl")
            if os.path.exists(ap):
                for ln in reversed(open(ap).read().splitlines()):
                    try:
                        e = json.loads(ln)
                        if e.get("type") == "sheet_send":
                            last_send = e; break
                    except Exception: pass
            return self._send(200, {"url_configured": bool(url), "has_webhook_payload": bool(last),
                                    "last_webhook_email": last_email, "last_send": last_send})
        if path == "/api/note":          # save a folder note (persist)
            notes = jload(os.path.join(WS, "folder_notes.json"), {})
            notes[str(body.get("folder", ""))] = str(body.get("note", ""))
            jsave(os.path.join(WS, "folder_notes.json"), notes)
            return self._send(200, {"ok": True})
        if path == "/api/active":         # switch the active session (persist)
            wsj = jload(os.path.join(WS, "workspace.json"), {})
            wsj["active_session"] = body.get("id")
            jsave(os.path.join(WS, "workspace.json"), wsj)
            return self._send(200, {"ok": True})
        if path == "/api/session":        # create OR merge-update a session; never drops its command history
            sess = jload(os.path.join(WS, "sessions.json"), [])
            s = body.get("session", {})
            sid = s.get("id")
            existing = next((x for x in sess if x.get("id") == sid), None) if sid else None
            if existing:
                for k, v in s.items():
                    if k != "commands":
                        existing[k] = v
                existing["updated"] = time.time()
                out_id = existing["id"]
            else:
                s.setdefault("id", "s" + str(int(time.time())))
                s.setdefault("commands", [])
                s["updated"] = time.time()
                sess.insert(0, s)
                out_id = s["id"]
            jsave(os.path.join(WS, "sessions.json"), sess)
            return self._send(200, {"ok": True, "id": out_id})
        if path == "/api/router/bind":     # Phase 6a: map a role -> a vault key. No network. key_id="" unbinds.
            role, kid = body.get("role"), body.get("key_id", "")
            if role not in ROUTER_ROLES:
                return self._send(400, {"error": "unknown role"})
            vault = jload(os.path.join(WS, "keys.local.json"), {})
            if kid and (kid not in vault or not vault.get(kid)):
                return self._send(400, {"error": "no vault key for '%s' — paste it in INTEGRATIONS first" % kid})
            b = jload(_router_path(), {})
            if kid:
                b[role] = {"key_id": kid, "state": "bound",
                           "bound_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
                audit_log("router_bind", {"role": role, "key_id": kid})
            else:
                b.pop(role, None)
                audit_log("router_unbind", {"role": role})
            jsave(_router_path(), b)
            return self._send(200, router_state())
        if path == "/api/router/test":     # Phase 6a: LOCAL preflight ONLY — confirms the key exists. NO provider ping.
            role = body.get("role")
            if role not in ROUTER_ROLES:
                return self._send(400, {"error": "unknown role"})
            b = jload(_router_path(), {})
            vault = jload(os.path.join(WS, "keys.local.json"), {})
            kid = (b.get(role) or {}).get("key_id") or ""
            if not kid:
                res = "unbound"
            elif kid not in vault or not vault.get(kid):
                res = "missing_key"
            else:
                res = "preflight_ok"
            audit_log("router_preflight", {"role": role, "key_id": kid, "result": res})
            return self._send(200, {"role": role, "key_id": kid, "result": res, "external": False,
                                    "note": "local preflight only — live provider ping is wired in Phase 6b"})
        if path == "/api/route":           # Phase 6b: run a role through the router. Default = deterministic local floor.
            # Fail CLOSED with JSON. A hand-crafted raw spec (missing outputs/title/trigger) reaches the FROZEN
            # compile/render via the local floor and can raise KeyError — that must NOT drop the connection
            # (HTTP 000). The UI never sends a raw spec here, but this is a public loopback endpoint.
            try:
                result, meta = route(body.get("role"), body.get("payload") or {}, bool(body.get("opt_in")), body.get("model"))
            except Exception as e:
                return self._send(200, {"result": {"ok": False, "error": "route failed: %s: %s" % (type(e).__name__, str(e)[:120])},
                                        "meta": {"path": "error", "role": body.get("role"), "external": False}})
            audit_log("route", {"role": body.get("role"), "path": meta.get("path"), "external": bool(meta.get("external"))})
            return self._send(200, {"result": result, "meta": meta})
        if path == "/api/integration":    # BYOK: single key, multi-field dict, OR one named field. Stays LOCAL.
            iid = body.get("id")
            if not iid or not isinstance(iid, str):
                return self._send(400, {"ok": False, "error": "integration id required"})
            field, value = body.get("field"), body.get("value", "")
            key, fields = body.get("key", ""), body.get("fields")
            keypath = os.path.join(WS, "keys.local.json")
            if field:                      # save/clear ONE named key (the manual's per-key rows)
                keys = jload(keypath, {})
                cur = keys.get(iid) if isinstance(keys.get(iid), dict) else {}
                if value:
                    cur[field] = value
                else:
                    cur.pop(field, None)
                if cur:
                    keys[iid] = cur
                else:
                    keys.pop(iid, None)
                save_secret(keypath, keys)
                has = bool(cur)
            else:
                has = bool(key) or bool(fields)
                keys = jload(keypath, {})
                if has:
                    keys[iid] = fields if fields else key
                else:
                    keys.pop(iid, None)
                save_secret(keypath, keys)
            ints = jload(os.path.join(WS, "integrations.json"), {})
            for cat in ints.values():
                for it in cat:
                    if it.get("id") == iid:
                        it["status"] = "key_present" if has else "not_configured"
            jsave(os.path.join(WS, "integrations.json"), ints)
            if has:
                audit_log("byok_save", {"integration": iid})
                integration_audit("integration_key_saved", {"provider": iid, "key": field or "key", "secret_value_logged": False})
            return self._send(200, {"ok": True, "prompt_community": iid in ("discord", "telegram")})
        if path == "/api/integration_test":   # HONEST read-only connection test. LLMs: real ping. Others: not wired yet.
            iid = body.get("id")
            key = jload(os.path.join(WS, "keys.local.json"), {}).get(iid)
            status, detail = test_integration(iid, key)
            ints = jload(os.path.join(WS, "integrations.json"), {})
            for cat in ints.values():
                for it in cat:
                    if it.get("id") == iid:
                        it["status"] = status
                        it["last_tested"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            jsave(os.path.join(WS, "integrations.json"), ints)
            audit_log("integration_test", {"integration": iid, "status": status})
            integration_audit("integration_test", {"provider": iid, "result": status,
                                                    "error": detail if status == "failed" else None})
            return self._send(200, {"ok": True, "status": status, "detail": detail})
        return self._send(404, {"error": "not found"})

    def log_message(self, *a):
        pass


class _Srv(socketserver.ThreadingMixIn, socketserver.TCPServer):
    # Threaded so a single stalled/slowloris connection can't starve every other client (one worker per
    # connection). Still bound to 127.0.0.1 only (see HOST below) → threads are loopback-only, no LAN exposure.
    daemon_threads = True          # don't let a hung worker block process exit
    allow_reuse_address = True


if __name__ == "__main__":
    seed_workspace()
    url = f"http://{HOST}:{PORT}"
    no_open = "--no-open" in sys.argv
    try:
        srv = _Srv((HOST, PORT), H)
    except OSError:                       # already running → just open the tab, don't crash
        sys.stdout.write(f"RailCall Studio already running → {url}\n")
        if not no_open:
            import webbrowser
            webbrowser.open(url)
        sys.exit(0)
    if not no_open:                       # the launcher: pop a loopback tab in the default browser
        import webbrowser
        import threading
        threading.Timer(0.7, lambda: webbrowser.open(url)).start()
    sys.stdout.write(f"RailCall Studio → {url}  (loopback only · workspace {WS})\n")
    sys.stdout.flush()
    srv.serve_forever()
