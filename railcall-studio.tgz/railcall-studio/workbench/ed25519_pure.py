#!/usr/bin/env python3
"""
Pure-Python Ed25519 (RFC 8032) — ZERO dependencies, stdlib only (hashlib for SHA-512).

This is the PUBLIC-DOMAIN readable reference implementation of Ed25519 (the one published with
the original Ed25519 paper / mirrored in RFC 8032 §6 and the `python-ed25519` / `ed25519.py`
reference by Daniel J. Bernstein, Niels Duif, Tanja Lange, Peter Schwabe, Bo-Yin Yang — released
into the public domain). It is the readable reference, NOT a C library binding. RailCall's product
promise is "pure stdlib, no pip install", so we vendor the math instead of depending on pynacl /
cryptography.

It MUST pass the official RFC 8032 §7.1 known-answer vectors (TEST 1-4). Run this file directly:

    python3 workbench/ed25519_pure.py

and it asserts the four vectors (sign a known seed+message, compare to the RFC expected signature
hex) and a verify round-trip. If any vector fails it exits non-zero and prints which — do NOT ship
crypto that fails the vectors.

Public API used by RailCall:
    publickey_from_seed(seed32: bytes) -> bytes        # 32-byte public key from a 32-byte seed
    sign(message: bytes, seed32, pubkey32) -> bytes    # 64-byte signature
    verify(signature64, message, pubkey32) -> bool     # True iff valid (never raises on bad input)
    key_id(pubkey32: bytes) -> str                     # short stable id (sha256(pubkey)[:16] hex)
"""
import hashlib

# ---- curve constants (Ed25519 / edwards25519) ----
b = 256
q = 2 ** 255 - 19
L = 2 ** 252 + 27742317777372353535851937790883648493   # group order


def _H(m):
    return hashlib.sha512(m).digest()


def _expmod(b_, e, m):
    if e == 0:
        return 1
    t = _expmod(b_, e // 2, m) ** 2 % m
    if e & 1:
        t = (t * b_) % m
    return t


def _inv(x):
    return _expmod(x, q - 2, q)


d = (-121665 * _inv(121666)) % q
I = _expmod(2, (q - 1) // 4, q)


def _xrecover(y):
    xx = (y * y - 1) * _inv(d * y * y + 1)
    x = _expmod(xx, (q + 3) // 8, q)
    if (x * x - xx) % q != 0:
        x = (x * I) % q
    if x % 2 != 0:
        x = q - x
    return x


By = 4 * _inv(5) % q
Bx = _xrecover(By)
B = [Bx % q, By % q]


def _edwards(P, Q):
    x1, y1 = P
    x2, y2 = Q
    x3 = (x1 * y2 + x2 * y1) * _inv(1 + d * x1 * x2 * y1 * y2)
    y3 = (y1 * y2 + x1 * x2) * _inv(1 - d * x1 * x2 * y1 * y2)
    return [x3 % q, y3 % q]


def _scalarmult(P, e):
    if e == 0:
        return [0, 1]
    Q = _scalarmult(P, e // 2)
    Q = _edwards(Q, Q)
    if e & 1:
        Q = _edwards(Q, P)
    return Q


def _encodeint(y):
    bits = [(y >> i) & 1 for i in range(b)]
    return bytes([sum([bits[i * 8 + j] << j for j in range(8)]) for i in range(b // 8)])


def _encodepoint(P):
    x, y = P
    bits = [(y >> i) & 1 for i in range(b - 1)] + [x & 1]
    return bytes([sum([bits[i * 8 + j] << j for j in range(8)]) for i in range(b // 8)])


def _bit(h, i):
    return (h[i // 8] >> (i % 8)) & 1


def publickey(sk):
    """sk = 32-byte secret seed -> 32-byte public key (RFC 8032 'A')."""
    h = _H(sk)
    a = 2 ** (b - 2) + sum(2 ** i * _bit(h, i) for i in range(3, b - 2))
    A = _scalarmult(B, a)
    return _encodepoint(A)


def _Hint(m):
    h = _H(m)
    return sum(2 ** i * _bit(h, i) for i in range(2 * b))


def signature(m, sk, pk):
    """m, sk(32-byte seed), pk(32-byte pubkey) -> 64-byte signature."""
    h = _H(sk)
    a = 2 ** (b - 2) + sum(2 ** i * _bit(h, i) for i in range(3, b - 2))
    r = _Hint(bytes([h[i] for i in range(b // 8, b // 4)]) + m)
    R = _scalarmult(B, r)
    S = (r + _Hint(_encodepoint(R) + pk + m) * a) % L
    return _encodepoint(R) + _encodeint(S)


def _isoncurve(P):
    x, y = P
    return (-x * x + y * y - 1 - d * x * x * y * y) % q == 0


def _decodeint(s):
    return sum(2 ** i * _bit(s, i) for i in range(0, b))


def _decodepoint(s):
    y = sum(2 ** i * _bit(s, i) for i in range(0, b - 1))
    x = _xrecover(y)
    if x & 1 != _bit(s, b - 1):
        x = q - x
    P = [x, y]
    if not _isoncurve(P):
        raise ValueError("decoding point that is not on curve")
    return P


def checkvalid(s, m, pk):
    """Reference RFC 8032 verify. Raises on malformed input; returns True/False otherwise.
    Use verify() (below) for the never-raises wrapper RailCall calls."""
    if len(s) != b // 4:
        raise ValueError("signature length is wrong")
    if len(pk) != b // 8:
        raise ValueError("public-key length is wrong")
    R = _decodepoint(s[0:b // 8])
    A = _decodepoint(pk)
    S = _decodeint(s[b // 8:b // 4])
    h = _Hint(_encodepoint(R) + pk + m)
    return _scalarmult(B, S) == _edwards(R, _scalarmult(A, h))


# ---------------------------------------------------------------------------
# RailCall-facing API (byte-oriented, never raises on bad input for verify)
# ---------------------------------------------------------------------------
def publickey_from_seed(seed32):
    """32-byte seed -> 32-byte Ed25519 public key."""
    if not isinstance(seed32, (bytes, bytearray)) or len(seed32) != 32:
        raise ValueError("seed must be exactly 32 bytes")
    return publickey(bytes(seed32))


def sign(message, seed32, pubkey32):
    """message bytes + 32-byte seed + 32-byte pubkey -> 64-byte signature."""
    if not isinstance(message, (bytes, bytearray)):
        raise ValueError("message must be bytes")
    if len(seed32) != 32 or len(pubkey32) != 32:
        raise ValueError("seed and pubkey must be 32 bytes each")
    return signature(bytes(message), bytes(seed32), bytes(pubkey32))


def verify(signature64, message, pubkey32):
    """True iff signature64 (64 bytes) is a valid Ed25519 signature of message under pubkey32.
    NEVER raises — any malformed input / failed check returns False (an attacker-supplied receipt
    must produce an honest FALSE, not crash the auditor)."""
    try:
        if not isinstance(signature64, (bytes, bytearray)) or len(signature64) != 64:
            return False
        if not isinstance(pubkey32, (bytes, bytearray)) or len(pubkey32) != 32:
            return False
        if not isinstance(message, (bytes, bytearray)):
            return False
        return bool(checkvalid(bytes(signature64), bytes(message), bytes(pubkey32)))
    except Exception:
        return False


def key_id(pubkey32):
    """Short, stable id for a public key: first 16 hex chars of sha256(pubkey). Public, not secret."""
    return hashlib.sha256(bytes(pubkey32)).hexdigest()[:16]


# ---------------------------------------------------------------------------
# RFC 8032 §7.1 known-answer vectors (TEST 1-4), verbatim from the RFC.
# The self-test PROVES the math: derive pubkey from seed, sign the message, and assert both the
# public key AND the 64-byte signature equal the RFC's expected hex, plus a verify round-trip.
# ---------------------------------------------------------------------------
# TEST 4's message is exactly 1023 bytes (2046 hex chars), verbatim from RFC 8032 §7.1.
_RFC8032_TEST4_MSG = (
    "08b8b2b733424243760fe426a4b54908632110a66c2f6591eabd3345e3e4eb98"
    "fa6e264bf09efe12ee50f8f54e9f77b1e355f6c50544e23fb1433ddf73be84d8"
    "79de7c0046dc4996d9e773f4bc9efe5738829adb26c81b37c93a1b270b20329d"
    "658675fc6ea534e0810a4432826bf58c941efb65d57a338bbd2e26640f89ffbc"
    "1a858efcb8550ee3a5e1998bd177e93a7363c344fe6b199ee5d02e82d522c4fe"
    "ba15452f80288a821a579116ec6dad2b3b310da903401aa62100ab5d1a36553e"
    "06203b33890cc9b832f79ef80560ccb9a39ce767967ed628c6ad573cb116dbef"
    "efd75499da96bd68a8a97b928a8bbc103b6621fcde2beca1231d206be6cd9ec7"
    "aff6f6c94fcd7204ed3455c68c83f4a41da4af2b74ef5c53f1d8ac70bdcb7ed1"
    "85ce81bd84359d44254d95629e9855a94a7c1958d1f8ada5d0532ed8a5aa3fb2"
    "d17ba70eb6248e594e1a2297acbbb39d502f1a8c6eb6f1ce22b3de1a1f40cc24"
    "554119a831a9aad6079cad88425de6bde1a9187ebb6092cf67bf2b13fd65f270"
    "88d78b7e883c8759d2c4f5c65adb7553878ad575f9fad878e80a0c9ba63bcbcc"
    "2732e69485bbc9c90bfbd62481d9089beccf80cfe2df16a2cf65bd92dd597b07"
    "07e0917af48bbb75fed413d238f5555a7a569d80c3414a8d0859dc65a46128ba"
    "b27af87a71314f318c782b23ebfe808b82b0ce26401d2e22f04d83d1255dc51a"
    "ddd3b75a2b1ae0784504df543af8969be3ea7082ff7fc9888c144da2af58429e"
    "c96031dbcad3dad9af0dcbaaaf268cb8fcffead94f3c7ca495e056a9b47acdb7"
    "51fb73e666c6c655ade8297297d07ad1ba5e43f1bca32301651339e22904cc8c"
    "42f58c30c04aafdb038dda0847dd988dcda6f3bfd15c4b4c4525004aa06eeff8"
    "ca61783aacec57fb3d1f92b0fe2fd1a85f6724517b65e614ad6808d6f6ee34df"
    "f7310fdc82aebfd904b01e1dc54b2927094b2db68d6f903b68401adebf5a7e08"
    "d78ff4ef5d63653a65040cf9bfd4aca7984a74d37145986780fc0b16ac451649"
    "de6188a7dbdf191f64b5fc5e2ab47b57f7f7276cd419c17a3ca8e1b939ae49e4"
    "88acba6b965610b5480109c8b17b80e1b7b750dfc7598d5d5011fd2dcc5600a3"
    "2ef5b52a1ecc820e308aa342721aac0943bf6686b64b2579376504ccc493d97e"
    "6aed3fb0f9cd71a43dd497f01f17c0e2cb3797aa2a2f256656168e6c496afc5f"
    "b93246f6b1116398a346f1a641f3b041e989f7914f90cc2c7fff357876e506b5"
    "0d334ba77c225bc307ba537152f3f1610e4eafe595f6d9d90d11faa933a15ef1"
    "369546868a7f3a45a96768d40fd9d03412c091c6315cf4fde7cb68606937380d"
    "b2eaaa707b4c4185c32eddcdd306705e4dc1ffc872eeee475a64dfac86aba41c"
    "0618983f8741c5ef68d3a101e8a3b8cac60c905c15fc910840b94c00a0b9d0"
)


def _selftest_rfc8032():
    """Assert the four RFC 8032 vectors AND a verify round-trip. Returns a (passed, detail) report."""
    import binascii
    detail = []
    ok = True
    vectors = [
        (  # TEST 1 — empty message
            "9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60",
            "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a",
            "",
            "e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e06522490155"
            "5fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b",
        ),
        (  # TEST 2 — 1-byte message
            "4ccd089b28ff96da9db6c346ec114e0f5b8a319f35aba624da8cf6ed4fb8a6fb",
            "3d4017c3e843895a92b70aa74d1b7ebc9c982ccf2ec4968cc0cd55f12af4660c",
            "72",
            "92a009a9f0d4cab8720e820b5f642540a2b27b5416503f8fb3762223ebdb69da"
            "085ac1e43e15996e458f3613d0f11d8c387b2eaeb4302aeeb00d291612bb0c00",
        ),
        (  # TEST 3 — 2-byte message
            "c5aa8df43f9f837bedb7442f31dcb7b166d38535076f094b85ce3a2e0b4458f7",
            "fc51cd8e6218a1a38da47ed00230f0580816ed13ba3303ac5deb911548908025",
            "af82",
            "6291d657deec24024827e69c3abe01a30ce548a284743a445e3680d7db5ac3ac"
            "18ff9b538d16f290ae67f760984dc6594a7c15e9716ed28dc027beceea1ec40a",
        ),
        (  # TEST 4 — 1023-byte message (RFC 8032 §7.1, the "TEST 1024" vector)
            "f5e5767cf153319517630f226876b86c8160cc583bc013744c6bf255f5cc0ee5",
            "278117fc144c72340f67d0f2316e8386ceffbf2b2428c9c51fef7c597f1d426e",
            _RFC8032_TEST4_MSG,
            "0aab4c900501b3e24d7cdf4663326a3a87df5e4843b2cbdb67cbf6e460fec350"
            "aa5371b1508f9f4528ecea23c436d94b5e8fcd4f681e30a6ac00a9704a188a03",
        ),
    ]
    for i, (sk_hex, pk_hex, msg_hex, sig_hex) in enumerate(vectors, 1):
        sk = binascii.unhexlify(sk_hex)
        msg = binascii.unhexlify(msg_hex)
        want_pk = binascii.unhexlify(pk_hex)
        want_sig = binascii.unhexlify(sig_hex)
        got_pk = publickey(sk)
        got_sig = signature(msg, sk, got_pk)
        pk_ok = (got_pk == want_pk)
        sig_ok = (got_sig == want_sig)
        ver_ok = checkvalid(got_sig, msg, got_pk)
        passed = pk_ok and sig_ok and ver_ok
        ok = ok and passed
        detail.append("RFC 8032 TEST %d: pubkey %s, signature %s, verify %s" % (
            i,
            "OK" if pk_ok else "MISMATCH",
            "OK" if sig_ok else "MISMATCH",
            "OK" if ver_ok else "FAIL"))
    return ok, detail


if __name__ == "__main__":
    import sys
    passed, detail = _selftest_rfc8032()
    for line in detail:
        print(("  ok   " if "MISMATCH" not in line and "FAIL" not in line else "  FAIL ") + line)
    if not passed:
        print("\nED25519 SELF-TEST FAIL — vectors did not match. DO NOT SHIP.")
        sys.exit(1)
    print("\nED25519 SELF-TEST PASS — RFC 8032 TEST 1-4 vectors verified (pure stdlib, no pip).")
    sys.exit(0)
