#!/usr/bin/env python3
"""
RailCall Approval Airlock + Semantic Firewall (v0).

The product sentence this enforces:
  RailCall can chat about work, but it CANNOT mutate work until a schema-valid command crosses the
  Approval Airlock and the human approves the EXACT payload that will be executed.

commands.json is the source of truth — the model is never trusted. Flow:
  intent -> command candidate -> SCHEMA VALIDATION (firewall) -> deterministic airlock card -> human
  approval -> execution OR blocked receipt -> audit log.

Nothing here opens a socket. The integrity_hash binds: command schema version + resolved command +
command mode/provider/risk + approved payload hash + approval metadata + execution result metadata +
artifact. (mode/provider/risk are covered so a tampered receipt can't dodge the approval guard by
flipping a write down to a read — the auditor's _cmd_integrity must mirror this exact cover.)
"""
import json
import hashlib

SCHEMA_VERSION = "commands.v0"
SECRET_HINT = ("token", "key", "secret", "password", "apikey", "authorization", "bearer", "dsn")
EXEC_CLASS = {
    "executed": "executed", "available_read_only": "read_only", "approved_not_executed": "approved",
    "pending_approval": "pending", "blocked_by_policy": "blocked", "not_wired_yet": "not_wired",
    "not_configured": "not_configured", "failed_with_receipt": "failed", "failed_safely": "failed_safe",
}
WRITE_MODES = ("write_requires_approval", "write_blocked")


# ---- deterministic payload binding ----
def canonical(inputs):
    return json.dumps(inputs or {}, sort_keys=True, separators=(",", ":"), default=str)


def payload_hash(command_id, inputs):
    return "sha256:" + hashlib.sha256((str(command_id) + "\n" + canonical(inputs)).encode()).hexdigest()


def idempotency_key(command_id, inputs):
    return "idem_" + hashlib.sha256((str(command_id) + "|" + canonical(inputs)).encode()).hexdigest()[:24]


def redact(inputs):
    out = {}
    for k, v in (inputs or {}).items():
        if any(h in str(k).lower() for h in SECRET_HINT):
            out[k] = "••••••"
        elif isinstance(v, str) and len(v) > 300:
            out[k] = v[:300] + "…"
        else:
            out[k] = v
    return out


# ---- the Semantic Firewall ----
def validate(cmd, inputs, claimed=None):
    """cmd = the authoritative command dict from commands.json. claimed = what the model/caller ASSERTED
    (command_id/provider/mode/risk/approval_requirement), checked against cmd. Returns (ok, errors)."""
    errors = []
    if cmd is None:
        return False, ["command id mismatch: unknown command (not in commands.json)"]
    schema = cmd.get("input_schema") or {}
    inputs = inputs or {}
    for field, spec in schema.items():
        if spec.get("required") and (field not in inputs or inputs[field] in (None, "", [])):
            errors.append("missing required field: " + field)
        if field in inputs and inputs[field] is not None:
            t, v = spec.get("type"), inputs[field]
            ok = (t == "array" and isinstance(v, list)) or (t == "string" and isinstance(v, str)) or \
                 (t == "number" and isinstance(v, (int, float)) and not isinstance(v, bool)) or \
                 (t == "object" and isinstance(v, dict)) or t is None
            if not ok:
                errors.append("wrong type for '%s' (want %s)" % (field, t))
    for field in inputs:
        if field not in schema:
            errors.append("unknown field: " + field)
    for field, v in inputs.items():
        if isinstance(v, str):
            if "\x00" in v:
                errors.append("unsafe value in '%s' (null byte)" % field)
            if len(v) > 20000:
                errors.append("unsafe value in '%s' (too large)" % field)
    if claimed:
        if claimed.get("command_id") and claimed["command_id"] != cmd.get("id"):
            errors.append("command id mismatch: claimed %r != %r" % (claimed["command_id"], cmd.get("id")))
        if claimed.get("provider") and claimed["provider"] != cmd.get("provider"):
            errors.append("provider mismatch: claimed %r != %r" % (claimed["provider"], cmd.get("provider")))
        if claimed.get("mode") and claimed["mode"] != cmd.get("mode"):
            errors.append("mode mismatch: claimed %r != %r" % (claimed["mode"], cmd.get("mode")))
        if claimed.get("risk") and claimed["risk"] != cmd.get("risk"):
            errors.append("risk mismatch: claimed %r != %r" % (claimed["risk"], cmd.get("risk")))
        if cmd.get("mode") in WRITE_MODES and claimed.get("approval_requirement") == "none":
            errors.append("policy violation: a write command cannot declare approval_requirement=none")
    return (len(errors) == 0), errors


# ---- the deterministic airlock card ----
def airlock_card(cmd, inputs, status, stamp):
    external = cmd.get("provider") != "railcall"
    return {
        "command_id": cmd.get("id"), "title": cmd.get("title"), "provider": cmd.get("provider"),
        "mode": cmd.get("mode"), "risk": cmd.get("risk"),
        "required_integration": cmd.get("provider") if external else None,
        "payload": redact(inputs), "expected_external_touch": external,
        "approval_requirement": "required" if status == "available_write_requires_approval" else "none",
        "payload_hash": payload_hash(cmd.get("id"), inputs),
        "idempotency_key": idempotency_key(cmd.get("id"), inputs),
        "status": status, "created": stamp,
    }


def bind_approval(command_id, inputs, method, stamp):
    """Bind a human approval to the EXACT payload. method = ui_click | terminal_confirm."""
    return {"method": method, "timestamp": stamp, "approved_payload_hash": payload_hash(command_id, inputs)}


# ---- the receipt (binds approval to executed payload) ----
def _integrity(body):
    # SECURITY: mode/provider/risk/approval_requirement/required_integration are covered so a tampered
    # receipt can't flip a write down to a read to skip the "executed write needs approval" guard.
    # audit_workflow._cmd_integrity MUST use this exact tuple or every v1 receipt fails verification.
    cover = {k: body.get(k) for k in ("command_schema_version", "resolved_command_id", "payload_hash",
                                      "approval", "pre_execution_hash", "post_execution_result_hash",
                                      "result_status", "external_api_touched", "artifact_path",
                                      "mode", "provider", "risk", "approval_requirement",
                                      "required_integration")}
    return "sha256:" + hashlib.sha256(json.dumps(cover, sort_keys=True, default=str).encode()).hexdigest()


def make_receipt(cmd, inputs, intent, result_status, stamp, approval=None, external_touched=False,
                 artifact=None, output=None, note="", post_result=None):
    cid = cmd.get("id") if cmd else None
    ph = payload_hash(cid, inputs) if cmd else None
    pre = "sha256:" + hashlib.sha256(((cid or "?") + "|" + (ph or "")).encode()).hexdigest()
    post = None
    if post_result is not None:
        post = "sha256:" + hashlib.sha256(json.dumps(post_result, sort_keys=True, default=str).encode()).hexdigest()
    body = {
        "schema": "railcall_command_receipt.v1",
        "command_schema_version": SCHEMA_VERSION,
        "timestamp": stamp,
        "user_intent": intent or "",
        "resolved_command_id": cid,
        "provider": cmd.get("provider") if cmd else None,
        "mode": cmd.get("mode") if cmd else None,
        "risk": cmd.get("risk") if cmd else None,
        "required_integration": (cmd.get("provider") if cmd and cmd.get("provider") != "railcall" else None),
        "input_fields": sorted((inputs or {}).keys()),
        "payload_hash": ph,
        "idempotency_key": idempotency_key(cid, inputs) if cmd else None,
        "approval_requirement": "required" if (cmd and cmd.get("mode") in WRITE_MODES) else "none",
        "approval": approval,
        "pre_execution_hash": pre,
        "post_execution_result_hash": post,
        "external_api_touched": bool(external_touched),
        "result_status": result_status,
        "execution_class": EXEC_CLASS.get(result_status, "none"),
        "artifact_path": artifact,
        "note": note,
        "output": redact(output) if isinstance(output, dict) else output,
    }
    body["integrity_hash"] = _integrity(body)
    return body
