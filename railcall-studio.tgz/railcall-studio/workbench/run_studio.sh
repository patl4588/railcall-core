#!/bin/sh
# RailCall Studio launcher — portable. Resolves paths relative to THIS script, loads a BYOK
# key from a .env if one is found (override with RAILCALL_ENV=/path/to/.env), then runs the
# loopback server. No machine-specific paths.
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$HERE/.." && pwd)
for ENVF in "$RAILCALL_ENV" "$ROOT/.env" "$HERE/.env"; do
  if [ -n "$ENVF" ] && [ -f "$ENVF" ]; then
    GROQ_API_KEY=$(grep -E '^GROQ_API_KEY=' "$ENVF" | head -1 | cut -d= -f2- | tr -d '"'\'' \r')
    [ -n "$GROQ_API_KEY" ] && export GROQ_API_KEY
    break
  fi
done
exec python3 "$HERE/studio_server.py" --no-open
