#!/usr/bin/env python3
"""RailCall Workbench bridge — stdlib only, LOOPBACK only (127.0.0.1).

Closes the loop on REAL data — no mockups:
  GET  /api/receipt  → the newest funnel receipt actually on disk      (the DATA bridge)
  POST /api/run      → execute a WHITELISTED compiler command, return its real stdout/exit
                       (the TERMINAL socket)  — strict whitelist, no shell, no arbitrary input
  GET  /              → the workbench page
  GET  /vendor/*      → the locally-vendored xterm.js / xterm.css (zero CDN at runtime)

Binds 127.0.0.1 so the airlock holds: this bridge opens 0 EXTERNAL sockets, and the
compiler it runs proves its own 0-socket airlock in the receipt the canvas then reads.
"""
import http.server
import socketserver
import json
import os
import sys
import glob
import subprocess

HERE = os.path.dirname(os.path.abspath(__file__))   # .../workbench
ROOT = os.path.dirname(HERE)                         # repo root: mcp_server.py, tests/, fixtures/
HOST = "127.0.0.1"
PORT = int(os.environ.get("WB_PORT", "8777"))

# The terminal may run ONLY these. No shell string, no user-supplied args → no injection.
ALLOWED = {
    "build":    [sys.executable, "mcp_server.py", "--build-workflow", "fixtures/lead_history.csv"],
    "workflow": [sys.executable, "mcp_server.py", "--build-workflow", "fixtures/lead_history.csv"],
}


def newest_receipt():
    fs = sorted(glob.glob(os.path.join(ROOT, "tests", "workflow_*receipt*.json")), key=os.path.getmtime)
    if not fs:
        return None, None
    with open(fs[-1], encoding="utf-8") as f:
        return json.load(f), os.path.getmtime(fs[-1])


class Handler(http.server.BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="application/json"):
        b = body if isinstance(body, (bytes, bytearray)) else json.dumps(body).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(b)

    def _file(self, rel, ctype):
        p = os.path.join(HERE, rel)
        if not os.path.isfile(p):
            return self._send(404, {"error": "not found", "path": rel})
        with open(p, "rb") as f:
            self._send(200, f.read(), ctype)

    def do_GET(self):
        path = self.path.split("?")[0]
        if path in ("/", "/workbench.html"):
            return self._file("workbench.html", "text/html; charset=utf-8")
        if path == "/vendor/xterm.js":
            return self._file("vendor/xterm.js", "application/javascript")
        if path == "/vendor/xterm.css":
            return self._file("vendor/xterm.css", "text/css")
        if path == "/api/receipt":
            d, mt = newest_receipt()
            if d is None:
                return self._send(404, {"status": "no_receipt"})
            return self._send(200, {"status": "ok", "mtime": mt, "receipt": d})
        if path == "/api/workflows":
            wf = []
            for p in sorted(glob.glob(os.path.join(ROOT, "tests", "workflow_*receipt*.json")),
                            key=os.path.getmtime, reverse=True):
                try:
                    d = json.load(open(p, encoding="utf-8"))
                    wf.append({"id": d.get("workflow_id"), "result": d.get("result"),
                               "nodes": len(d.get("nodes", [])), "root": str(d.get("integrity_root", ""))[7:15],
                               "file": os.path.basename(p)})
                except Exception:
                    pass
            builds = [os.path.basename(p) for p in sorted(glob.glob(os.path.join(ROOT, "builds", "*.html")))]
            return self._send(200, {"workflows": wf, "builds": builds})
        if path.startswith("/builds/"):
            name = os.path.basename(path[len("/builds/"):])   # basename only — no path traversal
            p = os.path.join(ROOT, "builds", name)
            if name.endswith(".html") and os.path.isfile(p):
                with open(p, "rb") as f:
                    return self._send(200, f.read(), "text/html; charset=utf-8")
            return self._send(404, {"error": "not found"})
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        if self.path.split("?")[0] != "/api/run":
            return self._send(404, {"error": "not found"})
        n = int(self.headers.get("Content-Length", "0") or 0)
        try:
            payload = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            payload = {}
        cmd = str(payload.get("cmd", "")).strip().replace("railcall ", "")
        if cmd not in ALLOWED:
            return self._send(200, {"ok": False, "cmd": cmd, "stdout": "",
                                    "stderr": f"not allowed: {cmd!r}  (whitelist: {list(ALLOWED)})", "exit": 126})
        try:
            p = subprocess.run(ALLOWED[cmd], cwd=ROOT, capture_output=True, text=True, timeout=60)
            return self._send(200, {"ok": p.returncode == 0, "cmd": cmd,
                                    "stdout": p.stdout, "stderr": p.stderr, "exit": p.returncode})
        except Exception as e:
            return self._send(200, {"ok": False, "cmd": cmd, "stdout": "", "stderr": str(e), "exit": 1})

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer((HOST, PORT), Handler) as srv:
        sys.stdout.write(f"RailCall Workbench bridge → http://{HOST}:{PORT}  (loopback only · repo {ROOT})\n")
        sys.stdout.flush()
        srv.serve_forever()
