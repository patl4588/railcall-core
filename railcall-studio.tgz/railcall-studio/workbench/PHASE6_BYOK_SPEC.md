# RailCall Phase 6 — BYOK Multi-Model Role Spec (v0 · DRAFT)

**Status:** SPEC ONLY. No code lands until this is approved. Engine + airlock + dry-run stay frozen; everything below is additive (new surface area only).
**Branch when built:** continues on `studio-ui-v2`.
**One-line:** let a user map *their own* model keys to fixed execution **roles**, route through a local switch that never exposes the platform's internal reasoning provider, and keep every output a DRY-RUN, audited, loopback-previewable blueprint.

---

## 0. The contract in one paragraph
A user pastes their own provider keys into the existing `0600` vault (Phase 2). In a new **ROUTER** surface they bind each key to a **role** (Compose / Sweep / Audit). When a role fires, the local router uses that user's key to call *that user's provider directly over TLS* — the key authorizes one call to the provider it belongs to and is never sent to RailCall servers. Output is always a **draft + receipt** (never a silent write, never a real send). Compose output is **bounded to the pre-coded audited library** — the model arranges audited components, it does not author freehand code. With **zero keys bound, the product still fully works** on the deterministic-local floor. BYOK is an *enhancement layer*, never a dependency.

---

## 1. Two provider layers — the line that must never blur
This is the load-bearing distinction. Get it wrong and we either (a) leak our internal mechanics or (b) make the platform depend on a paid key.

| Layer | Who chooses | Visible to user? | Default |
|---|---|---|---|
| **A. Platform reasoning** (the Kai cascade that powers RailCall's *own* suggestions/compile fallback) | RailCall | **NO** — opaque, swappable. `show active provider` → **refuse** (Constitution). | Deterministic-local + Groq cascade (opt-in env), **never our Anthropic burn** |
| **B. BYOK roles** (the user's keys doing the user's work) | The **user** | **YES** — it's their config; they see/set role→key bindings | **Unbound** → falls back to Layer A's deterministic floor |

Rule: **Layer B is transparent (user's choice), Layer A is opaque (ours).** The router may report *which role* ran and *which of the user's keys* it used; it must never report which provider served a Layer-A platform call.

---

## 2. Roles, not models (the primitive)
We bind keys to **roles**, not models, so the system is provider-agnostic and the UI stays stable as models churn.

| Role | Job | Output | Latency class | Default binding (reassignable) |
|---|---|---|---|---|
| **Compose** | plain-English → structured workflow/UI **recipe** assembled from the audited library | recipe + `railcall_ui_receipt.v0` | seconds | a strong reasoning key (e.g. Claude) |
| **Sweep** | read-only deep scan across high-volume local files (logs, ledgers, CSVs) | findings summary (read-only) | seconds, long-context | a long-context key (e.g. Gemini) |
| **Audit** | fast JSON/schema validation + receipt parsing | pass/fail + reasons | <500ms class | a fast key (e.g. Groq) |
| *(Narrate — optional, default OFF)* | human-readable summaries of receipts/runs | text | seconds | — |

The Claude→Compose / Gemini→Sweep / Groq→Audit mapping from the brief is the **default**, not a hardcode — any key can fill any role. Roles are fixed; bindings are user-owned.

---

## 3. The vault + how a BYOK key is actually used (security perimeter)
- Keys live in `keys.local.json` (dir `0700` / file `0600`), masked `••••••`, never transmitted to RailCall. (Phase 2, already shipped.)
- A bound role's call goes **loopback server → the user's provider API** (e.g. `api.anthropic.com`) over TLS, **using the user's key as the auth header for that one request.** The key never touches a RailCall server, never a log, never a receipt (we store the *role + key-id*, never the secret).
- **Loopback only** (`127.0.0.1`). No LAN/public bind.
- **No surprise spend:** a bound paid key is **opt-in per build**, not a silent default (see §5). The deterministic floor is always free.
- **DRY-RUN persists:** a model can *draft* a recipe/UI; any *write* to disk/config or any *send* stays approval-gated by the existing payload-hash airlock.

---

## 4. Bindings store + model-picker UI
**Store:** `~/.railcall_workspace/role_bindings.json` — references keys by **integration id**, never the secret:
```json
{ "compose": {"key_id": "anthropic", "model": "claude-…", "state": "tested"},
  "sweep":   {"key_id": "gemini",    "model": "…",        "state": "bound"},
  "audit":   {"key_id": "groq",      "model": "…",        "state": "unbound"} }
```
**Surface:** a new left-tree node **`▸ ROUTER`** (sits under SYSTEM). Expanding shows the 3 roles, each a row:
```
▼ 🔀 ROUTER
  ├── compose   → [ anthropic ▾ ]   tested ✓
  ├── sweep     → [ gemini ▾ ]      bound · untested
  └── audit     → [ — bind a key ▾ ] unbound → local floor
```
- The dropdown lists **only providers that have a key in the vault** (you can't bind a role to a key you haven't pasted).
- Center pane on selecting a role = the role contract (inputs/outputs/what it may touch) + a read-only **Test** button (one cheap ping on the user's key) and a **clear binding** action.
- Right rail = honest state + "this role costs *your* key per call" note when bound to a paid provider.

---

## 5. The router — `route(role, payload)` + deterministic fallback
```
route(role, payload):
  b = role_bindings[role]
  if b.state == "tested" and opt_in_for_this_call:   # B: user's key, user's cost
      return call_provider(vault[b.key_id], b.model, payload)   # loopback → provider, TLS
  else:                                               # A: always-available floor
      return deterministic_local(role, payload)       # compose_engine / Groq cascade (opt-in)
```
- **Floor-first:** if a role is unbound/untested, or the user didn't opt into the paid call, the deterministic-local path runs. The product never *requires* a key.
- **Opt-in spend:** Compose via a bound paid key is an explicit choice per build (a labeled "compose with <role-key>" action), so no surprise charges. Default build = deterministic.
- **Opacity:** the router returns `{role, key_id, result}` for Layer-B calls; for Layer-A it returns `{result}` only — never the internal provider.

---

## 6. Compose bounded to the audited library + the UI receipt
**The make-or-break rule:** Compose does **not** write freehand UI/code. It selects + arranges + wires **pre-coded audited components** (`library/ui/ui_component_index.json`: 29 MIT/ISC/Apache parts + `combo_candidates.json`: 20 combos). A validation gate rejects any component id not in the treasury → the model is *constrained*, not free. If a layout needs a part we don't have, Compose **says so** (emits a `treasury_candidate`), it does not invent one.

**New receipt kind — `railcall_ui_receipt.v0`** (recomputable by `audit_workflow.py`):
```json
{ "schema": "railcall_ui_receipt.v0",
  "ui_id": "lead_intake_page",
  "from_workflow": "lead_routing_workflow",
  "components": [ {"id":"form_card","sha256":"…","version":"…","license":"MIT"} , … ],
  "role": "compose", "key_id": "anthropic",   // WHO composed — never the key
  "prompt": "a landing page that collects emails",
  "license_clean": true,                       // recomputed from the pieces
  "external": false,
  "integrity_root": "sha256:…" }
```
Auditor checks (mirror the workflow receipt): every component exists in the treasury, each claimed `sha256`/version matches the treasury's own pin, `license_clean` recomputes, integrity_root recomputes from the local artifact. **No green without a real recompute.**

---

## 7. Loopback preview — "generate it backwards on our link"
- **Backwards = workflow→UI.** The workflow spec (data shape + steps + actions) already exists; Compose generates the UI *from* it, so the front-end follows the governed workflow.
- The composed UI renders to a local artifact `builds/ui/<ui_id>.html` and is served at the existing loopback link pattern: **`http://127.0.0.1:8799/ui/<ui_id>`** (extends the current `/builds/*.html` route). You open the link and see your real front-end.
- It is a **preview/blueprint, not a deployed app** (honest framing, same as the Builder talker). Zero CDN, all assets local.

---

## 8. Honest states + failure modes
- Role states: `unbound` → `bound` (key assigned) → `untested` → `tested` (one read-only ping passed) → `failed` (ping failed, with reason). Same `saved ≠ tested` honesty as Phase 2.
- Provider/network error on a bound call → **fail to the deterministic floor with a visible note**, never a fake result.
- Compose tries to use a non-treasury component → **blocked**, emit `treasury_candidate`, fall back to nearest audited combo.
- Key missing for a bound role (vault edited out-of-band) → role auto-drops to `unbound`.

---

## 9. New surface area (all additive — engine frozen)
- **Endpoints (new):** `GET /api/router` (bindings + states, key *names* only), `POST /api/router/bind {role,key_id,model}`, `POST /api/router/test {role}`, `POST /api/compose_ui {workflow, prompt, role}` → recipe + `railcall_ui_receipt.v0`, `GET /ui/<ui_id>` (loopback preview).
- **Files (new):** `role_bindings.json`, `builds/ui/<ui_id>.html`, `PHASE6_BYOK_SPEC.md` (this).
- **Receipt kind (new):** `railcall_ui_receipt.v0` + auditor support.
- **Frozen:** `approval_airlock.py`, `command_registry.py`, `flow_engine.py`, `compose_engine.py` core, all existing receipts/tests. Phase 6 calls into them, never edits them.

---

## 10. Build phasing (after approval)
- **6a** Role abstraction + `role_bindings.json` + ROUTER tree node + picker UI (bind/unbind/test only — *no external calls yet*).
- **6b** `route()` with deterministic-local fallback proven (zero-BYOK path works end-to-end).
- **6c** BYOK **Compose** → bounded-to-library recipe + `railcall_ui_receipt.v0` + auditor support.
- **6d** Loopback **preview** render (`/ui/<ui_id>`).
- **6e** **Sweep** + **Audit** roles (read-only scan; fast validate).
Each phase: headless-verified, 0 external (except an explicitly-bound provider call on the user's key), regressions + auditor green, committed.

---

## 11. What this spec deliberately does NOT do (anti-drift)
- ❌ No freehand code generation — Compose is bounded to the audited, finite library.
- ❌ No platform Anthropic burn — Layer A never spends our keys; Layer B is the user's key/cost.
- ❌ No surfacing the internal reasoning provider — `show active provider` still refuses.
- ❌ No silent writes or real sends — drafts + receipts only; airlock-gated.
- ❌ No `.env` — keys stay in the `0600` vault.
- ❌ No hard dependency on any key — the deterministic floor is always the fallback.
- ❌ Not "unlimited models on demand" — a fixed role set; user binds the finite keys they hold.

---
**Open decisions for Pat (flagged, not silently chosen):**
1. **ROUTER placement** — new top-level left-tree node `▸ ROUTER` (my rec) vs. a tab inside Integrate.
2. **Compose default** — keep deterministic-local as the default and make BYOK-Compose an explicit per-build opt-in (my rec, prevents surprise spend) vs. "if a key is bound to Compose, always use it."
3. **Sweep/Audit in v0** — ship 6a–6d (Compose + preview) first and defer Sweep/Audit to 6e (my rec) vs. all three roles at once.
