# RailCall Studio

Governed automation you run **locally**. Bring your own keys, dry-run by default, every action
receipted. No cloud, no lock-in — it runs on `127.0.0.1`, your secrets never leave your machine.

## Run it (one command)

```
./start.command
```

That's it — pure Python 3 standard library, no `pip install`, no build step. Your browser opens to a
quick guide; the Studio is at **http://127.0.0.1:8799/v2**. Keep the terminal window open while you
use it (closing it stops the server).

Port 8799 busy? `STUDIO_PORT=8801 ./start.command`.

## What it does

- **Ingest any webhook** — point any tool (a signup form, Stripe, GitHub…) at one local endpoint;
  the payload lands in a governed log, live in the Monitor feed. No code runs on ingest.
- **Send to anything, governed** — `signup → Google Sheet`, or `webhook_out` to any Slack / Discord /
  Make / generic webhook URL. **DRY-RUN by default** — nothing leaves until you explicitly send.
- **448 integrations** — terminal-native manuals (keys, setup, dangerous actions, troubleshooting),
  with a local BYOK vault (`0600`, masked, never transmitted, never logged) and real read-only
  key-tests for the major providers.
- **Receipts on everything** — every run emits a tamper-evident receipt an independent auditor
  re-verifies. Honest failures, never a fake success.

`LOCAL · BYOK · DRY-RUN · NO SENDS` — that banner is the contract.

## Requires

Python 3 (any 3.7+). Nothing else.
