#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
#  RailCall Studio — one-run launcher (QA build)
#  Double-click this file (macOS) or run:  ./start.command
#  Starts the loopback studio + opens your browser to the QA guide.
# ─────────────────────────────────────────────────────────────────────────────
cd "$(dirname "$0")/workbench" 2>/dev/null || { echo "could not find ./workbench next to this script"; exit 1; }

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required. Install it from https://www.python.org/downloads/ and re-run."
  read -r -p "Press Enter to close..." _; exit 1
fi

PORT="${STUDIO_PORT:-8799}"
STUDIO="http://127.0.0.1:$PORT/v2"
GUIDE="http://127.0.0.1:$PORT/qa_guide"

# wait for the server to answer, then open the QA guide in the default browser
(
  for _ in $(seq 1 40); do
    if curl -s -o /dev/null "http://127.0.0.1:$PORT/v2" 2>/dev/null; then
      (command -v open >/dev/null 2>&1 && open "$GUIDE") \
        || (command -v xdg-open >/dev/null 2>&1 && xdg-open "$GUIDE") || true
      break
    fi
    sleep 0.5
  done
) &

echo ""
echo "  ┌──────────────────────────────────────────────────────────────┐"
echo "  │  RailCall Studio  ·  LOCAL · BYOK · DRY-RUN · NO SENDS         │"
echo "  ├──────────────────────────────────────────────────────────────┤"
echo "  │  Studio   →  $STUDIO"
echo "  │  QA guide →  $GUIDE"
echo "  ├──────────────────────────────────────────────────────────────┤"
echo "  │  Keep this window OPEN while testing.                         │"
echo "  │  Press Ctrl-C (or close this window) to stop the server.      │"
echo "  │  Port busy?  run:  STUDIO_PORT=8801 ./start.command           │"
echo "  └──────────────────────────────────────────────────────────────┘"
echo ""

exec python3 studio_server.py
