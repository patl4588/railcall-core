# TRUSTED_REUSE Promotion Rule

An asset may be promoted to `TRUSTED_REUSE` (production-visible **and** reusable by builders/agents) **only when ALL 14 of the following are committed and verifiable in-repo.** Missing any one → it stays at its current tier. Promotion is never automatic and never silent.

1. **Committed runnable code** or a deterministic executable workflow (no generated stub standing in for implementation).
2. **Explicit input contract** (named fields, types, required/optional).
3. **Explicit output contract** (shape + any emitted events/artifacts).
4. **Fixture / sample** input that exercises it.
5. **Executable local test command** (one command a reviewer can run).
6. **Passing validation receipt** (the test command's recorded pass result).
7. **Safety / refusal rules** (what it refuses; no live/destructive defaults).
8. **Provenance / source receipt** (where it came from; library-first search result).
9. **Non-developer summary** (what it does, what it produces, what it refuses).
10. **Patrick approval gate** (explicit human approval recorded).
11. **Codex / local QA result.**
12. **Groq or independent audit result** that proves the **exact gate being claimed** (a staging GO is not a promotion verdict).
13. **No generated stubs as implementation.**
14. **CI or a repeatable local validation path.**

## Hard distinctions
- A **receipt is evidence, not functionality.** A folder of receipts is never `TRUSTED_REUSE`.
- A **pointer/index/symlink is REFERENCE_ONLY**, never a usable module count.
- A **staging GO** (`GO_FOR_STAGED_LIBRARY_PACK`) authorizes *staging visibility only* — never canonical/trusted promotion.
- **"validated" in a filename** is not item 6. Item 6 is a runnable test producing a pass result now.
- **Production visibility ≠ trusted reuse.** An asset can be shown honestly in the inspector at a lower tier without being reusable.

## Banned, unevidenced language
Do not describe any asset with "cryptographic receipts", "128-bit routing", "zero-token rails", "built 100% from the trusted library", or similar unless each claim is backed by in-repo evidence. Receipts in this library are proof-only JSON records.

## Process
1. Classify (this pass: `library/audits/trust/library_trust_map_v1.json`).
2. Repair the highest-evidence candidates (`library/staging/queues/library_trust_repair_queue_v1.json`) up the tiers by adding the missing items above.
3. Re-audit (Codex/local + independent) against the **exact** promotion gate.
4. Patrick approves → only then `TRUSTED_REUSE` + canonical, with the inspector updated to count it.
