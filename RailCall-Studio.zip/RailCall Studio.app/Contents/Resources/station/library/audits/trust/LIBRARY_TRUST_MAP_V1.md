# LIBRARY TRUST MAP — V1 (classification only)

**Mission:** `LIBRARY_TRUST_REPAIR_V1_CLASSIFICATION_ONLY` · **Branch:** `library-trust-repair-v1` · **Base:** `release/audited-terminal-library-v1 @ b7b3b11ccd`
**Method:** fresh read-only `git ls-files library/` scan. Counts are committed-file truth. **Gemini/prior counts NOT used.** Trust = evidence in-repo, not filenames or marketing.
**This pass promotes nothing.** Machine-readable detail: `library_trust_map_v1.json`.

## The inflation, stated plainly
The committed library is **57 tracked files** — not thousands of reusable modules.
- `library/modules/workflows`, `primitives`, `packs`, `receipts` = **single symlinks** to dirs outside `library/`. The "1195 workflows / primitives / packs / receipt bundles" live elsewhere; in-tree they are **pointers**, not modules.
- `library/modules/combos` = **3 index JSON files** whose *contents* list ~5000 candidates and a "validated" set. None are per-item executable modules. The word "validated" in a filename is **not** evidence.
- `library/modules/sources` = **2 files** (migration manifest + a validation report). The big external module-library bulk is **not committed here**.
- `library/audits` is **absent** on this branch (the usability/trust dataset is on `library-audit/usability-classification-v0`).

So: a real, small usable core (the 15 UI legos + contracts + inspection tooling) surrounded by references, indexes, and staged stubs.

## Tier counts (committed assets)
| Tier | Count |
|---|---|
| `TRUSTED_REUSE` | **0** |
| `STARTER_REUSE` | 19 |
| `BLUEPRINT_ONLY` | 3 |
| `REFERENCE_ONLY` | 23 |
| `STAGED_BLUEPRINT` | 6 |
| `QUARANTINE` | 3 |
| `DELETE_REVIEW` | 1 |

`TRUSTED_REUSE = 0` is correct for a conservative first pass: **nothing** in-tree has all of {runnable code · input+output contract · fixture · test command · passing validation receipt · safety rules · provenance · non-dev summary · Patrick approval}. The closest are the 15 legos and `serve_library.cjs` — real code missing fixtures/tests/receipts/approval → `STARTER_REUSE`.

## What's in each tier
- **STARTER_REUSE (19)** — the 15 UI legos (real `.html` components w/ contracts), `_core/mc-state.js`, `serve_library.cjs`, `build_pages.py`, `build_central_library.py`. Real code; missing fixtures/tests/receipts/approval.
- **BLUEPRINT_ONLY (3)** — `CONTRACTS.md`, `ui/legos.manifest.json`, `LIBRARY_FIRST_RULE.md`. Specs/schema/policy; `LIBRARY_FIRST_RULE` enforcement is explicitly not built.
- **REFERENCE_ONLY (23)** — 5 symlinks, 3 generated inspector pages, READMEs/docs, 7 PDF staging receipts + PROMOTION_HOLD, the migration manifest, the sync script. Pointers/indexes/evidence — **not** functionality.
- **STAGED_BLUEPRINT (6)** — the `pdf_generation_pack` stub items (`STUB_NEEDS_BUILD`). Visible, not canonical. (Real impl is on a preserved branch — see the PDF packet.)
- **QUARANTINE (3)** — `MODULE_COMBO_UNIVERSE_CANDIDATES.json` (5000 bulk), `KAI_VALIDATED_WORKFLOW_INDEX_V1.json` (unevidenced "validated"), external `LIBRARY_VALIDATION_REPORT.json`. Inflated/misleading; do not count as usable.
- **DELETE_REVIEW (1)** — `MODULE_COMBO_UNIVERSE_CLASSIFIED_V1.json` (likely duplicate of the candidates universe). Flag only; **no deletion** without Patrick.

## Claims banned (none used here)
No "cryptographic receipts", "128-bit routing", "zero-token rails", "100% built from library", or "1195/5000 usable". Receipts here are proof-only JSON records. The library is **not** a trusted moat yet — it is a small usable core + an honest inspection system + a lot of references/stubs.

**Verdict:** `PASS_FOR_LIBRARY_TRUST_REPAIR_V1_CLASSIFICATION_REVIEW` (classification produced; promotions attempted = 0, approved = 0).
