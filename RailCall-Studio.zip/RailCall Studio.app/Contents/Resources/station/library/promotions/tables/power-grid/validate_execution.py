#!/usr/bin/env python3
"""Circuit breaker / promotion validator for tables/power-grid.

Pipeline (any failed check → FAULT → receipt FAIL → exit 1; nothing is hardcoded):
  1. load fixtures/sample.json + validate it against input_contract.json (auth_token, dataset_id,
     pagination.limit, data, cross-field len(data) <= limit).
  2. execute the REAL lego (library/tables/power-grid.html) in a Node DOM shim — mount + render +
     click — with net/http/https/dns hooked so ANY socket attempt is counted and blocked.
  3. assert ZERO live network sockets opened during execution.
  4. build the execution-result envelope (status / executed_at / data_matrix / …) from the REAL
     rendered cells and validate it against output_contract.json.
  5. write validation_receipt.json with a SHA-256 integrity tree over the packet + lego source.
patrick_approval_gate is written as a PENDING placeholder (formal sign-off is a separate step).

  python3 validate_execution.py
"""
import json, re, subprocess, tempfile, os, datetime, sys, hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path(__file__).resolve().parents[4]
LEGO = ROOT / "library" / "tables" / "power-grid.html"
inp = json.load(open(HERE / "input_contract.json"))
out = json.load(open(HERE / "output_contract.json"))
payload = json.load(open(HERE / "fixtures" / "sample.json"))

checks = []
def chk(name, ok, detail=""):
    checks.append({"check": name, "ok": bool(ok), "detail": str(detail)})
    return bool(ok)

def sha256_bytes(b): return "sha256:" + hashlib.sha256(b).hexdigest()
def sha256_file(p):
    return sha256_bytes(Path(p).read_bytes()) if Path(p).exists() else "MISSING"

# ── 1) validate payload against input_contract ──
P = inp["properties"]
tok = payload.get("auth_token")
chk("auth_token present + min length", isinstance(tok, str) and len(tok) >= P["auth_token"]["minLength"])
did = payload.get("dataset_id")
chk("dataset_id matches pattern", isinstance(did, str) and re.match(P["dataset_id"]["pattern"], did) is not None, did)
pag = payload.get("pagination") or {}
lim = pag.get("limit")
lspec = P["pagination"]["properties"]["limit"]
chk("pagination.limit int in range", isinstance(lim, int) and not isinstance(lim, bool) and lspec["minimum"] <= lim <= lspec["maximum"], lim)
if "offset" in pag:
    chk("pagination.offset int >= 0", isinstance(pag["offset"], int) and pag["offset"] >= 0)
data = payload.get("data")
dspec = P["data"]
chk("data is array in [minItems,maxItems]", isinstance(data, list) and dspec["minItems"] <= len(data) <= dspec["maxItems"], f"len={len(data) if isinstance(data,list) else 'n/a'}")
if isinstance(data, list):
    for i, cell in enumerate(data):
        chk(f"data[{i}] has label+value of valid type",
            isinstance(cell, dict) and isinstance(cell.get("label"), str) and cell.get("label")
            and isinstance(cell.get("value"), (str, int, float)) and not isinstance(cell.get("value"), bool))
    chk("cross-field: len(data) <= pagination.limit", isinstance(lim, int) and len(data) <= lim, f"{len(data)}<= {lim}")

# ── 2) execute the lego in a sandboxed Node DOM shim, with network hooked ──
no_comments = re.sub(r"<!--.*?-->", "", LEGO.read_text(), flags=re.S)
scripts = re.findall(r"<script>(.*?)</script>", no_comments, flags=re.S)
chk("lego exposes exactly one live <script>", len(scripts) == 1, f"found {len(scripts)}")
iife = scripts[-1] if scripts else ""

HARNESS = r'''
"use strict";
// ── circuit breaker: hook every outbound network primitive; count + block any attempt ──
let SOCKETS = 0;
const bump = (m) => { SOCKETS++; const e = new Error("NETWORK_BLOCKED:" + m); throw e; };
try { const net = require("net"); net.Socket.prototype.connect = function(){ return bump("net.Socket.connect"); }; net.connect = () => bump("net.connect"); net.createConnection = () => bump("net.createConnection"); } catch(e){}
try { const http = require("http"); http.request = () => bump("http.request"); http.get = () => bump("http.get"); } catch(e){}
try { const https = require("https"); https.request = () => bump("https.request"); https.get = () => bump("https.get"); } catch(e){}
try { const dns = require("dns"); dns.lookup = () => bump("dns.lookup"); if (dns.promises) dns.promises.lookup = () => bump("dns.promises.lookup"); } catch(e){}
try { const tls = require("tls"); tls.connect = () => bump("tls.connect"); } catch(e){}
// ── minimal DOM shim ──
const DISPATCHED = [];
global.CustomEvent = class { constructor(type, opts){ this.type=type; if(opts){ this.detail=opts.detail; this.bubbles=opts.bubbles; } } };
let CLICK = null;
const root = { addEventListener(ev, fn){ if(ev==="click") CLICK = fn; } };
const host = { _h:"", set innerHTML(v){ this._h=v; }, get innerHTML(){ return this._h; },
  querySelector(sel){ return sel===".power-grid" ? root : null; },
  dispatchEvent(e){ DISPATCHED.push({type:e.type, detail:e.detail}); return true; } };
global.window = {};
global.document = { querySelector(){ return host; } };
/*__LEGO__*/
const PAYLOAD = /*__PAYLOAD__*/;
let mounted = false, err = null;
try {
  if (!window.LEGO_power_grid || typeof window.LEGO_power_grid.mount !== "function") throw new Error("no window.LEGO_power_grid.mount");
  window.LEGO_power_grid.mount("#host", { data: PAYLOAD.data });
  mounted = true;
  if (CLICK) CLICK({ target: { closest(s){ return s===".power-grid-cell" ? { dataset:{ index:"0" } } : null; } } });
} catch(e) { err = String(e && e.message || e); }
console.log(JSON.stringify({ html: host.innerHTML, api_version: (window.LEGO_power_grid||{}).version,
  dispatched: DISPATCHED, network_sockets_opened: SOCKETS, mounted, err }));
'''
result = {}
if iife:
    harness = HARNESS.replace("/*__LEGO__*/", iife).replace("/*__PAYLOAD__*/", json.dumps(payload))
    with tempfile.NamedTemporaryFile("w", suffix=".cjs", delete=False, dir=str(HERE)) as tf:
        tf.write(harness); hp = tf.name
    try:
        proc = subprocess.run(["node", hp], capture_output=True, text=True, timeout=30)
        out_lines = proc.stdout.strip().splitlines()
        result = json.loads(out_lines[-1]) if out_lines else {"err": (proc.stderr or "")[:200]}
    except Exception as e:
        result = {"err": f"harness: {e}"}
    finally:
        os.unlink(hp)

chk("lego mounted without crash", result.get("mounted") is True and not result.get("err"), result.get("err", ""))
# ── 3) zero network sockets ──
chk("ZERO live network sockets opened", result.get("network_sockets_opened") == 0, f"sockets={result.get('network_sockets_opened')}")

# ── 4) build the execution-result envelope from the REAL render + validate vs output_contract ──
html = result.get("html", "")
cells = re.findall(r'data-mcid="lego-power-grid-cell-\d+".*?power-grid-label">(.*?)</p>.*?power-grid-value">(.*?)</p>.*?power-grid-trend\s+(\w+)"', html, flags=re.S)
data_matrix = [[lbl, val, cls] for (lbl, val, cls) in cells]
envelope = {
    "status": "SUCCESS" if (result.get("mounted") and result.get("network_sockets_opened") == 0) else "FAILURE",
    "executed_at": datetime.datetime.now().isoformat(timespec="seconds"),
    "mounted": bool(result.get("mounted")),
    "rendered_cell_count": len(data_matrix),
    "data_matrix": data_matrix,
    "network_sockets_opened": result.get("network_sockets_opened"),
    "api_version": result.get("api_version"),
}
OP = out["properties"]
chk("result.status in enum", envelope["status"] in OP["status"]["enum"], envelope["status"])
chk("result.executed_at ISO-8601", re.match(OP["executed_at"]["pattern"], envelope["executed_at"]) is not None)
chk("result.mounted == true", envelope["mounted"] is True)
chk("rendered_cell_count == data length", envelope["rendered_cell_count"] == len(data), f"{envelope['rendered_cell_count']} vs {len(data)}")
chk("data_matrix rows are [label,value,trend_class]", all(len(r) == 3 for r in data_matrix) and len(data_matrix) == len(data))
chk("result.network_sockets_opened == 0 (const)", envelope["network_sockets_opened"] == OP["network_sockets_opened"]["const"])
chk("result.api_version == 1.0.0 (const)", envelope["api_version"] == OP["api_version"]["const"], envelope["api_version"])

# ── 5) integrity tree (sha256 over the packet + lego source; excludes the receipt itself) ──
integrity_files = ["input_contract.json", "output_contract.json", "fixtures/sample.json",
                   "validate_execution.py", "NON_DEVELOPER_SUMMARY.md", "SAFETY_RULES.md", "PROVENANCE.md"]
tree = {f: sha256_file(HERE / f) for f in integrity_files}
tree["library/tables/power-grid.html"] = sha256_file(LEGO)
integrity_root = sha256_bytes(json.dumps(tree, sort_keys=True, separators=(",", ":")).encode())

faults = [c for c in checks if not c["ok"]]
result_status = "PASS" if not faults else "FAIL"
# approval gate is GOVERNANCE state, not a technical output — single source of truth is the registry,
# so the receipt always reflects it and re-runs never silently revert it.
approval_gate, approved_by = "PENDING_PLACEHOLDER", None
try:
    for _a in json.load(open(ROOT / "library" / "promotions" / "governed_legos_registry.json")).get("governed_assets", []):
        if _a.get("module_id") == "tables/power-grid":
            approval_gate = _a.get("patrick_approval_gate", approval_gate)
            approved_by = _a.get("approved_by")
except Exception:
    pass
receipt = {
    "schema": "validation_receipt.v1",
    "lego_id": "tables/power-grid",
    "promotion_dir": "library/promotions/tables/power-grid",
    "validated_at": datetime.datetime.now().isoformat(timespec="seconds"),
    "base_commit": "98dbd3a4d0",
    "validation_type": "REAL_EXECUTION + CONTRACT_CONFORMANCE + ZERO_NETWORK",
    "executor": "node DOM shim with net/http/https/dns/tls hooked (count+block)",
    "render_note": "structural + event + zero-socket conformance via real JS execution; NOT a pixel/visual render test",
    "checks_total": len(checks),
    "faults": len(faults),
    "result": result_status,
    "exit_code": 0 if not faults else 1,
    "execution_envelope": envelope,
    "trusted_reuse_allowed": not faults,
    "governance_tier": "TRUSTED_REUSE" if not faults else "STARTER_REUSE",
    "patrick_approval_gate": approval_gate,
    "approved_by": approved_by,
    "integrity_root": integrity_root,
    "integrity_tree": tree,
    "fault_details": faults,
    "checks": checks,
}
json.dump(receipt, open(HERE / "validation_receipt.json", "w"), indent=2)
print(json.dumps({"result": result_status, "checks_total": len(checks), "faults": len(faults),
                  "network_sockets_opened": envelope["network_sockets_opened"],
                  "rendered_cell_count": envelope["rendered_cell_count"], "integrity_root": integrity_root}, indent=2))
for c in faults:
    print("  FAULT:", c["check"], c["detail"])
sys.exit(0 if not faults else 1)
