# power-grid — plain-English promotion summary

**What it is:** a dashboard "stat grid" building block (the `tables/power-grid` lego) — it shows 4–12 metric tiles (label, value, up/down trend), like an MRR / churn / NPS dashboard row. It is **Metercall's own code** (first-party), not a third-party download.

**What "promotion to TRUSTED_REUSE" means here:** this block has been given hard "border walls" so a workflow can use it safely and predictably:
- an **input contract** — exactly what data it accepts (and rejects),
- an **output contract** — exactly what it produces,
- a **fixture** — a realistic sample payload,
- a **circuit-breaker validator** — a script that actually runs the block against the fixture and checks every rule.

**What was proven (not claimed):** the validator *executes the real block* and confirms it mounts and renders, produces the locked output shape, and **opens zero network connections** (it cannot phone home or leak the token). Every result in `validation_receipt.json` comes from that run — nothing is hand-typed. If any single check fails, the receipt says FAIL and the promotion does not count.

**Approval status:** the technical validation is **PASS** and the formal sign-off field `patrick_approval_gate` is now **APPROVED** (Patrick's explicit administrative override, 2026-06-15). This is the first fully-approved `TRUSTED_REUSE` asset.

**What this is NOT:** it is not a finished feature, not a workflow, and not a guarantee of pixel-perfect appearance (no visual/screenshot test was run — structure + behavior + safety only).
