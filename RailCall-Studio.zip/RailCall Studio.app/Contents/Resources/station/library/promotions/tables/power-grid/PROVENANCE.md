# power-grid — provenance

## Asset
- **Lego id:** `tables/power-grid`
- **Source file:** `library/tables/power-grid.html` (first-party Metercall code; MC LEGO · tables/power-grid · v1.0.0)
- **Origin:** authored in-repo by Metercall — NOT mirrored third-party OSS. No external license obligations.
- **Mount API:** `window.LEGO_power_grid.mount(target, { data })` · event `lego:select` · stable selectors `.power-grid-cell/.power-grid-label/.power-grid-value/.power-grid-trend`.

## Promotion
- **Branch:** `promote-first-governed-workflow-v1`
- **Integration base:** `98dbd3a4d0` (scaled Phase 1–3 treasury: 68 STARTER_REUSE_SMOKED, 20 COMBO_CANDIDATE)
- **Path before promotion:** STARTER_REUSE (first-party lego, reclassification map)
- **Path after promotion:** TRUSTED_REUSE (this packet)
- **Supersedes:** an earlier first-pass packet at `library/ui/metercall-legos/power-grid/` (built off the pre-scale base `4473cfdef3`); that approach is retired in favor of this `library/promotions/` packet with richer contracts.

## Evidence (all machine-generated, none hand-typed)
- `input_contract.json` / `output_contract.json` — derived from the lego's real mount/render code.
- `fixtures/sample.json` — realistic mock payload (fake token).
- `validate_execution.py` — circuit breaker (real DOM-shim execution + zero-network proof).
- `validation_receipt.json` — the run's result, including `integrity_root` (SHA-256 over the packet + lego source) and the per-file `integrity_tree`. See that file for the exact hashes.

## Approval
- **`patrick_approval_gate`: APPROVED** — technical validation complete (receipt `result: PASS`) AND formal human sign-off granted by Patrick (explicit administrative override, 2026-06-15). The governance source of truth for this gate is `library/promotions/governed_legos_registry.json`; `validate_execution.py` reads it into the receipt, so re-runs preserve the approved state.

## Verification
- Re-validate: `python3 library/promotions/tables/power-grid/validate_execution.py`
- Governance gate: `python3 library/ui/scripts/verify_governed_legos.py`
- Recompile truth surface: `python3 library/build_central_library.py && python3 library/build_pages.py`
