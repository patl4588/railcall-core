# power-grid — safety rules (enforced by the circuit breaker)

These are the invariants `validate_execution.py` asserts on every run. A violation = FAULT = receipt FAIL = exit 1.

## Network
- **ZERO live network sockets.** The validator hooks `net`, `http`, `https`, `dns`, and `tls` so any outbound attempt is counted **and blocked** (throws). The receipt records `network_sockets_opened` and the run only passes at `0`.
- Consequence: the lego **cannot transmit `auth_token`** or any payload field off-box. `auth_token` is an envelope-level field the lego never reads.

## Input
- Payload must satisfy `input_contract.json`: `auth_token` (string ≥16), `dataset_id` (`^ds_…`), `pagination.limit` (int 1–12), `data` (1–12 items, each `{label, value, trend?}`).
- Cross-field: `len(data) ≤ pagination.limit`. Malformed input is rejected, not coerced.

## Execution
- The real lego runs in a **minimal DOM shim** — no real browser, no filesystem writes by the lego, no `eval` of external input. Only the lego's own `<script>` is executed (the commented usage example is stripped first).
- Output must satisfy `output_contract.json`: `status ∈ {SUCCESS, FAILURE}`, ISO-8601 `executed_at`, `mounted == true`, `rendered_cell_count == len(data)`, `data_matrix` rows of `[label, value, trend_class]`, `network_sockets_opened == 0`, `api_version == 1.0.0`.

## Secrets
- The fixture's `auth_token` is a clearly-labeled fake (`…NOT_A_REAL_SECRET`). No real credential is stored in this packet.

## Integrity
- `validation_receipt.json` carries a SHA-256 `integrity_root` over the packet files + the lego source (`integrity_tree`). Re-running with any file changed produces a different root.

## Scope
- First-party Metercall code. No third-party license obligations. This packet promotes **only** `tables/power-grid` — no other module is touched.
