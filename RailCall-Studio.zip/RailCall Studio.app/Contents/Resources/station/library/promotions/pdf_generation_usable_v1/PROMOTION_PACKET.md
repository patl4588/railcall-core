# PROMOTION PACKET — `pdf_generation_usable_v1`

**This is a planning / classification packet, NOT an approval. No promotion is performed.**
**Classification (evidence-based, this pass): `STARTER_REUSE`** — real implementation + most proof exist, but it is staged, lacks the Patrick approval gate, and produces PDF-ready HTML (not a binary PDF). **Not `TRUSTED_REUSE`.**

## Subject
- **Asset:** `pdf_generation_pack` real implementation ("usable v1").
- **Where the real code lives:** preserved branch `library-pack/pdf-generation-usable-v1 @ 5a885d5fce` (pushed). **Not** on this trust-repair branch, and **not** the staged stubs on the release branch (those are `STAGED_BLUEPRINT`, `STUB_NEEDS_BUILD`).

## Evidence present (on the preserved branch)
| Promotion requirement | Present? | Evidence |
|---|---|---|
| 1. Committed runnable code | ✅ | `library/staging/modules/pdf/pdf_engine.cjs` (deterministic; validate → invoice math → render PDF-ready HTML) |
| 2. Input contract | ✅ | 6 upgraded descriptors with `input_schema` (proposal/invoice/report/essay + core + template) |
| 3. Output contract | ✅ | `output_schema` (`PDF_READY_HTML`, hashes, receipt) |
| 4. Fixture / sample | ✅ | 6 fixtures incl. 2 refusal fixtures (`library/staging/fixtures/pdf/`) |
| 5. Executable local test command | ✅ | `node library/tools/pdf/build_pdf_pack_v1.cjs` |
| 6. Passing validation receipt | ✅ | `pdf_generation_pack_v1__…json` — 9/9 checks pass (json, schema, fixture-gen, invoice math, refusal, determinism, no-secret, no-live-action, links) |
| 7. Safety / refusal rules | ✅ | `R0_PREVIEW_ONLY`, `preview_only`, refusal on missing/invalid input; no external API |
| 8. Provenance / source receipt | ✅ | library-first build receipts + `PROMOTION_HOLD.md` |
| 9. Non-developer summary | ✅ | per-descriptor `non_dev_summary` |
| 10. **Patrick approval gate** | ❌ | not granted |
| 11. Codex / local QA | ◻ partial | local run PASS; independent Codex QA not recorded |
| 12. Independent audit of the **exact** gate | ⚠ | Groq `GO_FOR_STAGED_USABLE_PDF_GENERATION_PACK_V1` proves the **staged-usable** gate — NOT canonical promotion |
| 13. No stub-as-implementation | ✅ | real engine; the stubs are a separate older artifact |
| 14. CI / repeatable validation | ◻ partial | repeatable local command exists; no CI wired |

## Why STARTER_REUSE, not TRUSTED_REUSE
- It is **staged**, not merged into the inspector/canonical, and has **no Patrick approval** (req 10).
- It produces **PDF_READY_HTML**, not a binary PDF — the converter hook is unbuilt; do not claim "production PDF generation."
- The Groq verdict is a **staging** verdict (req 12 needs an audit of the *promotion* gate).
- Library-first was last run against a **partial** shelf; must re-run vs the now-built `ui/index.json` + `modules/index.json`.

## What would move it up (no action this pass)
1. Merge the impl into a staged-usable position behind the inspector (visible as `STAGED_USABLE`, not canonical).
2. Re-run library-first vs the built indexes (still 0 strong duplicates).
3. Independent audit of the **promotion** gate (not the staging gate).
4. Patrick approval → only then consider `TRUSTED_REUSE` + canonical, with the binary-PDF converter as a separate item.

**Promotion status: NONE. Classification only. Default kept at `STARTER_REUSE`.**
