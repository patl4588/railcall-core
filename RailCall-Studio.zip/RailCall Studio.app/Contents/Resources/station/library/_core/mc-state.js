/**
 * MC — tiny cross-Lego shared state.
 * 30 lines. Not Redux. Not a framework. Just key/value + subscribe.
 *
 * Use this ONLY for state that legitimately spans Legos:
 *   - current user, current workspace, theme
 *   - oauth tokens (per provider)
 *   - global feature flags
 *
 * For Lego ↔ Lego communication WITHIN a single workspace, use CustomEvents
 * with canonical names (see library/CONTRACTS.md).
 *
 * USAGE:
 *   MC.set('user', { id: 'pat', name: 'Patrick' });
 *   MC.get('user');                     // → { id: 'pat', ... }
 *   const off = MC.on('user', u => console.log('user changed', u));
 *   off();                              // unsubscribe
 *
 * EVENTS:
 *   Subscribers fire AFTER the value is set. Initial subscribe does NOT fire
 *   with the current value — use `MC.get()` if you need it now.
 */
(function () {
  'use strict';
  if (window.MC) return; // idempotent

  const store = Object.create(null);
  const listeners = Object.create(null);

  window.MC = {
    version: '1.0.0',

    get(key) {
      return store[key];
    },

    set(key, value) {
      const prev = store[key];
      store[key] = value;
      const subs = listeners[key];
      if (subs) for (const fn of subs.slice()) {
        try { fn(value, prev); }
        catch (e) { console.warn('[MC] listener for', key, 'threw:', e); }
      }
    },

    on(key, fn) {
      if (typeof fn !== 'function') throw new TypeError('MC.on(key, fn) — fn must be a function');
      (listeners[key] = listeners[key] || []).push(fn);
      return () => {
        listeners[key] = (listeners[key] || []).filter(f => f !== fn);
      };
    },

    // Debug helper — `MC.dump()` shows the whole store (don't use in prod)
    dump() {
      return JSON.parse(JSON.stringify(store));
    }
  };
})();
