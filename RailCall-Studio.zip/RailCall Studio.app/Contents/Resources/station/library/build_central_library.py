#!/usr/bin/env python3
"""Build the Metercall canonical LOCAL library aggregation layer — NON-DESTRUCTIVE.

Creates metercall-site/library/{ui,modules}/ with index.json + README per side and a
central manifest.json, referencing existing sources (copy / relative-symlink / index)
WITHOUT moving or deleting any source folder. Re-runnable (idempotent).

  python3 library/build_central_library.py
"""
from __future__ import annotations
import datetime, glob, json, os, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]                 # metercall-site
LIB = ROOT / "library"
CKL = ROOT / "customer_kai_module_library_v0"
MODLIB = Path("/Users/patricklinden/metercall/module-library")
MASTER = Path("/Users/patricklinden/MASTER_LIBRARY_ALL")
NOW = datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S")  # local inspection page — real ts ok
BASE = "http://localhost:8745"


def mkdir(p: Path): p.mkdir(parents=True, exist_ok=True)
def wj(p: Path, obj): mkdir(p.parent); p.write_text(json.dumps(obj, indent=2) + "\n")
def cp(src: Path, dst: Path) -> bool:
    if src.exists(): mkdir(dst.parent); shutil.copy2(src, dst); return True
    return False
def rel_symlink(target: Path, link: Path):
    mkdir(link.parent)
    if link.is_symlink() or link.exists():
        if link.is_symlink(): link.unlink()
        else: return  # real dir already there — don't clobber
    os.symlink(os.path.relpath(target, link.parent), link)
def count_json(p: Path) -> int:
    try:
        d = json.load(open(p)); return len(d) if isinstance(d, (list, dict)) else 0
    except Exception: return 0

# ── 0) preserve the existing UI-Lego manifest + README into library/ui/ (nothing lost) ──
# Write the preserved copy ONCE. Guard against re-runs: after this script repurposes the
# root manifest/README to "central", a second run must NOT copy those central files over
# the preserved Lego originals. So only preserve if the preserved copy does not exist yet.
mkdir(LIB / "ui")
if (LIB / "manifest.json").exists() and not (LIB / "ui" / "legos.manifest.json").exists():
    cp(LIB / "manifest.json", LIB / "ui" / "legos.manifest.json")
if (LIB / "README.md").exists() and not (LIB / "ui" / "README.legos.md").exists():
    cp(LIB / "README.md", LIB / "ui" / "README.legos.md")

# ── 1) structure ──
for d in ("ui/components", "ui/pages", "ui/sites", "ui/previews", "ui/examples",
          "modules/workflows", "modules/combos", "modules/primitives", "modules/packs",
          "modules/receipts", "modules/sources"):
    mkdir(LIB / d)

# ── 2) MODULE LIBRARY content ──
# combos (copy the headline data)
cp(CKL / "MODULE_COMBO_UNIVERSE_CANDIDATES.json", LIB / "modules/combos/MODULE_COMBO_UNIVERSE_CANDIDATES.json")
cp(CKL / "MODULE_COMBO_UNIVERSE_CLASSIFIED_V1.json", LIB / "modules/combos/MODULE_COMBO_UNIVERSE_CLASSIFIED_V1.json")
cp(CKL / "indexes/KAI_VALIDATED_WORKFLOW_INDEX_V1.json", LIB / "modules/combos/KAI_VALIDATED_WORKFLOW_INDEX_V1.json")
combo_candidates = count_json(CKL / "MODULE_COMBO_UNIVERSE_CANDIDATES.json")
validated = len(json.load(open(CKL / "indexes/KAI_VALIDATED_WORKFLOW_INDEX_V1.json")).get("workflows", [])) if (CKL / "indexes/KAI_VALIDATED_WORKFLOW_INDEX_V1.json").exists() else 0

# workflows/definitions (relative symlink → no duplication, always fresh)
rel_symlink(ROOT / "workflow_primitives/workflows/definitions", LIB / "modules/workflows/definitions")
wf_count = len(glob.glob(str(ROOT / "workflow_primitives/workflows/definitions/*.json")))

# primitives + packs (reference the engine source)
rel_symlink(ROOT / "workflow_primitives", LIB / "modules/primitives/workflow_primitives")
rel_symlink(ROOT / "workflow_primitives/packs", LIB / "modules/packs/packs")
prim_count = len(glob.glob(str(ROOT / "workflow_primitives/**/*.py"), recursive=True))
pack_count = len([p for p in glob.glob(str(ROOT / "workflow_primitives/packs/*")) if os.path.isdir(p)])

# receipts / proof bundles (reference)
rel_symlink(ROOT / "email_send_runs", LIB / "modules/receipts/email_send_runs") if (ROOT / "email_send_runs").exists() else None
rel_symlink(ROOT / "demo_runs", LIB / "modules/receipts/demo_runs") if (ROOT / "demo_runs").exists() else None
rel_symlink(ROOT / "program_runs", LIB / "modules/receipts/program_runs") if (ROOT / "program_runs").exists() else None
receipt_bundles = len([p for p in glob.glob(str(ROOT / "demo_runs/*")) if os.path.isdir(p)]) + \
                  len([p for p in glob.glob(str(ROOT / "program_runs/*")) if os.path.isdir(p)])

# sources: external module-library repo (copy its top-level manifests; index the rest)
modlib_present = MODLIB.exists()
modlib_modules = modlib_branches = 0
if modlib_present:
    mkdir(LIB / "modules/sources/module-library")
    for f in ("LIBRARY_VALIDATION_REPORT.json", "GIT_MIGRATION_MANIFEST.json"):
        cp(MODLIB / f, LIB / "modules/sources/module-library" / f)
    # bring the module catalogs/indexes into the served area so they're browsable (read-only copy)
    for sub in ("module_source_library", "indexed_library"):
        s = MODLIB / sub
        if s.exists():
            d = LIB / "modules/sources/module-library" / sub
            if d.exists(): shutil.rmtree(d)
            shutil.copytree(s, d)
    modlib_modules = len([p for p in glob.glob(str(MODLIB / "module_source_library/*")) if os.path.isdir(p)]) + \
                     len([p for p in glob.glob(str(MODLIB / "indexed_library/*"))])
    try:
        import subprocess
        modlib_branches = len(subprocess.check_output(["git", "-C", str(MODLIB), "branch", "-a"]).decode().splitlines())
    except Exception: pass

ckl_modules = len(json.load(open(CKL / "indexes/KAI_MODULE_INDEX_V1.json"))["modules"]) if (CKL / "indexes/KAI_MODULE_INDEX_V1.json").exists() else 0


def scan_staging():
    """Read-only scan of library/staging/ → staged packs. NEVER counted as canonical."""
    sdir = LIB / "staging"
    packs = {}
    for f in sorted(glob.glob(str(sdir / "modules/**/*.json"), recursive=True)) + \
             sorted(glob.glob(str(sdir / "ui/**/*.json"), recursive=True)):
        try:
            d = json.load(open(f))
        except Exception:
            continue
        pk = d.get("pack") or "unknown_pack"
        rel = os.path.relpath(f, ROOT)
        p = packs.setdefault(pk, {"pack": pk, "modules": [], "ui": [], "statuses": set()})
        (p["ui"] if f"{os.sep}ui{os.sep}" in f else p["modules"]).append(rel)
        if d.get("status"):
            p["statuses"].add(d["status"])
    out = []
    for pk, info in sorted(packs.items()):
        rc = sorted(os.path.relpath(p, ROOT) for p in glob.glob(str(sdir / f"receipts/{pk}__*.json")))
        groq = next((r for r in rc if "groq_audit_result" in r), None)
        val = next((r for r in rc if r.endswith(".json") and "groq_audit" not in r), None)
        hold = sdir / f"receipts/{pk}_PROMOTION_HOLD.md"
        out.append({
            "pack": pk, "title": pk.replace("_", " ").title().replace("Pdf", "PDF").replace("Ui", "UI"),
            "canonical": False, "promoted_to_canonical": False,
            "labels": sorted(info["statuses"]) + ["STAGED_STUB", "NOT CANONICAL", "NOT READY FOR REUSE", "PROMOTION HOLD"],
            "modules": sorted(info["modules"]), "ui": sorted(info["ui"]), "receipts": rc,
            "groq_audit_result": groq, "validation_receipt": val,
            "promotion_hold_doc": os.path.relpath(hold, ROOT) if hold.exists() else None,
        })
    return {"note": "STAGED — NOT canonical, NOT counted in canonical totals, NOT for reuse until promoted (requires Patrick/audit approval).",
            "pack_count": len(out), "packs": out}


staging_index = scan_staging()


def _lj(p: Path):
    try: return json.load(open(p))
    except Exception: return {}


def build_treasury():
    """Read the Sovereign Code Treasury registries and return the honest disk-truth block.
    Single integration point: the inspector + build_pages render THIS, not the legacy counts.
    Everything here is STARTER tier or reference — trusted_reuse stays 0, nothing is a workflow."""
    paths = {
        "embassy_registry": LIB / "embassy/embassy_registry.json",
        "ui_registry": LIB / "ui/ui_registry.json",
        "sub_data_index": LIB / "sub_data_index.json",           # actual path (root, not embassy/)
        "combo_candidates": LIB / "combo_candidates.json",        # actual path (root, not embassy/)
        "ui_component_index": LIB / "ui/ui_component_index.json",
        "reclassification_index": LIB / "ui/metercall-legos/reclassification_index.json",  # _index, not _map
        "governed_legos_registry": LIB / "promotions/governed_legos_registry.json",  # first-party promotions
    }
    present = {k: p.exists() for k, p in paths.items()}
    emb, uir = _lj(paths["embassy_registry"]), _lj(paths["ui_registry"])
    sub, comb = _lj(paths["sub_data_index"]), _lj(paths["combo_candidates"])
    uici, recl = _lj(paths["ui_component_index"]), _lj(paths["reclassification_index"])
    emb_pkgs, ui_srcs = emb.get("packages", []), uir.get("sources", [])

    def smoked(rs): return sum(1 for r in rs if r.get("status") == "STARTER_REUSE_SMOKED")
    def trusted(rs): return sum(1 for r in rs if r.get("status") == "TRUSTED_REUSE" or r.get("trusted_reuse_allowed") is True)
    backend_smoked, ui_smoked = smoked(emb_pkgs), smoked(ui_srcs)
    mirrored_trusted = trusted(emb_pkgs) + trusted(ui_srcs)  # third-party OSS stays 0 by design

    # First-party governed legos: count a promotion ONLY if its validation_receipt verifies PASS on disk.
    # A registry entry alone cannot inflate the trusted count — the proof must verify.
    gov = _lj(paths["governed_legos_registry"])
    governed = []
    for a in gov.get("governed_assets", []):
        rp = (a.get("proof_chain") or {}).get("validation_receipt")
        rcpt = _lj(ROOT / rp) if rp else {}
        verified = bool(a.get("trusted_reuse_allowed")) and rcpt.get("result") == "PASS" and rcpt.get("faults") == 0
        governed.append({"module_id": a.get("module_id"), "tier": a.get("governance_tier"),
                         "receipt_result": rcpt.get("result", "MISSING"), "faults": rcpt.get("faults"),
                         "network_sockets_opened": (rcpt.get("execution_envelope") or {}).get("network_sockets_opened"),
                         "patrick_approval_gate": a.get("patrick_approval_gate", rcpt.get("patrick_approval_gate")),
                         "verified_trusted": verified, "promotion_dir": a.get("promotion_dir")})
    governed_trusted = sum(1 for g in governed if g["verified_trusted"])
    trusted_total = mirrored_trusted + governed_trusted

    quarantine = []
    for r in emb_pkgs:
        if r.get("status") == "QUARANTINE":
            quarantine.append({"name": r.get("package_name"), "lane": "backend", "license": r.get("license"),
                               "reason": r.get("status_reason", "license not in permissive allowlist")})
    for r in ui_srcs:
        if r.get("status") == "QUARANTINE":
            quarantine.append({"name": r.get("component_name"), "lane": "ui", "license": r.get("license"),
                               "reason": r.get("status_reason", "license not in permissive allowlist")})

    tiers = (recl.get("summary") or {}).get("tier_counts", {})
    return {
        "label": "TREASURY_TRUTH",
        "trusted": False,
        "note": ("Honest disk truth from the Sovereign Code Treasury registries. Mirrored OSS is STARTER tier "
                 "only and stays trusted=0 by design. First-party legos reach TRUSTED_REUSE only via the full "
                 "chain (contracts + fixture + a REAL validation receipt that PASSES on disk) and are counted "
                 "only when that receipt verifies. patrick_approval_gate may still be PENDING."),
        "source_of_truth": {k: os.path.relpath(p, ROOT) for k, p in paths.items()},
        "registries_present": present,
        "starter_reuse_smoked": backend_smoked + ui_smoked,
        "starter_reuse_smoked_backend": backend_smoked,
        "starter_reuse_smoked_ui": ui_smoked,
        "sub_data_reference": (sub.get("summary") or {}).get("sub_data_entries", 0),
        "combo_candidates_created": (comb.get("summary") or {}).get("combo_candidates_created", 0),
        "workflow_candidates_created": (comb.get("summary") or {}).get("WORKFLOW_CANDIDATES_CREATED", 0),
        "trusted_reuse_count": trusted_total,
        "mirrored_trusted_count": mirrored_trusted,
        "governed_trusted_count": governed_trusted,
        "governed_assets": governed,
        "ui_components_indexed": (uici.get("summary") or {}).get("indexed_components", 0),
        "quarantine_count": len(quarantine),
        "quarantine_blocked": quarantine,
        "reclassified": {
            "assets": (recl.get("summary") or {}).get("reclassified_assets", 0),
            "first_party_ui_legos_starter_reuse": tiers.get("STARTER_REUSE", 0),
            "legacy_combo_candidate_reference": tiers.get("COMBO_CANDIDATE", 0),
            "reference_only": tiers.get("REFERENCE_ONLY", 0),
            "receipt_reference": tiers.get("RECEIPT_REFERENCE", 0),
            "discovery_reference": tiers.get("DISCOVERY_REFERENCE", 0),
        },
    }


treasury = build_treasury()

modules_index = {
    "schema": "metercall_module_library_index_v1", "indexed_at": NOW, "canonical_root": "metercall-site/library/modules",
    "local_url": f"{BASE}/library/modules/",
    "categories": {
        "workflows": {"count": wf_count, "source_path": "workflow_primitives/workflows/definitions/", "available_at": "library/modules/workflows/definitions/ (symlink)", "mode": "reference"},
        "combos": {"candidates": combo_candidates, "validated": validated, "source_path": "customer_kai_module_library_v0/MODULE_COMBO_UNIVERSE_CANDIDATES.json", "available_at": "library/modules/combos/", "mode": "copy"},
        "primitives": {"py_files": prim_count, "source_path": "workflow_primitives/", "available_at": "library/modules/primitives/workflow_primitives (symlink)", "mode": "reference"},
        "packs": {"count": pack_count, "source_path": "workflow_primitives/packs/", "available_at": "library/modules/packs/packs (symlink)", "mode": "reference"},
        "receipts": {"bundles": receipt_bundles, "source_path": "demo_runs/, program_runs/, email_send_runs/", "available_at": "library/modules/receipts/ (symlinks)", "mode": "reference"},
        "sources": {"module_library_modules": modlib_modules, "module_library_branches": modlib_branches, "indexed_modules": ckl_modules, "source_path": str(MODLIB) + " (self-hosted git, not GitHub) + customer_kai_module_library_v0/", "available_at": "library/modules/sources/module-library/", "mode": "index", "present": modlib_present, "nick_branch": "work/nick/module-intake"},
    },
    "staging": staging_index,
}
wj(LIB / "modules/index.json", modules_index)

# ── 3) UI LIBRARY content (index existing generated UI; reference, don't move) ──
_LEGO_EXCL = {"ui", "modules", "staging", "_core"}   # inspector sub-pages / non-lego dirs, not legos
legos = sorted(p for p in glob.glob(str(LIB / "*/*.html")) if Path(p).parent.name not in _LEGO_EXCL)
lego_cats = sorted({Path(p).parent.name for p in legos})
def cnt(pat): return len(glob.glob(pat, recursive=True))
ui_index = {
    "schema": "metercall_ui_library_index_v1", "indexed_at": NOW, "canonical_root": "metercall-site/library/ui",
    "local_url": f"{BASE}/library/ui/",
    "categories": {
        "components": {"count": len(legos), "lego_categories": lego_cats, "source_path": "library/<category>/*.html (MeterCall Total Library legos)", "open_base": f"{BASE}/library/", "mode": "index"},
        "pages": {"count": cnt(str(ROOT / "ui/dist/*.html")), "source_path": "ui/dist/", "open_base": f"{BASE}/ui/dist/", "mode": "index"},
        "sites": {"count": cnt(str(ROOT / "kaiai-variants/*.html")), "source_path": "kaiai-variants/", "open_base": f"{BASE}/kaiai-variants/", "mode": "index"},
        "previews": {"count": len([p for p in glob.glob(str(ROOT / "preview-home-*")) if os.path.isdir(p)]), "source_path": "preview-home-*/", "open_base": f"{BASE}/", "mode": "index"},
        "examples": {"count": cnt(str(ROOT / "ui/public/proof/*.json")), "source_path": "ui/public/proof/ (proof bundles the UI renders)", "open_base": f"{BASE}/ui/public/proof/", "mode": "index"},
    },
    "legos": [{"category": Path(p).parent.name, "file": Path(p).name, "open": f"{BASE}/library/{Path(p).parent.name}/{Path(p).name}"} for p in legos],
}
wj(LIB / "ui/index.json", ui_index)

ui_total = sum(c.get("count", 0) for c in ui_index["categories"].values())
mod_total = wf_count + validated + pack_count + receipt_bundles

# ── 4) central manifest.json (Patrick's schema) ──
manifest = {
    "canonicalRoot": "metercall-site/library",
    "indexedAt": NOW,
    "note": "Canonical LOCAL inspection center. Non-destructive aggregation/index layer; sources are referenced, not moved. The original 'MeterCall Total Library' UI legos are preserved at library/ui/legos.manifest.json + library/ui/README.legos.md. HEADLINE TRUTH is manifest.treasury (Sovereign Code Treasury disk counts); the legacy moduleLibrary counts are reference-only and NOT trusted.",
    "treasury": treasury,
    "uiLibrary": {"path": "library/ui", "localUrl": f"{BASE}/library/ui/", "status": "indexed", "counts": {k: (v.get("count") or v.get("candidates") or 0) for k, v in ui_index["categories"].items()}},
    "moduleLibrary": {"path": "library/modules", "localUrl": f"{BASE}/library/modules/", "status": "LEGACY_REFERENCE_ONLY", "trusted": False, "deprecated_count_source": True,
                      "note": "Legacy symlink/index-derived counts (workflows/combos/validated). These are DEPRECATED_COUNT_SOURCE / NOT_TRUSTED reference numbers — NOT active product inventory and NOT treasury truth. Honest disk counts live in manifest.treasury.",
                      "counts": {"workflows": wf_count, "combo_candidates": combo_candidates, "validated_workflows": validated, "packs": pack_count, "receipt_bundles": receipt_bundles, "external_modules": modlib_modules}},
    "stagedLibrary": {"path": "library/staging", "status": "STAGED — NOT canonical", "counted_in_canonical": False, "pack_count": staging_index["pack_count"], "packs": [p["pack"] for p in staging_index["packs"]], "note": "Visible in inspector under Staging; promotion to canonical requires Patrick/audit approval."},
    "indexPage": {"localUrl": f"{BASE}/library/", "title": "Metercall Local Library"},
    "sources": [
        {"name": "module combos", "sourcePath": "customer_kai_module_library_v0/MODULE_COMBO_UNIVERSE_CANDIDATES.json", "targetPath": "library/modules/combos/MODULE_COMBO_UNIVERSE_CANDIDATES.json", "mode": "copy", "status": "copied"},
        {"name": "workflow definitions", "sourcePath": "workflow_primitives/workflows/definitions/", "targetPath": "library/modules/workflows/definitions/", "mode": "symlink", "status": "indexed"},
        {"name": "external module-library", "sourcePath": str(MODLIB) + " (ssh://git@157.230.177.45 — self-hosted, NOT GitHub)", "targetPath": "library/modules/sources/module-library/", "mode": "index", "status": "indexed" if modlib_present else "missing"},
        {"name": "MASTER_LIBRARY_ALL", "sourcePath": str(MASTER), "targetPath": "(not used)", "mode": "deprecated", "status": "stale"},
        {"name": "duplicate clone", "sourcePath": "/Users/patricklinden/Documents/GitHub/metercall-site", "targetPath": "(ignored)", "mode": "ignore", "status": "stale"},
    ],
}
wj(LIB / "manifest.json", manifest)

# ── 5) READMEs ──
(LIB / "README.md").write_text(f"""# Metercall Local Library — canonical center

**Canonical root:** `metercall-site/library/` · indexed {NOW}

One obvious place for Nick / Kai / the terminal to find UI and modules. This is a
**non-destructive aggregation/index layer** — source folders are referenced (copy /
symlink / index), never moved or deleted.

Open the inspection page: **{BASE}/library/**

## Two libraries
| Library | Path | Local link | What |
|---|---|---|---|
| **UI Library** | `library/ui/` | {BASE}/library/ui/ | components, pages, sites, previews, examples |
| **Module Library** | `library/modules/` | {BASE}/library/modules/ | workflows, combos, primitives, packs, receipts, sources |

## Counts (at index time)
- UI: {ui_total} indexed items ({len(legos)} legos)
- Modules: {wf_count} workflow defs · {combo_candidates} combo candidates ({validated} validated) · {pack_count} packs · {receipt_bundles} receipt bundles

## Notes
- The original **MeterCall Total Library** UI legos (the prior `library/manifest.json` + `README.md`) are **preserved** at `library/ui/legos.manifest.json` and `library/ui/README.legos.md` — nothing was deleted.
- `MASTER_LIBRARY_ALL` (Jun-9 snapshot) is **DEPRECATED / stale** — not canonical.
- External module source of truth: `/Users/patricklinden/metercall/module-library` (self-hosted git, auto-pulled; Nick's branch `work/nick/module-intake`). Not deleted.
- Rebuild this layer: `python3 library/build_central_library.py`
""")
(LIB / "ui/README.md").write_text(f"# UI Library\n\nGenerated/handmade UI: components, pages, sites, previews, examples. Indexed {NOW}.\nLocal link: {BASE}/library/ui/\n\nSee `index.json` for categories + counts. Original legos preserved in `legos.manifest.json` / `README.legos.md`.\n")
(LIB / "modules/README.md").write_text(f"# Module Library\n\nWorkflows, combos, primitives, packs, receipts, and external module sources. Indexed {NOW}.\nLocal link: {BASE}/library/modules/\n\nSee `index.json` for categories + counts + source paths. Sources are referenced (symlink/copy/index), not moved.\n")

# ── 6) mark MASTER_LIBRARY_ALL deprecated ──
if MASTER.exists():
    try:
        (MASTER / "DEPRECATED_STALE.md").write_text(f"# DEPRECATED / STALE — do not use as canonical\n\nThis is a Jun-9 snapshot. Canonical library is now `metercall-site/library/` (indexed {NOW}).\nServe + inspect: {BASE}/library/\n")
    except Exception: pass

print(json.dumps({"ok": True, "indexed_at": NOW,
                  "treasury_truth": {"starter_reuse_smoked": treasury["starter_reuse_smoked"],
                                     "sub_data_reference": treasury["sub_data_reference"],
                                     "combo_candidates_created": treasury["combo_candidates_created"],
                                     "workflow_candidates_created": treasury["workflow_candidates_created"],
                                     "trusted_reuse_count": treasury["trusted_reuse_count"],
                                     "quarantine_blocked": treasury["quarantine_count"],
                                     "reclassified_assets": treasury["reclassified"]["assets"]},
                  "ui_items": ui_total, "legos": len(legos),
                  "LEGACY_REFERENCE_ONLY": {"workflows": wf_count, "combo_candidates": combo_candidates, "validated": validated,
                                            "packs": pack_count, "receipt_bundles": receipt_bundles,
                                            "external_modules": modlib_modules, "note": "NOT trusted, NOT treasury truth"}}, indent=2))
