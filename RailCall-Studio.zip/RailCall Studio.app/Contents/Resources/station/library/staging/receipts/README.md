# Staging — Receipts (library-use proof)

Receipts for staged builds land **here**. Every build receipt must prove the library was
checked first (see [`../../LIBRARY_FIRST_RULE.md`](../../LIBRARY_FIRST_RULE.md)) and include:

- user request
- classified intent
- library indexes searched
- shelf matches found
- shelf items reused
- shelf items skipped
- new staged items created (if any)
- reason for building new instead of reusing

A build with **no library-search result is an automatic FAIL**. Receipts here are the
evidence an audit/Patrick uses before promoting any staged item to canonical.
