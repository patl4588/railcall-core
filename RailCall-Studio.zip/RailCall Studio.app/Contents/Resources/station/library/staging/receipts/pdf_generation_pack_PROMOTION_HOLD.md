# PROMOTION HOLD — `pdf_generation_pack`

**Status: STAGED_STUB · NOT CANONICAL · NOT READY FOR REUSE · PROMOTION HOLD**

This pack is visible in the library inspector under **Staging → Modules → PDF Generation
Pack** so it can be inspected safely. It is **not** in the canonical library and is **not**
counted in any canonical total. Do not reuse these items in a build. Promotion to the
trusted canonical shelf requires Patrick's explicit approval after the checklist below is
satisfied.

> Product rule: **Staged belongs in the library. Canonical belongs only after promotion.**

---

## What is staged

6 items, all `status: STAGED_STUB` / `STUB_NEEDS_BUILD`, all `canonical: false`,
`preview_only: true`, `execution_tier: R0_PREVIEW_ONLY`, all six live flags `false`.

| id | kind | intent family | path |
|---|---|---|---|
| `pdf_generation_core` | module | pdf_generation | `library/staging/modules/pdf/pdf_generation_core.json` |
| `pdf_template_engine` | module | pdf_generation | `library/staging/modules/pdf/pdf_template_engine.json` |
| `proposal_pdf_builder` | module | proposal_pdf | `library/staging/modules/pdf/proposal_pdf_builder.json` |
| `invoice_pdf_builder` | module | invoice_pdf | `library/staging/modules/pdf/invoice_pdf_builder.json` |
| `report_pdf_builder` | module | report_pdf | `library/staging/modules/pdf/report_pdf_builder.json` |
| `pdf_preview_renderer` | ui | pdf_generation | `library/staging/ui/pdf/pdf_preview_renderer.json` |

## Evidence on file (all read-only, in `library/staging/receipts/`)

- **Build receipt (library-first proof):** `pdf_generation_pack__2026-06-15T13-45-18-229Z.json`
  — dry-run, `gaps_total: 6`, `reused_items: []`. Searched `library/manifest.json`
  (15 entries); found **0 strong matches** and 14 weak matches, all skipped as
  `loose_match_different_purpose_not_reused` (kanban/forms/auth UI legos, unrelated).
- **Local validation:** `validation.passed: true` — 8 checks all pass (json_validity,
  required_fields_present, duplicate_check, link_path_check, no_secrets,
  no_live_connector_actions, no_production_writes, docs_match_files).
- **Groq audit result:** `pdf_generation_pack__2026-06-15T14-00-02-270Z.groq_audit_result.json`
  — `llama-3.3-70b-versatile`, verdict **`GO_FOR_STAGED_LIBRARY_PACK`**, `failed_checks: []`,
  `patches_required: []`, audited 2026-06-15T14:00:04Z.

## Why this is HOLD, not promote

1. **Stubs only.** Every item is `STAGED_STUB` / `STUB_NEEDS_BUILD` — no implemented or
   executable behavior. Canonical shelf items must be real and reusable.
2. **`R0_PREVIEW_ONLY`.** Nothing here is execution-verified.
3. **The Groq verdict is a *staging* verdict, not a promotion verdict.**
   `GO_FOR_STAGED_LIBRARY_PACK` means "fine to live in `library/staging/`" — it explicitly
   does **not** authorize moving into canonical.
4. **Library-first search ran against a partial shelf.** At search time
   `library/ui/index.json` and `library/modules/index.json` were `absent`, so the
   duplicate/reuse check did not run against the full built indexes. Must be re-run.

## Promotion checklist (all required before canonical)

- [ ] Stubs replaced with real, executable module/UI definitions (no `STUB_NEEDS_BUILD`).
- [ ] Library-first search **re-run against the now-built** `library/ui/index.json` +
      `library/modules/index.json` → still 0 strong duplicates.
- [ ] Local validation re-passes on the real (non-stub) files.
- [ ] Fresh audit (Groq + human) returning a **promotion** verdict — not the staging verdict.
- [ ] Patrick's explicit approval to promote.
- [ ] Only then: move into `library/modules/`, update the canonical index to count it and
      mark it reusable, regenerate inspector.

## Locked constraints (unchanged by staging)

no canonical promotion · no main merge · no push · no deploy · no real send/billing/CRM/
workbook mutation · no secrets · frozen MCP untouched · no automatic promotion without
Patrick approval. Origin branch of record for these files:
`library-pack/pdf-generation-v0` (`pushed: false`).
