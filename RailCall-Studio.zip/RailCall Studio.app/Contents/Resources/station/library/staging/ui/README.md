# Staging — UI (gaps only)

New UI pieces (components / pages / sites / previews / examples) that Groq/Kai builds land
**here first** — never directly in canonical `library/ui/`.

A staged item is allowed **only after** a library-first shelf check found no suitable match
(see [`../../LIBRARY_FIRST_RULE.md`](../../LIBRARY_FIRST_RULE.md)). Each staged item must
carry a receipt proving: the user request, classified intent, indexes searched, matches
found, and why nothing matched.

**Promotion** to canonical `library/ui/` requires **Patrick / approved-audit** review.
Nothing is promoted automatically.
