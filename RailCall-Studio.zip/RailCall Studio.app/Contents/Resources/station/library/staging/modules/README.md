# Staging — Modules (gaps only)

New modules / workflows / combos / primitives / packs that Groq/Kai builds land **here
first** — never directly in canonical `library/modules/`.

A staged item is allowed **only after** a library-first shelf check found no suitable match
(see [`../../LIBRARY_FIRST_RULE.md`](../../LIBRARY_FIRST_RULE.md)). Each staged item must
carry a receipt proving: the user request, classified intent, indexes searched, matches
found, shelf items reused/skipped, and why nothing matched.

**Promotion** to canonical `library/modules/` requires **Patrick / approved-audit** review.
Nothing is promoted automatically.
