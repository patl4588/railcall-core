#!/usr/bin/env bash
# Metercall library sync — pull the shared library branch + re-index. Run every 5 min via cron.
#
# Both Pat and Nick push to library-organization-v0; this keeps each machine's local library
# fresh. The module-library itself is auto-pulled separately (scripts/auto_pull_module_library.sh),
# so re-indexing here picks up Nick's newest modules. Derived artifacts (indexes + the external
# catalogs) are gitignored and rebuilt locally — nothing generated is pushed, so no conflicts.
#
# Run from a DEDICATED checkout/worktree that is on branch library-organization-v0 (NOT your main
# metercall-site checkout, which automation keeps on main). Override the path with METERCALL_SITE.
set -euo pipefail
REPO="${METERCALL_SITE:-$HOME/metercall-site-library}"
cd "$REPO"
git pull --rebase --autostash --quiet || { echo "[library-sync] pull needs manual resolve in $REPO" >&2; exit 1; }
python3 library/build_central_library.py >/dev/null
echo "[library-sync] $(date '+%Y-%m-%d %H:%M:%S') re-indexed $(git rev-parse --short HEAD)"
