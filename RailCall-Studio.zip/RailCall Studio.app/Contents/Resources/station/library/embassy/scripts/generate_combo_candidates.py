#!/usr/bin/env python3
"""Sovereign Code Treasury — combo candidate generator (REAL).
Propose candidate COMBINATIONS of mirrored assets (e.g. form + validation, table + styling). Each combo
references ONLY assets that are STARTER_REUSE_SMOKED in the registries (membership is validated; a combo
with any missing/unsmoked member is dropped to INCOMPLETE and excluded from the candidate count).

A combo is a CANDIDATE only: status COMBO_CANDIDATE, is_workflow=false, trusted_reuse_allowed=false.
It is NOT a workflow. To ever become a WORKFLOW_CANDIDATE it needs a real Metercall wrapper + I/O contract
+ fixture + validation receipt + Patrick approval — none of which exist here, so WORKFLOW_CANDIDATES_CREATED
stays 0. Writes library/combo_candidates.json.

  python3 library/embassy/scripts/generate_combo_candidates.py [--dry-run]
"""
import json, sys, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
EMB_REG = ROOT / "library" / "embassy" / "embassy_registry.json"
UI_REG = ROOT / "library" / "ui" / "ui_registry.json"
OUT = ROOT / "library" / "combo_candidates.json"
DRY = "--dry-run" in sys.argv

# Curated candidate combinations. Members must be STARTER_REUSE_SMOKED in a registry to count.
COMBOS = [
    {"combo_id": "combo:validated_form", "intent": "form with schema validation",
     "members": ["react-hook-form", "zod"]},
    {"combo_id": "combo:data_grid", "intent": "sortable/filterable data table with styled cells",
     "members": ["@tanstack/react-table", "tailwind-merge", "class-variance-authority"]},
    {"combo_id": "combo:command_palette", "intent": "⌘K command palette with icons",
     "members": ["cmdk", "lucide-react"]},
    {"combo_id": "combo:date_field", "intent": "date input: popover + calendar + date math",
     "members": ["react-day-picker", "@radix-ui/react-popover", "date-fns"]},
    {"combo_id": "combo:modal_stack", "intent": "dialog on desktop, drawer on mobile",
     "members": ["@radix-ui/react-dialog", "vaul"]},
    {"combo_id": "combo:charts_panel", "intent": "resizable dashboard panel with charts",
     "members": ["recharts", "react-resizable-panels"]},
    {"combo_id": "combo:styled_button", "intent": "variant-driven button styling",
     "members": ["class-variance-authority", "tailwind-merge", "clsx"]},
    {"combo_id": "combo:toast_feedback", "intent": "toast notifications with icons",
     "members": ["sonner", "lucide-react"]},
    {"combo_id": "combo:id_and_slug", "intent": "stable ids + url slugs for records",
     "members": ["nanoid", "slugify"]},
    {"combo_id": "combo:markdown_render", "intent": "render markdown content blocks",
     "members": ["marked"]},
    {"combo_id": "combo:jwt_auth_util", "intent": "hash password + sign/verify session token",
     "members": ["bcryptjs", "jsonwebtoken"]},
    {"combo_id": "combo:config_loader", "intent": "load + validate env/config",
     "members": ["dotenv", "zod"]},
    {"combo_id": "combo:csv_import_grid", "intent": "parse an uploaded CSV → render it in a data grid",
     "members": ["csv-parse", "@tanstack/react-table"]},
    {"combo_id": "combo:csv_export_named", "intent": "serialize rows → a slug-named CSV download",
     "members": ["csv-stringify", "slugify"]},
    {"combo_id": "combo:api_fetch_validated", "intent": "fetch an API then schema-validate the response",
     "members": ["axios", "zod"]},
    {"combo_id": "combo:html_scrape_to_markdown", "intent": "scrape HTML → render as markdown",
     "members": ["cheerio", "marked"]},
    {"combo_id": "combo:file_search_palette", "intent": "glob the workspace → ⌘K file picker",
     "members": ["fast-glob", "cmdk"]},
    {"combo_id": "combo:resilient_batch", "intent": "bounded-concurrency batch with per-item retry",
     "members": ["p-map", "p-retry"]},
    {"combo_id": "combo:layered_config", "intent": "merge env + file config then validate",
     "members": ["deepmerge", "dotenv", "zod"]},
    {"combo_id": "combo:namespaced_logger", "intent": "namespaced + colorized debug logging",
     "members": ["debug", "picocolors"]},
]


def smoked_set():
    s = {}
    if EMB_REG.exists():
        for r in json.load(open(EMB_REG)).get("packages", []):
            if r.get("status") == "STARTER_REUSE_SMOKED":
                s[r["package_name"]] = {"lane": "backend", "license": r.get("license"), "version": r.get("version_or_commit")}
    if UI_REG.exists():
        for r in json.load(open(UI_REG)).get("sources", []):
            if r.get("status") == "STARTER_REUSE_SMOKED":
                s[r["component_name"]] = {"lane": "ui", "license": r.get("license"), "version": r.get("version_or_commit")}
    return s


def main():
    smoked = smoked_set()
    out_combos, candidate_count, incomplete = [], 0, 0
    for combo in COMBOS:
        missing = [m for m in combo["members"] if m not in smoked]
        resolved = [{"name": m, **smoked[m]} for m in combo["members"] if m in smoked]
        complete = not missing
        rec = {"combo_id": combo["combo_id"], "intent": combo["intent"],
               "status": "COMBO_CANDIDATE" if complete else "INCOMPLETE",
               "is_workflow": False, "trusted_reuse_allowed": False, "promotion_required": True, "promotion_status": "NONE",
               "members_requested": combo["members"], "members_resolved": resolved, "members_missing": missing,
               "becomes_workflow_candidate_when": "a Metercall wrapper + I/O contract + fixture + validation receipt + Patrick approval exist (none yet)",
               "note": "a candidate combination of mirrored STARTER assets — NOT an executable workflow, NOT trusted reuse"}
        out_combos.append(rec)
        if complete:
            candidate_count += 1
        else:
            incomplete += 1

    out = {"schema": "combo_candidates.v1", "mission": "SOVEREIGN_CODE_TREASURY_AND_UI_TREASURY_PILOT_V1",
           "built_by": "library/embassy/scripts/generate_combo_candidates.py",
           "built_at": datetime.datetime.now().isoformat(), "dry_run": DRY,
           "trusted_reuse_allowed_global": False,
           "rules": ["combos are CANDIDATE combinations only; every member is a STARTER_REUSE_SMOKED mirror",
                     "a combo is NOT a workflow and NOT trusted reuse",
                     "a combo only becomes a WORKFLOW_CANDIDATE with a real wrapper + contract + fixture + receipt + Patrick approval",
                     "combos referencing any missing/unsmoked member are marked INCOMPLETE and excluded from the candidate count"],
           "summary": {"combo_candidates_created": candidate_count, "incomplete_combos": incomplete,
                       "WORKFLOW_CANDIDATES_CREATED": 0, "TRUSTED_REUSE": 0},
           "combos": out_combos}
    if not DRY:
        json.dump(out, open(OUT, "w"), indent=2)
    print(json.dumps(out["summary"], indent=2))
    for c in out_combos:
        print(f"  {c['status']:16} {c['combo_id']:26} <- {', '.join(c['members_requested'])}"
              + (f"  MISSING:{c['members_missing']}" if c["members_missing"] else ""))
    print(f"  wrote {OUT.relative_to(ROOT)}" if not DRY else "  (dry-run: nothing written)")


if __name__ == "__main__":
    main()
