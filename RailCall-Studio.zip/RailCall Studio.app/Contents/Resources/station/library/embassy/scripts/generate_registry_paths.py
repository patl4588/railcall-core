#!/usr/bin/env python3
"""Normalize + publish the canonical source-of-truth paths for every treasury registry/index
(Grok cleanup item 1: some indexes were not where the report said). Writes library/REGISTRY_PATHS.json
— the single explicit, committed map of where each registry lives, so the inspector, build layer, and
any audit all read the same locations. Reports any mismatch against the originally-briefed paths.

  python3 library/embassy/scripts/generate_registry_paths.py [--dry-run]
"""
import json, sys, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "library" / "REGISTRY_PATHS.json"
DRY = "--dry-run" in sys.argv

# canonical (actual) path + the path the original brief listed (for transparency on the correction)
REGISTRIES = {
    "embassy_registry":       {"path": "library/embassy/embassy_registry.json",                 "briefed": "library/embassy/embassy_registry.json"},
    "ui_registry":            {"path": "library/ui/ui_registry.json",                            "briefed": "library/ui/ui_registry.json"},
    "sub_data_index":         {"path": "library/sub_data_index.json",                            "briefed": "library/embassy/sub_data_index.json"},
    "combo_candidates":       {"path": "library/combo_candidates.json",                          "briefed": "library/embassy/combo_candidates.json"},
    "ui_component_index":     {"path": "library/ui/ui_component_index.json",                      "briefed": "library/ui/ui_component_index.json"},
    "reclassification_index": {"path": "library/ui/metercall-legos/reclassification_index.json", "briefed": "library/ui/metercall-legos/reclassification_map.json"},
    "third_party_licenses":   {"path": "library/THIRD_PARTY_LICENSES.md",                         "briefed": "library/THIRD_PARTY_LICENSES.md"},
}

entries, corrections = {}, []
for key, info in REGISTRIES.items():
    exists = (ROOT / info["path"]).exists()
    corrected = info["path"] != info["briefed"]
    entries[key] = {"canonical_path": info["path"], "exists": exists,
                    "briefed_path": info["briefed"], "path_corrected": corrected}
    if corrected:
        corrections.append({"registry": key, "was_briefed": info["briefed"], "actual_canonical": info["path"]})

out = {"schema": "registry_paths.v1", "mission": "TREASURY_INSPECTOR_INTEGRATION_V1",
       "built_by": "library/embassy/scripts/generate_registry_paths.py",
       "built_at": datetime.datetime.now().isoformat(), "dry_run": DRY,
       "note": "Single explicit source-of-truth path map. sub_data_index + combo_candidates are CROSS-CUTTING "
               "(backend + UI) so they live at library/ root, not under embassy/. reclassification file is "
               "reclassification_index.json (not _map). All readers must use canonical_path.",
       "all_present": all(e["exists"] for e in entries.values()),
       "path_corrections": corrections, "registries": entries}
if not DRY:
    json.dump(out, open(OUT, "w"), indent=2)
print(json.dumps({"all_present": out["all_present"], "path_corrections": len(corrections),
                  "missing": [k for k, e in entries.items() if not e["exists"]]}, indent=2))
for c in corrections:
    print(f"  CORRECTED  {c['registry']}: briefed {c['was_briefed']} -> actual {c['actual_canonical']}")
print(f"  wrote {OUT.relative_to(ROOT)}" if not DRY else "  (dry-run)")
