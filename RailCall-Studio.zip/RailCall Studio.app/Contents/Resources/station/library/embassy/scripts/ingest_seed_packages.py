#!/usr/bin/env python3
"""Sovereign Code Treasury — backend package ingester (REAL).
Screen each seed package's license LIVE from npm against the permissive allowlist; mirror permissive
tarballs locally with a sha256 + version pin; import-smoke each (node require). Copyleft/unknown ->
QUARANTINE (not mirrored). Writes library/embassy/embassy_registry.json + per-package receipts.
TRUSTED_REUSE stays 0; trusted_reuse_allowed=false on every asset.

  python3 library/embassy/scripts/ingest_seed_packages.py [--dry-run]
"""
import json, os, sys, hashlib, datetime, shutil, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
EMB = ROOT / "library" / "embassy"
STORAGE, QUAR, RECE = EMB / "storage", EMB / "quarantine", EMB / "receipts"
for d in (STORAGE, QUAR, RECE):
    d.mkdir(parents=True, exist_ok=True)
DRY = "--dry-run" in sys.argv

seed = json.load(open(EMB / "seed_packages.json"))
ALLOW = {x.upper() for x in seed.get("permissive_allowlist", [])}


def npm(args):
    return subprocess.run(["npm"] + args, capture_output=True, text=True)


def norm_license(lic):
    if isinstance(lic, dict):
        return lic.get("type", "UNKNOWN")
    return lic or "UNKNOWN"


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return "sha256:" + h.hexdigest()


records, to_install = [], []
for c in seed["candidates"]:
    name, ver = c["name"], c.get("version", "latest")
    r = npm(["view", f"{name}@{ver}", "version", "license", "--json"])
    if r.returncode != 0:
        records.append({"asset_id": f"backend:{name}", "asset_type": "backend_package", "package_name": name,
                        "version_or_commit": ver, "license": "UNKNOWN", "license_allowed": False,
                        "status": "QUARANTINE", "status_reason": "npm view failed (not found/network)",
                        "trusted_reuse_allowed": False, "promotion_status": "NONE", "smoke_test_result": "n/a"})
        continue
    try:
        meta = json.loads(r.stdout)
    except Exception:
        meta = {}
    license = norm_license(meta.get("license"))
    version = meta.get("version", ver)
    allowed = license.upper() in ALLOW
    rec = {"asset_id": f"backend:{name}@{version}", "asset_type": "backend_package", "package_name": name,
           "ecosystem": "npm", "version_or_commit": version,
           "source_url": f"https://registry.npmjs.org/{name}/-/{name}-{version}.tgz",
           "license": license, "license_allowed": allowed,
           "copyright_notice_present": None, "notice_file_present": None,
           "local_mirror_path": None, "archive_sha256": None,
           "ingested_at": datetime.datetime.now().isoformat(), "update_policy": "static",
           "promotion_status": "NONE", "trusted_reuse_allowed": False,
           "smoke_test_type": "IMPORT_SMOKE",
           "smoke_test_command": f"node -e \"require('{name}')\"", "smoke_test_result": "n/a",
           "smoke_label": "IMPORT_SMOKE_NOT_RUN",
           "attribution": f"third-party '{name}' (c) its authors, {license} — mirrored locally, NOT authored or owned by Metercall"}
    if not allowed:
        reason = f"license '{license}' not in permissive allowlist (copyleft/dual/unknown) — NOT mirrored"
        rec.update({"status": "QUARANTINE", "status_reason": reason, "quarantine_reason": reason,
                    "license_failure": True, "local_mirror_path": None, "archive_sha256": None,
                    "smoke_label": "QUARANTINED_NOT_SMOKED"})
        json.dump(rec, open(QUAR / f"{name}.quarantine.json", "w"), indent=2)
        records.append(rec)
        continue
    if DRY:
        rec.update({"status": "STARTER_REUSE", "status_reason": "dry-run: license allowed; would mirror"})
        records.append(rec)
        continue
    pkgdir = STORAGE / f"{name}@{version}"
    pkgdir.mkdir(parents=True, exist_ok=True)
    pr = npm(["pack", f"{name}@{version}", "--pack-destination", str(pkgdir), "--json"])
    if pr.returncode != 0:
        rec.update({"status": "QUARANTINE", "status_reason": "npm pack failed", "quarantine_reason": "npm pack failed",
                    "local_mirror_path": None, "smoke_label": "QUARANTINED_NOT_SMOKED"})
        json.dump(rec, open(QUAR / f"{name}.quarantine.json", "w"), indent=2)
        records.append(rec)
        continue
    try:
        fn = json.loads(pr.stdout)[0]["filename"]
    except Exception:
        fn = f"{name}-{version}.tgz"
    tgz = pkgdir / fn
    rec.update({"status": "STARTER_REUSE", "status_reason": "mirrored; license allowed; sha256 + version pinned; license/notice preserved in tarball",
                "local_mirror_path": str(tgz.relative_to(ROOT)), "archive_sha256": sha256_file(tgz),
                "copyright_notice_present": True, "notice_file_present": True})
    records.append(rec)
    to_install.append(f"{name}@{version}")

if to_install and not DRY:
    smoke = EMB / ".smoke_env"
    smoke.mkdir(exist_ok=True)
    (smoke / "package.json").write_text('{"name":"embassy-smoke","private":true}\n')
    subprocess.run(["npm", "install", *to_install, "--prefix", str(smoke), "--no-audit", "--no-fund", "--no-save"], capture_output=True, text=True)
    for rec in records:
        if rec.get("status") != "STARTER_REUSE":
            continue
        pkg = rec["package_name"]
        sp = subprocess.run(["node", "-e", f"require('{pkg}')"], cwd=str(smoke), capture_output=True, text=True)
        kind = "cjs"
        if sp.returncode != 0:
            # real ESM fallback: genuinely dynamic-import the module (many modern pkgs are ESM-only)
            sp = subprocess.run(["node", "--input-type=module", "-e",
                                 f"import('{pkg}').then(()=>process.exit(0)).catch(e=>{{console.error(e);process.exit(1)}})"],
                                cwd=str(smoke), capture_output=True, text=True)
            kind = "esm"
        if sp.returncode == 0:
            rec["status"] = "STARTER_REUSE_SMOKED"
            rec["smoke_test_result"] = "PASS"
            rec["smoke_label"] = "IMPORT_SMOKE_PASSED"
            rec["import_kind"] = kind
        else:
            rec["smoke_test_result"] = "FAIL"
            rec["smoke_label"] = "IMPORT_SMOKE_FAILED"
            rec["smoke_error"] = (sp.stderr or "")[:160]  # stays STARTER_REUSE (mirrored, not smoked)
    shutil.rmtree(smoke, ignore_errors=True)

counts = {t: sum(1 for r in records if r.get("status") == t) for t in ["REFERENCE_ONLY", "STARTER_REUSE", "STARTER_REUSE_SMOKED", "QUARANTINE"]}
counts["TRUSTED_REUSE"] = 0
# Grok reconciliation: backend smoke is a real import (node require), distinct from the UI entry-resolution smoke.
counts["BACKEND_IMPORT_SMOKED"] = counts["STARTER_REUSE_SMOKED"]
counts["BACKEND_QUARANTINED"] = counts["QUARANTINE"]
registry = {"schema": "embassy_registry.v1", "mission": "SOVEREIGN_CODE_TREASURY_AND_UI_TREASURY_PILOT_V1",
            "built_by": "library/embassy/scripts/ingest_seed_packages.py", "built_at": datetime.datetime.now().isoformat(),
            "permissive_allowlist": sorted(ALLOW), "trusted_reuse_allowed_global": False,
            "smoke_kind": "IMPORT_SMOKE",
            "smoke_kind_note": "Backend smoke runs node -e require('<pkg>') in a clean install — a real import. A package passing here is IMPORT_SMOKE_PASSED.",
            "rules": ["STARTER tier only; no TRUSTED_REUSE without a Metercall wrapper + contracts + fixture + validation + receipt + Patrick approval",
                      "mirrored packages are third-party, NOT owned by Metercall (license/notice preserved in tarball)",
                      "no live pulls during trusted execution; only the local pinned mirror is used",
                      "license screen is conservative: dual/copyleft/unknown -> QUARANTINE; covers the mirrored package, not yet the full transitive graph"],
            "summary": counts, "packages": records}
json.dump(registry, open(EMB / "embassy_registry.json", "w"), indent=2)
for r in records:
    json.dump(r, open(RECE / f"{r['package_name']}.receipt.json", "w"), indent=2)
print(json.dumps(counts, indent=2))
for r in records:
    print(f"  {r.get('status', '?'):22} {r['package_name']}@{r.get('version_or_commit', '?')} [{r.get('license', '?')}] smoke={r.get('smoke_test_result', '-')}")
