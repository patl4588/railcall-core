#!/usr/bin/env python3
"""Sovereign Code Treasury — sub-data index generator (REAL, OFFLINE).
Extract static, reference-only sub-data from the LOCAL mirrored tarballs only (no live pulls): subpath
exports, bin entries, declared dependency names, keywords, and (for icon sets) a sampled icon-module
listing. Every entry is SUB_DATA_REFERENCE — reference catalog material, NOT executable, NOT trusted.
Reads both embassy_registry.json + ui_registry.json; writes library/sub_data_index.json.

  python3 library/embassy/scripts/generate_sub_data_index.py [--dry-run]
"""
import json, sys, tarfile, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
EMB_REG = ROOT / "library" / "embassy" / "embassy_registry.json"
UI_REG = ROOT / "library" / "ui" / "ui_registry.json"
OUT = ROOT / "library" / "sub_data_index.json"
DRY = "--dry-run" in sys.argv


def load_reg(p, key):
    if not p.exists():
        return []
    d = json.load(open(p))
    return d.get(key, [])


def read_member_json(tf, name):
    try:
        f = tf.extractfile(name)
        return json.loads(f.read().decode("utf-8")) if f else None
    except Exception:
        return None


def extract(tgz_path, role):
    """Read package/package.json + sample file listing from a local tarball (offline)."""
    p = ROOT / tgz_path
    info = {"subpath_exports": [], "bin": [], "dependency_names": [], "keywords": [],
            "icon_module_count": None, "sample_icon_names": []}
    if not p.exists():
        return info, "tarball missing"
    try:
        with tarfile.open(p, "r:gz") as tf:
            members = tf.getnames()
            pj = read_member_json(tf, "package/package.json")
            if isinstance(pj, dict):
                exp = pj.get("exports")
                if isinstance(exp, dict):
                    info["subpath_exports"] = sorted([k for k in exp.keys() if k not in (".",)])[:50]
                b = pj.get("bin")
                if isinstance(b, dict):
                    info["bin"] = sorted(b.keys())
                elif isinstance(b, str):
                    info["bin"] = [pj.get("name", "")]
                deps = pj.get("dependencies")
                if isinstance(deps, dict):
                    info["dependency_names"] = sorted(deps.keys())
                kw = pj.get("keywords")
                if isinstance(kw, list):
                    info["keywords"] = [str(x) for x in kw][:20]
            if "icon" in role:
                icons = [m for m in members if "/icons/" in m and m.endswith((".js", ".mjs", ".d.ts"))]
                stems = sorted({m.rsplit("/", 1)[-1].split(".")[0] for m in icons if m.rsplit("/", 1)[-1][0:1].isalpha()})
                if stems:
                    info["icon_module_count"] = len(stems)
                    info["sample_icon_names"] = stems[:12]
    except Exception as e:
        return info, f"read error: {e}"
    return info, None


def main():
    sources = []
    for rec in load_reg(EMB_REG, "packages"):
        if rec.get("status") == "STARTER_REUSE_SMOKED" and rec.get("local_mirror_path"):
            sources.append(("backend", rec["package_name"], rec))
    for rec in load_reg(UI_REG, "sources"):
        if rec.get("status") == "STARTER_REUSE_SMOKED" and rec.get("local_mirror_path"):
            sources.append(("ui", rec["component_name"], rec))

    entries, totals = [], {"subpath_exports": 0, "bin": 0, "icon_modules": 0}
    for lane, name, rec in sources:
        info, err = ({}, "dry-run") if DRY else extract(rec["local_mirror_path"], rec.get("role", ""))
        e = {"sub_data_id": f"subdata:{lane}:{name}", "status": "SUB_DATA_REFERENCE",
             "executable": False, "trusted_reuse_allowed": False,
             "lane": lane, "source_asset": name, "version": rec.get("version_or_commit"),
             "license": rec.get("license"), "source_mirror": rec.get("local_mirror_path"),
             "extraction": "static metadata from local mirror (offline); reference only",
             "data": info, "error": err}
        if not DRY and isinstance(info, dict):
            totals["subpath_exports"] += len(info.get("subpath_exports") or [])
            totals["bin"] += len(info.get("bin") or [])
            totals["icon_modules"] += (info.get("icon_module_count") or 0)
        entries.append(e)

    out = {"schema": "sub_data_index.v1", "mission": "SOVEREIGN_CODE_TREASURY_AND_UI_TREASURY_PILOT_V1",
           "built_by": "library/embassy/scripts/generate_sub_data_index.py",
           "built_at": datetime.datetime.now().isoformat(), "dry_run": DRY,
           "tier_for_all_entries": "SUB_DATA_REFERENCE", "trusted_reuse_allowed_global": False,
           "rules": ["sub-data entries are reference catalog material extracted statically from local mirrors",
                     "sub-data entries are NOT executable workflows and NOT trusted reuse",
                     "extraction is offline: reads only the pinned local tarballs, never the live registry"],
           "summary": {"sub_data_entries": len(entries), "extracted_subpath_exports": totals["subpath_exports"],
                       "extracted_bin_entries": totals["bin"], "extracted_icon_modules": totals["icon_modules"],
                       "TRUSTED_REUSE": 0},
           "entries": entries}
    if not DRY:
        json.dump(out, open(OUT, "w"), indent=2)
    print(json.dumps(out["summary"], indent=2))
    print(f"  wrote {OUT.relative_to(ROOT)}" if not DRY else "  (dry-run: nothing written)")


if __name__ == "__main__":
    main()
