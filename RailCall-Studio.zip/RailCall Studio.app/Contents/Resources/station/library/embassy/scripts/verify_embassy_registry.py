#!/usr/bin/env python3
"""Verify embassy_registry.json is internally honest. Exits nonzero on any violation.
Checks: required fields present; global + per-asset trusted_reuse_allowed are false; TRUSTED_REUSE==0;
QUARANTINE assets are NOT mirrored; STARTER assets have an existing mirror tarball + sha256; license_allowed
agrees with the allowlist; summary counts equal recomputed counts.
"""
import json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
REG = ROOT / "library" / "embassy" / "embassy_registry.json"
REQ = ["asset_id", "asset_type", "package_name", "version_or_commit", "license", "license_allowed",
       "status", "trusted_reuse_allowed", "promotion_status"]
errs, warns = [], []

if not REG.exists():
    print("FAIL: embassy_registry.json missing — run ingest_seed_packages.py")
    sys.exit(1)
d = json.load(open(REG))
allow = {x.upper() for x in d.get("permissive_allowlist", [])}
pkgs = d.get("packages", [])

if d.get("trusted_reuse_allowed_global") is not False:
    errs.append("global trusted_reuse_allowed_global is not false")

recount = {}
for r in pkgs:
    nm = r.get("package_name", "?")
    for f in REQ:
        if f not in r:
            errs.append(f"{nm}: missing field '{f}'")
    if r.get("trusted_reuse_allowed") is not False:
        errs.append(f"{nm}: trusted_reuse_allowed is not false")
    if r.get("promotion_status") not in (None, "NONE"):
        errs.append(f"{nm}: promotion_status must be NONE in pilot (got {r.get('promotion_status')})")
    st = r.get("status")
    recount[st] = recount.get(st, 0) + 1
    if st == "QUARANTINE":
        if r.get("local_mirror_path"):
            errs.append(f"{nm}: QUARANTINE must not be mirrored, but local_mirror_path is set")
        if r.get("license_allowed") is True:
            errs.append(f"{nm}: QUARANTINE but license_allowed=true")
    elif st in ("STARTER_REUSE", "STARTER_REUSE_SMOKED"):
        if r.get("license", "").upper() not in allow:
            errs.append(f"{nm}: STARTER but license '{r.get('license')}' not in allowlist")
        if not r.get("license_allowed"):
            errs.append(f"{nm}: STARTER but license_allowed is not true")
        mp = r.get("local_mirror_path")
        if not mp:
            errs.append(f"{nm}: STARTER but no local_mirror_path")
        elif not (ROOT / mp).exists():
            errs.append(f"{nm}: mirror tarball missing on disk: {mp}")
        if not str(r.get("archive_sha256", "")).startswith("sha256:"):
            errs.append(f"{nm}: STARTER but missing sha256")
        if st == "STARTER_REUSE_SMOKED":
            if r.get("smoke_test_result") != "PASS":
                errs.append(f"{nm}: SMOKED but smoke_test_result != PASS")
            if r.get("smoke_test_type") != "IMPORT_SMOKE":
                errs.append(f"{nm}: backend smoke_test_type must be IMPORT_SMOKE")
            if r.get("smoke_label") != "IMPORT_SMOKE_PASSED":
                errs.append(f"{nm}: SMOKED but smoke_label != IMPORT_SMOKE_PASSED")

if recount.get("TRUSTED_REUSE", 0) != 0 or d.get("summary", {}).get("TRUSTED_REUSE", 0) != 0:
    errs.append("TRUSTED_REUSE count is not 0")
STATUS_KEYS = {"REFERENCE_ONLY", "STARTER_REUSE", "STARTER_REUSE_SMOKED", "QUARANTINE"}
summ = {k: v for k, v in d.get("summary", {}).items() if k in STATUS_KEYS}
for k, v in summ.items():
    if recount.get(k, 0) != v:
        errs.append(f"summary[{k}]={v} != recomputed {recount.get(k,0)}")
# Grok-reconciliation aliases must agree with the tier counts
sm = d.get("summary", {})
if sm.get("BACKEND_IMPORT_SMOKED") != recount.get("STARTER_REUSE_SMOKED", 0):
    errs.append("summary.BACKEND_IMPORT_SMOKED != STARTER_REUSE_SMOKED count")
if sm.get("BACKEND_QUARANTINED") != recount.get("QUARANTINE", 0):
    errs.append("summary.BACKEND_QUARANTINED != QUARANTINE count")
if d.get("smoke_kind") != "IMPORT_SMOKE":
    errs.append("registry.smoke_kind must be IMPORT_SMOKE")

print(f"embassy_registry: {len(pkgs)} assets | recomputed {recount}")
for w in warns:
    print("  WARN:", w)
if errs:
    for e in errs:
        print("  FAIL:", e)
    print(f"VERIFY_EMBASSY: FAIL ({len(errs)} issues)")
    sys.exit(1)
print("VERIFY_EMBASSY: PASS")
