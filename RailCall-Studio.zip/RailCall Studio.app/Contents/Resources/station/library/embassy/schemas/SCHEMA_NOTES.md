# embassy schemas

The registry shape is declared inline via the `schema` key in each artifact (no separate schema files in the pilot):

- `embassy_registry.json` → `"schema": "embassy_registry.v1"`
- per-package receipts under `../receipts/*.receipt.json` use the same record shape as `packages[]`
- quarantine records under `../quarantine/*.quarantine.json` are the same record with `status: "QUARANTINE"` and `local_mirror_path: null`

Run `python3 library/embassy/scripts/verify_embassy_registry.py` to validate the registry against these invariants.
