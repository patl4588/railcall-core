#!/usr/bin/env node
/*
 * metercall-library inspection server — smallest read-only static server.
 *   node library/serve_library.cjs           # default 127.0.0.1:8745
 *   PORT=8746 node library/serve_library.cjs  # override port
 *
 * - Binds 127.0.0.1 only (no external exposure).
 * - GET/HEAD only (read-only; never writes / never modifies indexes).
 * - Serves the repo/worktree root so /library/ and the open links resolve.
 * - Rejects path traversal: any request that resolves OUTSIDE the repo root → 403,
 *   including symlink escapes (checked via realpath). Symlinks that stay inside the
 *   root (the library's workflow/primitive/receipt references) are allowed.
 * - No auth (local, read-only inspection). Does NOT auto-start — run it manually.
 */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const ROOT = path.resolve(__dirname, '..');                 // parent of library/ = repo/worktree root
const HOST = '127.0.0.1';
const PORT = Number(process.env.PORT || process.argv[2] || 8745);

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.cjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.txt': 'text/plain; charset=utf-8', '.md': 'text/plain; charset=utf-8',
};
const inRoot = (p) => p === ROOT || p.startsWith(ROOT + path.sep);
const JSONH = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' };

// Read-only JSON directory listing for the inspector tree. GET-only, path-traversal safe
// (resolves inside ROOT; symlinks that escape ROOT are rejected via realpath). Never writes.
function listDir(u, res) {
  const rel = (u.searchParams.get('dir') || '').replace(/^\/+/, '');
  const target = path.resolve(ROOT, '.', rel);
  if (!inRoot(target)) { res.writeHead(403, JSONH); return res.end('{"ok":false,"error":"forbidden"}'); }
  fs.realpath(target, (e0, real) => {
    if (e0 || !inRoot(real)) { res.writeHead(e0 ? 404 : 403, JSONH); return res.end(JSON.stringify({ ok: false, error: e0 ? 'not found' : 'outside root' })); }
    fs.stat(real, (e1, st) => {
      if (e1 || !st.isDirectory()) { res.writeHead(404, JSONH); return res.end(JSON.stringify({ ok: false, error: 'not a directory' })); }
      fs.readdir(real, { withFileTypes: true }, (e2, ents) => {
        if (e2) { res.writeHead(500, JSONH); return res.end(JSON.stringify({ ok: false, error: 'read error' })); }
        const LIMIT = 6000;
        const entries = ents.slice(0, LIMIT).map((d) => {
          let type = d.isDirectory() ? 'dir' : 'file', size = 0;
          try { const s = fs.statSync(path.join(real, d.name)); type = s.isDirectory() ? 'dir' : 'file'; size = s.size || 0; } catch { /* broken symlink */ }
          return { name: d.name, type, size };
        }).sort((a, b) => (a.type === b.type ? a.name.localeCompare(b.name) : a.type === 'dir' ? -1 : 1));
        res.writeHead(200, JSONH);
        res.end(JSON.stringify({ ok: true, dir: rel, count: ents.length, truncated: ents.length > LIMIT, entries }));
      });
    });
  });
}

const server = http.createServer((req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end('GET only'); }
  let u, pathname;
  try { u = new URL(req.url, `http://${HOST}`); pathname = decodeURIComponent(u.pathname); }
  catch { res.writeHead(400); return res.end('bad request'); }

  if (pathname === '/') { res.writeHead(302, { location: '/library/' }); return res.end(); }
  if (pathname === '/library/__ls') return listDir(u, res);

  const resolved = path.resolve(ROOT, '.' + pathname);
  if (!inRoot(resolved)) { res.writeHead(403); return res.end('403 forbidden — outside repo root'); }

  fs.stat(resolved, (err, st) => {
    if (err) { res.writeHead(404); return res.end('404 not found'); }
    let file = resolved;
    if (st.isDirectory()) {
      if (!pathname.endsWith('/')) { res.writeHead(302, { location: pathname + '/' }); return res.end(); }
      file = path.join(resolved, 'index.html');
      if (!fs.existsSync(file)) { res.writeHead(404); return res.end('404 — no index.html in directory'); }
    }
    fs.realpath(file, (e2, real) => {                          // defend against symlink escape
      if (e2 || !inRoot(real)) { res.writeHead(e2 ? 404 : 403); return res.end(e2 ? '404' : '403 forbidden — symlink escape'); }
      res.writeHead(200, { 'content-type': TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream', 'cache-control': 'no-store' });
      if (req.method === 'HEAD') return res.end();
      fs.createReadStream(file).pipe(res);
    });
  });
});

server.listen(PORT, HOST, () => {
  console.log(`metercall library inspection server (read-only) → http://${HOST}:${PORT}/library/`);
  console.log(`  UI Library     : http://${HOST}:${PORT}/library/ui/`);
  console.log(`  Module Library : http://${HOST}:${PORT}/library/modules/`);
  console.log(`  root=${ROOT} · GET-only · 127.0.0.1 · path-traversal blocked`);
});
