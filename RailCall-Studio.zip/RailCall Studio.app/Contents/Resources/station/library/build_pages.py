#!/usr/bin/env python3
"""Generate the local library inspection pages from the committed indexes.

Server-side render: counts are read from library/{manifest,ui/index,modules/index}.json
and baked into self-contained HTML — so the pages render via file:// with NO server
(and also work later when served at :8745). Relative links connect the 3 pages.

  python3 library/build_pages.py
"""
import json
from pathlib import Path

LIB = Path(__file__).resolve().parent
man = json.load(open(LIB / "manifest.json"))
ui = json.load(open(LIB / "ui" / "index.json"))
mod = json.load(open(LIB / "modules" / "index.json"))
tre = man.get("treasury", {})


def treasury_banner():
    rc = tre.get("reclassified", {})
    cells = [("STARTER_REUSE_SMOKED", tre.get("starter_reuse_smoked", 0)), ("SUB_DATA_REFERENCE", tre.get("sub_data_reference", 0)),
             ("COMBO_CANDIDATES", tre.get("combo_candidates_created", 0)), ("WORKFLOW_CANDIDATES", tre.get("workflow_candidates_created", 0)),
             ("TRUSTED_REUSE", tre.get("trusted_reuse_count", 0)), ("QUARANTINED·blocked", tre.get("quarantine_count", 0)),
             ("RECLASSIFIED", rc.get("assets", 0))]
    chips = "".join(f'<span style="display:inline-block;margin:3px 6px 0 0;padding:4px 10px;border-radius:8px;background:#13161f;border:1px solid #2c3142"><b style="color:#a78bfa">{v}</b> <span style="color:#9aa3b2;font-size:11px">{k}</span></span>' for k, v in cells)
    return ('<div style="margin:0 0 16px;padding:12px 14px;border:1px solid #3b2d63;background:rgba(124,92,255,.06);border-radius:11px">'
            '<div style="font-size:12px;color:#c4b5fd;font-weight:700;letter-spacing:.04em">SOVEREIGN CODE TREASURY — DISK TRUTH (STARTER tier, nothing trusted)</div>'
            f'<div style="margin-top:6px">{chips}</div></div>')

CSS = """<style>
:root{--v:#7C3AED;--bg:#0b0d12;--card:#13161f;--line:#222634;--fg:#e6e8ee;--mut:#9aa3b2}
*{box-sizing:border-box}body{margin:0;font-family:-apple-system,Segoe UI,Roboto,sans-serif;background:var(--bg);color:var(--fg);line-height:1.45}
a{color:var(--v);text-decoration:none}a:hover{text-decoration:underline}
header{padding:26px 30px;border-bottom:1px solid var(--line)}
h1{margin:0;font-size:22px}.sub{color:var(--mut);font-size:13px;margin-top:6px}
.wrap{padding:24px 30px;max-width:1100px}
.cards{display:grid;grid-template-columns:1fr 1fr;gap:18px}
@media(max-width:720px){.cards{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:22px;display:block;color:var(--fg)}
.card:hover{border-color:var(--v)}
.card h2{margin:0 0 6px;font-size:19px}
.big{font-size:38px;font-weight:800;color:var(--v);line-height:1}
.mini{color:var(--mut);font-size:12.5px;margin:10px 0 14px}
.badge{display:inline-block;font-size:11px;padding:2px 9px;border-radius:20px;background:#1d1430;color:#c4b5fd;border:1px solid #3b2d63;vertical-align:middle;margin-left:8px}
.row{display:flex;justify-content:space-between;gap:12px;border-bottom:1px solid var(--line);padding:11px 0;align-items:baseline}
.cat{font-size:15px;font-weight:600}.n{font-weight:800;color:var(--v);font-size:17px}
.path{font-family:ui-monospace,SFMono-Regular,monospace;font-size:11px;color:var(--mut);word-break:break-all}
.note{color:var(--mut);font-size:12px;margin-top:18px}
.list{margin:6px 0 0;padding:0;list-style:none;columns:2}
.list li{font-family:ui-monospace,monospace;font-size:12px;padding:2px 0}
</style>"""


def doc(title: str, body: str) -> str:
    return ("<!doctype html><html lang=en><head><meta charset=utf-8>"
            "<meta name=viewport content=\"width=device-width,initial-scale=1\">"
            f"<title>{title}</title>{CSS}</head><body>{body}</body></html>")


# ── library/index.html — two cards ──
uic = man["uiLibrary"]; modc = man["moduleLibrary"]
ui_total = sum(v for v in uic["counts"].values() if isinstance(v, int))
ui_mini = " · ".join(f"{k} {v}" for k, v in uic["counts"].items())
mod_mini = " · ".join(f"{k} {v}" for k, v in modc["counts"].items())
index_body = f"""
<header><h1>Metercall Local Library</h1>
<div class=sub>canonical root: <span class=path>{man['canonicalRoot']}</span> · indexed {man['indexedAt']}</div></header>
<div class=wrap><div class=cards>
  <a class=card href="ui/index.html">
    <h2>UI Library<span class=badge>{uic['status']}</span></h2>
    <div class=big>{ui_total}</div><div class=mini>{ui_mini}</div>
    <div class=path>{uic['path']}</div>
    <div class=mini>local link (when served): {uic['localUrl']}</div>
    <div style="margin-top:10px;color:var(--v);font-weight:600">Open UI Library →</div>
  </a>
  <a class=card href="modules/index.html">
    <h2>Module Library<span class=badge>{modc['status']}</span></h2>
    <div class=big>{modc['counts'].get('workflows',0)}</div><div class=mini>workflows · plus: {mod_mini}</div>
    <div class=path>{modc['path']}</div>
    <div class=mini>local link (when served): {modc['localUrl']}</div>
    <div style="margin-top:10px;color:var(--v);font-weight:600">Open Module Library →</div>
  </a>
</div>
<div class=note>Static inspection pages (data baked from the committed indexes). Open this file directly (file://) or serve <span class=path>metercall-site/</span> at :8745 for the permanent links above. Rebuild after re-indexing: <span class=path>python3 library/build_pages.py</span></div>
</div>"""
# NOTE: library/index.html is the INTERACTIVE inspector (hand-maintained, reads the JSON indexes
# at runtime — never needs regenerating). build_pages.py must NOT overwrite it. Static 2-card
# page disabled on purpose so the inspector survives every re-index / sync.
# (LIB / "index.html").write_text(doc("Metercall Local Library", index_body))


# ── library/ui/index.html ──
rows = []
for cat, c in ui["categories"].items():
    n = c.get("count", 0)
    extra = f"<div class=path>{c.get('source_path','')}</div>"
    if c.get("open_base"):
        extra += f"<div class=mini>open (when served): {c['open_base']}</div>"
    rows.append(f"<div class=row><div><span class=cat>{cat}</span>{extra}</div><span class=n>{n}</span></div>")
legos = "".join(f"<li><a href=\"{l['open']}\">{l['category']}/{l['file']}</a></li>" for l in ui.get("legos", []))
ui_body = f"""
<header><h1>UI Library</h1>
<div class=sub><a href="../index.html">← Metercall Local Library</a> · indexed {ui['indexed_at']} · {ui_total} items</div></header>
<div class=wrap>{treasury_banner()}{''.join(rows)}
<h2 style="font-size:15px;margin-top:24px">Components (legos) — {len(ui.get('legos',[]))}</h2>
<ul class=list>{legos}</ul>
<div class=note>Counts read from <span class=path>library/ui/index.json</span>. Deep "open" links activate when <span class=path>metercall-site/</span> is served at :8745.</div></div>"""
(LIB / "ui" / "index.html").write_text(doc("UI Library", ui_body))


# ── library/modules/index.html ──
mrows = []
for cat, c in mod["categories"].items():
    if cat == "combos":
        n = f"{c.get('candidates',0)}"; sub = f"validated {c.get('validated',0)}"
    elif cat == "sources":
        n = f"{c.get('module_library_modules',0)}"; sub = f"external repo (self-hosted) · nick branch: {c.get('nick_branch','')}"
    elif cat == "primitives":
        n = f"{c.get('py_files',0)}"; sub = "python primitives"
    else:
        n = f"{c.get('count', c.get('bundles',0))}"; sub = c.get('mode','')
    mrows.append(f"<div class=row><div><span class=cat>{cat}</span>"
                 f"<div class=path>{c.get('source_path','')}</div>"
                 f"<div class=mini>{sub} · {c.get('available_at','')}</div></div>"
                 f"<span class=n>{n}</span></div>")

# Staged packs — rendered SEPARATELY from canonical; NOT in the counts above.
st = mod.get("staging") or {}
staging_html = ""
if st.get("packs"):
    items = []
    for p in st["packs"]:
        labels = "".join(f'<span class=badge style="background:#3a1d1d;color:#fca5a5;border-color:#7f1d1d">{l}</span> ' for l in p.get("labels", []))
        links = [f'<a href="/{x}">{x.split("/")[-1]}</a>' for x in (p.get("modules", []) + p.get("ui", []))]
        if p.get("validation_receipt"): links.append(f'<a href="/{p["validation_receipt"]}">validation receipt</a>')
        if p.get("groq_audit_result"): links.append(f'<a href="/{p["groq_audit_result"]}">Groq audit result</a>')
        if p.get("promotion_hold_doc"): links.append(f'<a href="/{p["promotion_hold_doc"]}">PROMOTION HOLD doc</a>')
        items.append(
            '<div style="border:1px solid #7f1d1d;border-radius:10px;padding:14px;margin-top:10px;background:#1a1213">'
            f'<div style="font-weight:700;font-size:16px">{p.get("title", p["pack"])} '
            f'<span style="font-size:11px;color:#fca5a5">({len(p.get("modules", []))} modules · {len(p.get("ui", []))} ui)</span></div>'
            f'<div style="margin:8px 0">{labels}</div>'
            f'<div class=mini>files (open when served): {" · ".join(links)}</div></div>')
    staging_html = ('<h2 style="font-size:15px;margin-top:26px;color:#fca5a5">&#9888; Staging &mdash; NOT canonical (do not reuse; promotion held)</h2>'
                    f'<div class=mini>{st.get("note", "")}</div>' + "".join(items))

mod_body = f"""
<header><h1>Module Library <span class=badge style="background:#3a2d10;color:#fbbf24;border-color:#7f5d1d">LEGACY_REFERENCE_ONLY</span></h1>
<div class=sub><a href="../index.html">← Metercall Local Library</a> · indexed {mod['indexed_at']}</div></header>
<div class=wrap>{treasury_banner()}
<div style="margin:0 0 16px;padding:11px 14px;border:1px solid rgba(251,191,36,.4);background:rgba(251,191,36,.07);border-radius:11px;color:#fbe6b0;font-size:12.5px">
<b style="color:#fbbf24">DEPRECATED_COUNT_SOURCE / NOT_TRUSTED.</b> The counts below (workflows · combos · validated) are legacy symlink/index-derived numbers — <b>NOT active product inventory and NOT treasury truth</b>. Honest disk counts are in the treasury banner above. The product-facing combo source is the {tre.get('combo_candidates_created',0)} COMBO_CANDIDATE entries (0 workflows), not the legacy 5000-combo index.</div>
{''.join(mrows)}
<div class=note>Legacy counts read from <span class=path>library/modules/index.json</span> (reference only). Sources are referenced (symlink/copy/index), never moved. The Staging section below is <b>NOT</b> part of these counts.</div>
{staging_html}</div>"""
(LIB / "modules" / "index.html").write_text(doc("Module Library", mod_body))

print(json.dumps({"ok": True, "wrote": ["library/index.html", "library/ui/index.html", "library/modules/index.html"],
                  "ui_total": ui_total, "module_workflows": modc["counts"].get("workflows", 0),
                  "legos": len(ui.get("legos", []))}, indent=2))
