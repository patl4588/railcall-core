# Library-First Execution — core product rule

**This is serious. Not optional. Not polish. Not a doc preference.**
**If Groq/Kai does not use the library first, we do not have a product.**

> **Metercall is library-first, not imagination-first.**
> Metercall does not blindly generate — it checks the shelf, reuses governed modules,
> stages gaps, and leaves a receipt. **If Groq/Kai ignores the library, Metercall loses its moat.**

**Status:** RULE + audit criterion. The enforcement feature (intent classifier, shelf
search, drift block, staging→canonical promote) is **NOT built yet**. This document
defines the required behavior for Kai / Groq / Codex / Nick and the gate that audits it.

## The rule
Before Groq/Kai builds anything, it **must** check the local library shelf and either
**reuse** existing items or **explicitly prove there is no suitable match**.

## Canonical library paths (check FIRST)
- `library/manifest.json`
- `library/ui/index.json`
- `library/modules/index.json`
- `library/ui/`
- `library/modules/`
- `library/modules/workflows/`
- `library/modules/combos/`
- `library/modules/primitives/`
- `library/modules/packs/`
- `library/modules/receipts/`
- `library/modules/sources/`

## Required behavior
1. **Classify request intent.** User: "Build a simple CRM" → Intent: `simple_crm`.
2. **Search the library FIRST:** module index · workflow definitions · combo candidates ·
   validated combos · primitives · UI components/pages/sites/previews/examples.
3. **Report shelf matches BEFORE building.** "I found these library matches: CRM intake
   workflow · contact/customer primitive · dashboard UI page · receipt/safety pattern.
   I will reuse these first."
4. **If no match exists, say so clearly.** "No suitable library match found. Creating a staged candidate."
5. **New work goes to STAGING first, not canonical:** `library/staging/ui/` ·
   `library/staging/modules/` · `library/staging/receipts/`.
6. **Canonical promotion requires Patrick/audit approval.** Nothing new goes directly
   into the canonical library without review.
7. **Receipts must prove library use.** Every build receipt must include: user request ·
   classified intent · library indexes searched · shelf matches found · shelf items reused ·
   shelf items skipped · new staged items created (if any) · reason for building new instead of reusing.
8. **Drift guard.** If a matching library item exists and Groq/Kai tries to build from
   scratch → warn/block: *"Library match exists. Reuse required unless Patrick approves a custom build."*
9. **Audit rule.** Any future Groq/Kai build that does **not** show a library search result is an **automatic FAIL**.

## Fail condition (automatic fail)
- No library search
- No shelf-match report
- No reuse / skipped / new receipt
- Direct generation from scratch when a matching library item exists

## Scope / not-yet
Docs + rule + staging scaffold **only**. Do **not** build the enforcement (classifier,
search, drift block, promote flow) without an explicit, separately-scoped go. Library-lane
only — does not touch terminal/login, the Nick test branch, the real-terminal bridge, the
`module-library` repo, deploy, or `main`.
