#!/usr/bin/env python3
"""Governance gate for first-party TRUSTED_REUSE lego promotions. Exits nonzero on any violation.

No lego is trusted by a flag flip alone: every governed asset marked trusted_reuse_allowed=true must
have, on disk, the full proof chain — input_contract + output_contract + fixture + validate_execution.py
+ a validation_receipt with result=PASS, faults=0, and network_sockets_opened=0 — plus its source file
and a patrick_approval_gate field (PENDING is allowed; the gate must merely be declared, not silently absent).
"""
import json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
REG = ROOT / "library" / "promotions" / "governed_legos_registry.json"
errs = []

if not REG.exists():
    print("VERIFY_GOVERNED: PASS (no governed_legos_registry.json — 0 promotions)")
    sys.exit(0)
reg = json.load(open(REG))
assets = reg.get("governed_assets", [])

trusted_n = 0
for a in assets:
    mid = a.get("module_id", "?")
    if not a.get("trusted_reuse_allowed"):
        continue
    trusted_n += 1
    if a.get("governance_tier") != "TRUSTED_REUSE":
        errs.append(f"{mid}: trusted but governance_tier != TRUSTED_REUSE")
    if not a.get("patrick_approval_gate"):
        errs.append(f"{mid}: trusted but patrick_approval_gate not declared")
    src = a.get("source_file")
    if not src or not (ROOT / src).exists():
        errs.append(f"{mid}: source_file missing on disk: {src}")
    pc = a.get("proof_chain") or {}
    for key in ("input_contract", "output_contract", "fixture", "validator", "validation_receipt"):
        p = pc.get(key)
        if not p:
            errs.append(f"{mid}: proof_chain.{key} not declared")
        elif not (ROOT / p).exists():
            errs.append(f"{mid}: proof_chain.{key} missing on disk: {p}")
    rp = pc.get("validation_receipt")
    if rp and (ROOT / rp).exists():
        rc = json.load(open(ROOT / rp))
        if rc.get("result") != "PASS":
            errs.append(f"{mid}: validation_receipt result != PASS ({rc.get('result')})")
        if rc.get("faults") != 0:
            errs.append(f"{mid}: validation_receipt faults != 0 ({rc.get('faults')})")
        env = rc.get("execution_envelope") or {}
        if env.get("network_sockets_opened") not in (0,):
            errs.append(f"{mid}: receipt network_sockets_opened != 0 ({env.get('network_sockets_opened')})")
        if not str(rc.get("integrity_root", "")).startswith("sha256:"):
            errs.append(f"{mid}: receipt missing sha256 integrity_root")

print(f"governed_legos: {len(assets)} asset(s) | {trusted_n} trusted")
if errs:
    for e in errs:
        print("  FAIL:", e)
    print(f"VERIFY_GOVERNED: FAIL ({len(errs)} issues)")
    sys.exit(1)
print("VERIFY_GOVERNED: PASS")
