#!/usr/bin/env python3
"""Sovereign Code Treasury — reclassify existing Metercall-authored library assets into the new tier
vocabulary. This is a NON-DESTRUCTIVE classification MAP: it moves no files and promotes nothing (moving
the committed HTML legos/JSON would break serve_library.cjs + the inspector references). Each existing
asset is relabeled conservatively; trusted_reuse_allowed stays false for every entry.

Rule of thumb (per mission):
  combos -> COMBO_CANDIDATE / REFERENCE_ONLY · old workflow pointers -> REFERENCE_ONLY ·
  source catalogs -> DISCOVERY_REFERENCE · old receipts -> RECEIPT_REFERENCE ·
  sub-data -> SUB_DATA_REFERENCE · old UI legos -> STARTER_REUSE

  python3 library/ui/scripts/generate_reclassification_index.py [--dry-run]
"""
import json, sys, fnmatch, datetime, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "library" / "ui" / "metercall-legos" / "reclassification_index.json"
DRY = "--dry-run" in sys.argv

# (glob, new_tier, rationale). First match wins. Globs are relative to repo root.
RULES = [
    ("library/ui/legos.manifest.json", "STARTER_REUSE", "Metercall-authored UI legos manifest — first-party starter UI (contract-completeness tracked separately; not trusted)"),
    ("library/ui/README*", "REFERENCE_ONLY", "documentation for the legos"),
    ("library/*/index.html", "REFERENCE_ONLY", "inspector/index page, not a lego"),
    ("library/*/*.html", "STARTER_REUSE", "Metercall-authored UI lego markup (auth/calendar/charts/forms/inbox/kanban/kpis/maps/nav/payments/tables/ui) — first-party starter UI"),
    ("library/_core/*", "REFERENCE_ONLY", "first-party core util — reference, not a trusted module"),
    ("library/audits/**", "REFERENCE_ONLY", "audit / trust-map document — reference"),
    ("library/governance/**", "REFERENCE_ONLY", "governance rule document — reference"),
    ("library/modules/combos/*CANDIDATE*", "COMBO_CANDIDATE", "combo candidate set — candidate combinations, not workflows"),
    ("library/modules/combos/*WORKFLOW*", "REFERENCE_ONLY", "old 'validated workflow' index pointer — NOT a validated workflow under the new standard"),
    ("library/modules/combos/*", "REFERENCE_ONLY", "combo classification reference"),
    ("library/modules/sources/*", "DISCOVERY_REFERENCE", "source/discovery catalog — pointers, not trusted assets"),
    ("library/modules/receipts/*", "RECEIPT_REFERENCE", "historical receipt — reference, not current executable proof"),
    ("library/modules/primitives/*", "REFERENCE_ONLY", "workflow primitive pointer"),
    ("library/modules/packs/*", "REFERENCE_ONLY", "pack pointer"),
    ("library/modules/workflows/*", "REFERENCE_ONLY", "old workflow pointer"),
    ("library/staging/modules/*", "REFERENCE_ONLY", "staged module stub — not trusted, not promoted"),
    ("library/staging/receipts/*", "RECEIPT_REFERENCE", "staging receipt — reference"),
    ("library/staging/**", "REFERENCE_ONLY", "staging artifact"),
    ("library/promotions/**", "REFERENCE_ONLY", "promotion packet — proposed, not promoted in this pilot"),
]
# Exclude the NEW treasury folders this mission created (they have their own registries).
EXCLUDE = ["library/embassy/*", "library/ui/storage/*", "library/ui/quarantine/*",
           "library/ui/receipts/*", "library/ui/scripts/*", "library/ui/sources/*",
           "library/ui/metercall-legos/*", "library/ui/ui_registry.json",
           "library/ui/ui_component_index.json", "library/sub_data_index.json",
           "library/combo_candidates.json"]


def tracked_files():
    out = subprocess.run(["git", "ls-files", "library/"], cwd=str(ROOT), capture_output=True, text=True)
    return [l for l in out.stdout.splitlines() if l]


def match(path):
    for glob, tier, why in RULES:
        if fnmatch.fnmatch(path, glob):
            return tier, why
    return None, None


def main():
    entries, tier_counts, unmatched = [], {}, []
    for f in tracked_files():
        if any(fnmatch.fnmatch(f, e) for e in EXCLUDE):
            continue
        # only reclassify the asset buckets named in the rules; skip infra files at library/ root
        tier, why = match(f)
        if not tier:
            if "/" in f[len("library/"):]:  # nested but unmatched -> record as unmatched for transparency
                unmatched.append(f)
            continue
        entries.append({"path": f, "first_party": True, "new_tier": tier,
                        "trusted_reuse_allowed": False, "promotion_status": "NONE",
                        "exists": (ROOT / f).exists(), "rationale": why})
        tier_counts[tier] = tier_counts.get(tier, 0) + 1

    out = {"schema": "reclassification_index.v1", "mission": "SOVEREIGN_CODE_TREASURY_AND_UI_TREASURY_PILOT_V1",
           "built_by": "library/ui/scripts/generate_reclassification_index.py",
           "built_at": datetime.datetime.now().isoformat(), "dry_run": DRY,
           "non_destructive": True, "files_moved": 0, "promotions": 0, "trusted_reuse_allowed_global": False,
           "rules": ["existing Metercall-authored assets relabeled into the new tier vocabulary",
                     "NON-DESTRUCTIVE: no files moved, nothing promoted; this is a classification map only",
                     "every entry stays trusted_reuse_allowed=false; STARTER_REUSE here means first-party starter UI, not trusted",
                     "old 'validated workflow' indexes are REFERENCE_ONLY — not workflows under the new standard"],
           "summary": {"reclassified_assets": len(entries), "tier_counts": dict(sorted(tier_counts.items())),
                       "unmatched_nested_files": len(unmatched), "TRUSTED_REUSE": 0, "files_moved": 0},
           "unmatched_sample": unmatched[:20], "entries": entries}
    if not DRY:
        OUT.parent.mkdir(parents=True, exist_ok=True)
        json.dump(out, open(OUT, "w"), indent=2)
    print(json.dumps(out["summary"], indent=2))
    print(f"  wrote {OUT.relative_to(ROOT)}" if not DRY else "  (dry-run: nothing written)")


if __name__ == "__main__":
    main()
