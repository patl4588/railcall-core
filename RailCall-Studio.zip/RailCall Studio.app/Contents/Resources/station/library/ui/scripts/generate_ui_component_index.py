#!/usr/bin/env python3
"""Sovereign Code Treasury — UI component index generator (REAL).
Build a navigable catalog of the mirrored UI sources from ui_registry.json, grouped by role category.
Each index entry POINTS AT a real STARTER_REUSE_SMOKED source record — the index is a reference catalog,
not a set of trusted product features. Writes library/ui/ui_component_index.json.

  python3 library/ui/scripts/generate_ui_component_index.py [--dry-run]
"""
import json, sys, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
UI_REG = ROOT / "library" / "ui" / "ui_registry.json"
OUT = ROOT / "library" / "ui" / "ui_component_index.json"
DRY = "--dry-run" in sys.argv

CATEGORY = {
    "modal_primitive": "overlays", "menu_primitive": "overlays", "popover_primitive": "overlays",
    "tooltip_primitive": "overlays", "drawer": "overlays", "headless_primitives": "overlays",
    "tabs_primitive": "navigation", "accordion_primitive": "disclosure", "select_primitive": "inputs",
    "otp_input": "inputs", "form_state": "inputs", "date_picker": "inputs", "command_palette": "inputs",
    "icon_set": "iconography", "variant_styling_util": "styling", "class_merge_util": "styling",
    "positioning_engine": "engine", "data_table": "data_display", "charts": "data_display",
    "carousel": "data_display", "resizable_panels": "layout", "toast": "feedback",
}


def main():
    if not UI_REG.exists():
        print("ui_registry.json missing — run ingest_ui_sources.py first")
        return
    reg = json.load(open(UI_REG))
    cats = {}
    entries = []
    for s in reg.get("sources", []):
        if s.get("status") != "STARTER_REUSE_SMOKED":
            continue
        role = s.get("role", "")
        cat = CATEGORY.get(role, "other")
        e = {"component_id": f"uic:{s['component_name']}", "status": "REFERENCE",
             "trusted_reuse_allowed": False, "is_trusted_product_feature": False,
             "component_name": s["component_name"], "role": role, "category": cat,
             "license": s.get("license"), "version": s.get("version_or_commit"),
             "smoke_test_result": s.get("smoke_test_result"), "entry_resolved": s.get("smoke_entry_resolved"),
             "source_mirror": s.get("local_mirror_path"), "source_record": s.get("asset_id"),
             "note": "reference catalog entry pointing at a STARTER_REUSE_SMOKED mirror; NOT a trusted product feature"}
        entries.append(e)
        cats.setdefault(cat, []).append(s["component_name"])

    out = {"schema": "ui_component_index.v1", "mission": "SOVEREIGN_CODE_TREASURY_AND_UI_TREASURY_PILOT_V1",
           "built_by": "library/ui/scripts/generate_ui_component_index.py",
           "built_at": datetime.datetime.now().isoformat(), "dry_run": DRY,
           "trusted_reuse_allowed_global": False,
           "rules": ["index entries are reference catalog pointers to mirrored UI sources",
                     "mirrored UI components are NOT trusted product features until wrapped/contracted/validated/receipted/approved",
                     "catalog reflects only STARTER_REUSE_SMOKED sources (license-allowed + entry resolved on disk)"],
           "summary": {"indexed_components": len(entries), "categories": {k: len(v) for k, v in sorted(cats.items())},
                       "TRUSTED_REUSE": 0, "trusted_product_features": 0},
           "categories": {k: sorted(v) for k, v in sorted(cats.items())},
           "components": entries}
    if not DRY:
        json.dump(out, open(OUT, "w"), indent=2)
    print(json.dumps(out["summary"], indent=2))
    print(f"  wrote {OUT.relative_to(ROOT)}" if not DRY else "  (dry-run: nothing written)")


if __name__ == "__main__":
    main()
