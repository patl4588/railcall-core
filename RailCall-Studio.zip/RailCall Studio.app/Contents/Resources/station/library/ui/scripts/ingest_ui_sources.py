#!/usr/bin/env python3
"""Sovereign Code Treasury — UI source ingester (REAL).
Screen each UI seed package's license LIVE from npm against the permissive allowlist; mirror permissive
tarballs locally with a sha256 + exact version pin. UI smoke = the package's declared entry point
(module / main / exports['.']) resolves to a real file on disk after a clean install (rendering deferred,
R0_PREVIEW_ONLY). Copyleft / compound-non-permissive / custom / commercial / unknown -> QUARANTINE
(NOT mirrored). Writes library/ui/ui_registry.json + per-source receipts. TRUSTED_REUSE stays 0;
trusted_reuse_allowed=false on every asset.

  python3 library/ui/scripts/ingest_ui_sources.py [--dry-run]
"""
import json, os, sys, hashlib, datetime, shutil, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
UI = ROOT / "library" / "ui"
STORAGE, QUAR, RECE = UI / "storage", UI / "quarantine", UI / "receipts"
for d in (STORAGE, QUAR, RECE):
    d.mkdir(parents=True, exist_ok=True)
DRY = "--dry-run" in sys.argv

seed = json.load(open(UI / "ui_seed_sources.json"))
ALLOW = {x.upper() for x in seed.get("permissive_allowlist", [])}


def npm(args):
    return subprocess.run(["npm"] + args, capture_output=True, text=True)


def norm_license(lic):
    if isinstance(lic, dict):
        return lic.get("type", "UNKNOWN")
    return lic or "UNKNOWN"


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return "sha256:" + h.hexdigest()


def safe(name):
    return name.replace("@", "").replace("/", "__")


def entry_candidates(pj):
    """Collect declared entry-point relative paths from a package.json (module/main/exports['.'])."""
    out = []
    for k in ("module", "main"):
        if isinstance(pj.get(k), str):
            out.append(pj[k])
    exp = pj.get("exports")
    dot = None
    if isinstance(exp, str):
        dot = exp
    elif isinstance(exp, dict):
        dot = exp.get(".", exp)  # use "." subpath if present, else top-level conditions
    def harvest(v):
        if isinstance(v, str):
            out.append(v)
        elif isinstance(v, dict):
            for cond in ("import", "module", "browser", "require", "default", "node"):
                if cond in v:
                    harvest(v[cond])
    if dot is not None:
        harvest(dot)
    # normalize "./x" -> "x"
    return [p[2:] if p.startswith("./") else p for p in out if isinstance(p, str)]


records, to_install = [], []
for c in seed["candidates"]:
    name, ver, role = c["name"], c.get("version", "latest"), c.get("role", "")
    r = npm(["view", f"{name}@{ver}", "version", "license", "--json"])
    if r.returncode != 0:
        rec = {"asset_id": f"ui:{name}", "asset_type": "ui_component_source", "component_name": name,
               "role": role, "version_or_commit": ver, "license": "UNKNOWN", "license_allowed": False,
               "status": "QUARANTINE", "status_reason": "npm view failed (not found/network)",
               "trusted_reuse_allowed": False, "promotion_status": "NONE", "smoke_test_result": "n/a"}
        json.dump(rec, open(QUAR / f"{safe(name)}.quarantine.json", "w"), indent=2)
        records.append(rec)
        continue
    try:
        meta = json.loads(r.stdout)
    except Exception:
        meta = {}
    license = norm_license(meta.get("license"))
    version = meta.get("version", ver)
    allowed = license.upper() in ALLOW
    rec = {"asset_id": f"ui:{name}@{version}", "asset_type": "ui_component_source", "component_name": name,
           "role": role, "source": "npm", "version_or_commit": version,
           "source_url": f"https://www.npmjs.com/package/{name}/v/{version}",
           "license": license, "license_allowed": allowed,
           "copyright_notice_present": None, "notice_file_present": None,
           "local_mirror_path": None, "archive_sha256": None,
           "ingested_at": datetime.datetime.now().isoformat(), "update_policy": "static",
           "promotion_status": "NONE", "trusted_reuse_allowed": False,
           "smoke_test_type": "ENTRY_RESOLUTION_SMOKE",
           "smoke_test_command": "resolve declared entry (module/main/exports['.']) to a file on disk; NOT a DOM/headless render test",
           "smoke_test_result": "n/a",
           "smoke_label": "ENTRY_RESOLUTION_SMOKE_NOT_RUN",
           "attribution": f"third-party '{name}' (c) its authors, {license} — mirrored locally, NOT authored or owned by Metercall"}
    if not allowed:
        reason = f"license '{license}' not in permissive allowlist (copyleft/compound/custom/commercial/unknown) — NOT mirrored"
        rec.update({"status": "QUARANTINE", "status_reason": reason, "quarantine_reason": reason,
                    "license_failure": True, "local_mirror_path": None, "archive_sha256": None,
                    "smoke_test_result": "n/a", "smoke_label": "QUARANTINED_NOT_SMOKED"})
        json.dump(rec, open(QUAR / f"{safe(name)}.quarantine.json", "w"), indent=2)
        records.append(rec)
        continue
    if DRY:
        rec.update({"status": "STARTER_REUSE", "status_reason": "dry-run: license allowed; would mirror"})
        records.append(rec)
        continue
    pkgdir = STORAGE / f"{safe(name)}@{version}"
    pkgdir.mkdir(parents=True, exist_ok=True)
    pr = npm(["pack", f"{name}@{version}", "--pack-destination", str(pkgdir), "--json"])
    if pr.returncode != 0:
        rec.update({"status": "QUARANTINE", "status_reason": "npm pack failed", "quarantine_reason": "npm pack failed",
                    "local_mirror_path": None, "smoke_label": "QUARANTINED_NOT_SMOKED"})
        json.dump(rec, open(QUAR / f"{safe(name)}.quarantine.json", "w"), indent=2)
        records.append(rec)
        continue
    try:
        fn = json.loads(pr.stdout)[0]["filename"]
    except Exception:
        fn = None
    tgz = (pkgdir / fn) if fn else next(iter(pkgdir.glob("*.tgz")), None)
    rec.update({"status": "STARTER_REUSE", "status_reason": "mirrored; license allowed; sha256 + exact version pinned; license/notice preserved in tarball",
                "local_mirror_path": str(tgz.relative_to(ROOT)) if tgz else None,
                "archive_sha256": sha256_file(tgz) if tgz else None,
                "copyright_notice_present": True, "notice_file_present": True})
    records.append(rec)
    to_install.append(f"{name}@{version}")

if to_install and not DRY:
    smoke = UI / ".smoke_env"
    smoke.mkdir(exist_ok=True)
    (smoke / "package.json").write_text('{"name":"ui-smoke","private":true}\n')
    # install package files only; we never execute them, only check declared entry files exist on disk
    subprocess.run(["npm", "install", *to_install, "--prefix", str(smoke),
                    "--no-audit", "--no-fund", "--no-save", "--ignore-scripts", "--legacy-peer-deps"],
                   capture_output=True, text=True)
    nm = smoke / "node_modules"
    for rec in records:
        if rec.get("status") != "STARTER_REUSE":
            continue
        name = rec["component_name"]
        pjp = nm / name / "package.json"
        if not pjp.exists():
            rec["smoke_test_result"] = "FAIL"
            rec["smoke_error"] = "package not present after install"
            continue
        try:
            pj = json.loads(pjp.read_text())
        except Exception:
            pj = {}
        cands = entry_candidates(pj)
        resolved = next((c for c in cands if (nm / name / c).exists()), None)
        if resolved:
            rec["status"] = "STARTER_REUSE_SMOKED"
            rec["smoke_test_result"] = "PASS"
            rec["smoke_label"] = "ENTRY_RESOLUTION_SMOKE_PASSED"
            rec["smoke_entry_resolved"] = resolved
        else:
            rec["smoke_test_result"] = "FAIL"
            rec["smoke_label"] = "ENTRY_RESOLUTION_SMOKE_FAILED"
            rec["smoke_error"] = f"no declared entry resolved on disk (checked: {cands[:4]})"  # stays STARTER_REUSE
    shutil.rmtree(smoke, ignore_errors=True)

counts = {t: sum(1 for r in records if r.get("status") == t) for t in ["REFERENCE_ONLY", "STARTER_REUSE", "STARTER_REUSE_SMOKED", "QUARANTINE"]}
counts["TRUSTED_REUSE"] = 0
# Grok reconciliation: surface UI-specific, unambiguous counts + the exact smoke kind (entry resolution, NOT DOM render).
counts["UI_ENTRY_RESOLUTION_SMOKED"] = counts["STARTER_REUSE_SMOKED"]
counts["UI_QUARANTINED"] = counts["QUARANTINE"]
registry = {"schema": "ui_registry.v1", "mission": "SOVEREIGN_CODE_TREASURY_AND_UI_TREASURY_PILOT_V1",
            "built_by": "library/ui/scripts/ingest_ui_sources.py", "built_at": datetime.datetime.now().isoformat(),
            "permissive_allowlist": sorted(ALLOW), "trusted_reuse_allowed_global": False,
            "smoke_kind": "ENTRY_RESOLUTION_SMOKE",
            "smoke_kind_note": "UI smoke verifies the declared entry point (module/main/exports['.']) resolves to a real file on disk. It is NOT a DOM/headless render test. A component passing here is ENTRY_RESOLUTION_SMOKE_PASSED, not render-verified.",
            "rules": ["STARTER tier only; no TRUSTED_REUSE without a Metercall wrapper + contracts + fixture + validation + receipt + Patrick approval",
                      "mirrored UI sources are third-party, NOT owned by Metercall (license/notice preserved in tarball)",
                      "UI smoke = ENTRY_RESOLUTION_SMOKE (declared entry resolves on disk); DOM/render verification is deferred (R0_PREVIEW_ONLY)",
                      "license screen is conservative: copyleft/compound/custom/commercial/unknown -> QUARANTINE; covers the mirrored package, not the full transitive graph",
                      "mirrored UI components are NOT trusted product features until wrapped, contracted, validated, receipted, and approved",
                      "every QUARANTINE source has local_mirror_path=null + a quarantine_reason and is NOT mirrored"],
            "summary": counts, "sources": records}
json.dump(registry, open(UI / "ui_registry.json", "w"), indent=2)
for r in records:
    json.dump(r, open(RECE / f"{safe(r['component_name'])}.receipt.json", "w"), indent=2)
print(json.dumps(counts, indent=2))
for r in records:
    print(f"  {r.get('status', '?'):22} {r['component_name']}@{r.get('version_or_commit', '?')} [{r.get('license', '?')}] smoke={r.get('smoke_test_result', '-')}")
