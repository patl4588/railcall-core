# ui schemas

The registry/index shapes are declared inline via the `schema` key in each artifact (no separate schema files in the pilot):

- `ui_registry.json` → `"schema": "ui_registry.v1"`
- `ui_component_index.json` → `"schema": "ui_component_index.v1"`
- `metercall-legos/reclassification_index.json` → `"schema": "reclassification_index.v1"`
- per-source receipts under `../receipts/*.receipt.json` use the same record shape as `sources[]`
- quarantine records under `../quarantine/*.quarantine.json` are the same record with `status: "QUARANTINE"` and `local_mirror_path: null`

Run `python3 library/ui/scripts/verify_ui_registry.py` to validate the registry against these invariants.
