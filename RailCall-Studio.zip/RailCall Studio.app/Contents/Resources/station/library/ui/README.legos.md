# MeterCall Total Library

Pre-built MC-ID-wrapped Legos. The Builder/Assembler picks the right Lego for a user request and writes only minimal bridge code.

## Categories
- `tables/` — data tables, KPI grids, scorecards
- `forms/` — input forms, multi-step flows, validation patterns
- `charts/` — line/bar/area, sparklines, gauges
- `kanban/` — board layouts, drag-drop columns
- `inbox/` — message lists, threads, notification feeds
- `calendar/` — month/week/day views, event tiles
- `payments/` — checkout flows, pricing tables, invoices
- `auth/` — login/signup, SSO, password reset
- `maps/` — locations, routes, region heatmaps
- `kpis/` — single-metric stat cards (vs `tables/power-grid` which is multi-metric)
- `nav/` — sidebars, topbars, breadcrumbs
- `empty-states/` — zero-data screens with primary CTA

## Lego format
Each Lego is one self-contained `.html` file with inline CSS + JS. No external deps. Must:
- Wrap root in `<div data-mcid="lego-<slug>" data-version="x.y.z">`
- Stable class selectors that `kaiAdjust` can target
- Idempotent `window.LEGO_<name>.mount(target, opts)` API
- Document inputs/outputs/events at top of file

See `tables/power-grid.html` for the canonical example.

## Manifest
`manifest.json` indexes every Lego with searchable tags. Assembler queries this to find candidates for a user request.

## Status
**v0.1.0 — Infrastructure only.** One example Lego seeded. Not yet wired into the Builder. Pivoting the flywheel to seed Legos here is the next step (gated on Pat's call).
