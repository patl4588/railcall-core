# Library sync — one shared library, both push, auto-updates every 5 minutes

Pat + Nick push to the **same** branch; each machine pulls + re-indexes every 5 minutes, so the
local inspector is always fresh. No manual rebuild.

## The model
- **Shared branch:** `library-organization-v0` on `patl4588/metercall-site` (private). Both push here.
- **Modules** sync separately and already auto-pull: `scripts/auto_pull_module_library.sh` pulls the
  self-hosted `module-library` every 5 min (Nick pushes modules there). Re-indexing picks them up.
- **Derived stays local:** the JSON indexes and the ~9.3M external catalogs are gitignored and
  rebuilt locally — never pushed, so pushes never conflict and the repo stays small.
- **The inspector** (`library/index.html`) is hand-maintained and reads the JSON at runtime; it is
  not regenerated (`build_pages.py` no longer writes it).

## One-time setup (each machine)
```
# dedicated checkout of the library branch (NOT your main metercall-site checkout)
git clone git@github.com:patl4588/metercall-site.git ~/metercall-site-library
cd ~/metercall-site-library && git checkout library-organization-v0

# build the index once, then serve it
python3 library/build_central_library.py
node library/serve_library.cjs            # → http://localhost:8745/library/

# add the 5-min sync cron (rebuilds after each pull)
( crontab -l 2>/dev/null; \
  echo "*/5 * * * * METERCALL_SITE=$HOME/metercall-site-library $HOME/metercall-site-library/library/sync_library.sh >> /tmp/metercall-library-sync.log 2>&1" \
) | crontab -
```

## Daily use
- UI / library / inspector changes → `git add … && git commit && git push` to `library-organization-v0`.
- New modules → push to the self-hosted `module-library` (auto-pulled).
- Every machine's inspector refreshes within 5 minutes.

## Notes
- A fresh clone has no indexes until the first `build_central_library.py` (the cron handles it after setup).
- Don't run the cron against your *main* metercall-site checkout — automation keeps that on `main`.
  Use a dedicated checkout/worktree on `library-organization-v0`.
