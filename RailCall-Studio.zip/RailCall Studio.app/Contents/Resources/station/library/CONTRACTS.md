# Lego Contracts v0.1

Standard event names + input shapes every Lego MUST follow. This is what makes assembly cheap — when contracts match, the Assembler auto-wires with zero bridge code.

## Why contracts matter

If every list-style Lego emits `lego:select` with `{id, label, data}`, and every detail-style Lego accepts `selected: {id, label, data}`, the Assembler matches them by name and wires them automatically. **No bridge code, no LLM call, no bug surface.**

The bridge becomes a one-line subscription, not a generative AI task.

## Canonical events (emit on the host element, `bubbles: true`)

| Event | When | Detail shape |
|---|---|---|
| `lego:select` | User picked a row / item / option | `{id: string, label: string, data: any}` |
| `lego:change` | User edited a value (form, slider, toggle) | `{field: string, value: any, prev: any}` |
| `lego:submit` | User completed an action that needs commit (save, send) | `{values: object}` |
| `lego:delete` | User triggered a destructive action | `{id: string, data: any}` |
| `lego:cancel` | User backed out of a flow | `{}` |
| `lego:error` | Lego failed internally (network, validation, etc.) | `{message: string, kind: string}` |
| `lego:loading` | Lego started/stopped a long async operation | `{loading: boolean}` |

## Canonical input shapes (mount opts)

| Input | Type | Use |
|---|---|---|
| `data` | `any[] \| object` | The primary payload to render |
| `selected` | `{id, label, data}` | Pre-selected item from upstream Lego |
| `value` | `any` | Pre-filled form value |
| `error` | `string \| null` | Render an error state |
| `loading` | `boolean` | Render a loading state |
| `theme` | `'light' \| 'dark'` | Override default light theme |

## Required mount API

Every Lego exposes:

```js
window.LEGO_<slug> = {
  version: '1.0.0',
  mount(target, opts): RootElement,    // returns root for cleanup
  unmount?(target): void                // optional
};
```

`target` is a DOM element OR a CSS selector. `opts` follows the canonical input shapes above when applicable.

## Required root element

```html
<div data-mcid="lego-<slug>" data-version="<x.y.z>" class="lego-<slug>">
  ...
</div>
```

## Sensitive data

Legos that need OAuth tokens or platform secrets MUST declare in manifest:
- `requires_oauth: ['shopify' | 'notion' | 'google' | ...]` — OAuth-with-PKCE flow, token in `MC.get('oauth.<provider>')`
- `requires_proxy: ['stripe' | 'email' | ...]` — server proxy at `api.metercall.ai/proxy/<service>`, never expose secrets to the browser

The Assembler runs the auth flow before mount if credentials missing.

## Cross-Lego shared state

For things that span multiple Legos (current user, current workspace, theme, oauth tokens), use `window.MC` (see `_core/mc-state.js`). Don't invent your own globals.

```js
MC.set('user', { id: 'pat', name: 'Patrick' });
MC.get('user');
MC.on('user', user => console.log('user changed', user));
```

---

**When in doubt: pick a canonical event/input name. Don't invent a new one without updating this file first.**
