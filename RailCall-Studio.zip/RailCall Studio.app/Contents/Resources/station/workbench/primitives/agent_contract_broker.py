"""
agent_contract_broker.py — Multi-agent ingestion + contract registration

Pat directive 2026-06-30 — "establishes the entry point for the autonomous
micro-economy: schema, deduplicated ingestion layer, contract registration."

Public API:

    new_contract_id() -> str         # ct_<ms-epoch>_<urlsafe11>
    new_bid_id() -> str              # bd_<ms-epoch>_<urlsafe11>

    ingest_bid(payload, idempotency_key, db, saga=None,
               margin_threshold=0.12) -> dict
        Idempotency check → threshold evaluation → ledger write.
        Returns one of:
            {"outcome": "DUPLICATE_DROPPED", ...}
            {"outcome": "BID_REJECTED", "reason": "...", ...}
            {"outcome": "THRESHOLD_VALIDATED", "bid_id": "...", "contract_id": "..."}
        Raises only on unexpected DB-layer faults (handled by the saga
        context manager upstream).

The broker reuses:
    primitives/sagalog.py            — for the wrapping context manager
    primitives/conditional_branch.py — for the threshold decision
    Postgres tables 004-sagalogs.sql + 006-agent-economy.sql

The HTTP endpoint that calls this lives in studio_server.py:/api/agent_bid
(loopback-only; the "open API" wording in Pat's spec is the design intent,
but going public requires auth + rate-limit which we have NOT yet built).
"""

import hashlib
import json
import os
import secrets
import time
from typing import Any, Dict, Optional

from .conditional_branch import branch, GREATER_OR_EQUAL


# --------------------------- model tier classification ------------------
# Same allow-list as workbench/compose_engine.py + studio_server.py — kept
# explicit so an attacker who swaps GROQ_MODEL to an unknown value can't
# stealth-classify as PRIMARY. See PITCH_KIT_AI_SAFETY_MANIFESTO.md.
_PRIMARY_MODELS = {
    "llama-3.3-70b-versatile",
    "openai/gpt-oss-120b",
    "qwen/qwen3-32b",
}
_FALLBACK_MODELS = {
    "meta-llama/llama-4-scout-17b-16e-instruct",
    "llama-3.1-8b-instant",
    "openai/gpt-oss-20b",
}


def _classify_tier(model_name: str) -> str:
    if model_name in _PRIMARY_MODELS:
        return "PRIMARY_REASONER"
    if model_name in _FALLBACK_MODELS:
        return "FALLBACK_LOW_FIDELITY"
    return "UNKNOWN_DEFAULTED_FALLBACK"


def _current_composer_model() -> Dict[str, Any]:
    """Reads GROQ_MODEL just like compose_engine does. Defaults to
    UNKNOWN_DEFAULTED_FALLBACK when unset — safer to over-flag."""
    name = os.environ.get("GROQ_MODEL", "")
    tier = _classify_tier(name) if name else "UNKNOWN_DEFAULTED_FALLBACK"
    return {"name": name or "unset", "tier": tier}


# --------------------------- id minting ----------------------------------

def _sortable_id(prefix: str) -> str:
    ts = int(time.time() * 1000)
    rnd = secrets.token_urlsafe(8)[:11]
    return f"{prefix}_{ts:013d}_{rnd}"


def new_contract_id() -> str:
    return _sortable_id("ct")


def new_bid_id() -> str:
    return _sortable_id("bd")


# --------------------------- the broker ----------------------------------

class BidIngestError(RuntimeError):
    """Raised when the incoming payload structure is unusable. Saga
    compensation is NOT triggered — this is a client error, not a
    runtime fault."""
    pass


_REQUIRED_BID_FIELDS = ("buying_agent_id", "selling_agent_id", "resource_type",
                        "bid_amount", "max_latency_tolerance")

_RESOURCE_TYPES = {"compute", "storage", "logistics", "inference", "bandwidth"}


def _validate_payload(payload: Dict[str, Any]) -> None:
    if not isinstance(payload, dict):
        raise BidIngestError(f"payload must be a dict, got {type(payload).__name__}")
    missing = [f for f in _REQUIRED_BID_FIELDS if payload.get(f) is None]
    if missing:
        raise BidIngestError(f"payload missing required fields: {missing}")
    if payload["resource_type"] not in _RESOURCE_TYPES:
        raise BidIngestError(
            f"resource_type {payload['resource_type']!r} not in {sorted(_RESOURCE_TYPES)}")
    if float(payload["bid_amount"]) <= 0:
        raise BidIngestError("bid_amount must be > 0 (enforced by SQL CHECK too)")
    if int(payload["max_latency_tolerance"]) <= 0:
        raise BidIngestError("max_latency_tolerance must be > 0 (ms)")


def _check_idempotency(idempotency_key: str, db: Any) -> Optional[str]:
    """Returns 'duplicate' if the key has been seen in the last 24h.
    Otherwise writes a fresh lock and returns None."""
    if not idempotency_key:
        raise BidIngestError("idempotency_key header is required")
    cur = db.cursor()
    cur.execute(
        "SELECT event_id FROM idempotent_locks WHERE event_id = %s "
        "AND expires_at > now()",
        (idempotency_key,),
    )
    if cur.fetchone() is not None:
        return "duplicate"
    # Insert with 24h expiry. Use parameterized arithmetic — no SQL injection.
    cur.execute(
        "INSERT INTO idempotent_locks (event_id, source, saga_id, expires_at) "
        "VALUES (%s, %s, %s, now() + interval '24 hours')",
        (idempotency_key, "agent_contract_broker", None),
    )
    db.commit()
    return None


def _release_idempotency(idempotency_key: str, db: Any) -> None:
    """Used on threshold rejection so the rejected agent can immediately
    retry with a corrected bid."""
    try:
        cur = db.cursor()
        cur.execute("DELETE FROM idempotent_locks WHERE event_id = %s",
                    (idempotency_key,))
        db.commit()
    except Exception:
        pass


def _fetch_cost_baseline(resource_type: str, db: Any) -> Optional[float]:
    """Reads the current internal cost per unit for the given resource.
    Returns None if no baseline exists (caller should treat as unknown
    cost — which we map to a hard reject, not a permissive accept)."""
    cur = db.cursor()
    cur.execute("SELECT cost_per_unit FROM resource_cost_baselines "
                "WHERE resource_type = %s", (resource_type,))
    row = cur.fetchone()
    return float(row[0]) if row else None


def _evaluate_threshold(bid_amount: float, cost_baseline: float,
                        margin_threshold: float, saga: Any) -> Dict[str, Any]:
    """Pat directive §3: bid_amount must exceed cost_baseline by at least
    margin_threshold (default 12%). Routes through conditional_branch so
    the decision is auto-logged into the saga's history."""
    minimum_acceptable = cost_baseline * (1 + margin_threshold)
    return branch(
        value=bid_amount,
        op=GREATER_OR_EQUAL,
        threshold=minimum_acceptable,
        saga=saga,
        label=f"threshold_check_{margin_threshold*100:.0f}pct",
    )


def _canonical_payload_hash(payload: Dict[str, Any], bid_id: str,
                            contract_id: str) -> str:
    """Deterministic hash over the bid payload. Same canonical-bytes
    pattern as compose_engine's integrity_root (sort_keys, tight
    separators, UTF-8). An auditor can recompute by hand."""
    canonical = json.dumps(
        {"bid_id": bid_id, "contract_id": contract_id, "payload": payload},
        sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _sign_transaction(bid_id: str, contract_id: str, payload: Dict[str, Any],
                      db: Any) -> Dict[str, Any]:
    """Pat directive (attestation now): every accepted bid gets a signature
    stamped with the model tier that processed it. FALLBACK tier produces
    NO signature row and the broker rejects the bid upstream.

    Reuses the same ed25519 signer compose_engine uses for receipt
    signatures, so an auditor's verify chain is identical to the workflow
    receipt chain.
    """
    model = _current_composer_model()
    if model["tier"] != "PRIMARY_REASONER":
        # No signature. Caller's upstream check should already prevent us
        # from reaching here, but defense in depth.
        return {"refused_signing": True, "model_tier": model["tier"]}

    payload_hash = _canonical_payload_hash(payload, bid_id, contract_id)

    # Reuse compose_engine's signer if available — otherwise fall back to a
    # marker that the row was written but un-signed (auditor must investigate).
    sig_value = None
    try:
        import railcall_signing as _sg  # same module compose_engine imports
        signed = _sg.sign_block(payload_hash)
        if signed:
            sig_value = signed.get("sig")
    except Exception:
        pass
    if not sig_value:
        sig_value = "UNSIGNED_SIGNER_UNAVAILABLE"

    sig_id = "sig_" + str(int(time.time() * 1000)) + "_" + secrets.token_urlsafe(8)[:11]

    cur = db.cursor()
    cur.execute(
        """
        INSERT INTO agent_transaction_signatures
            (signature_id, bid_id, contract_id, model_name, model_tier,
             fallback_engaged, payload_hash, signature_alg, signature_value)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """,
        (sig_id, bid_id, contract_id, model["name"], model["tier"],
         False, payload_hash, "ed25519", sig_value),
    )
    db.commit()
    return {
        "signature_id": sig_id,
        "model_name": model["name"],
        "model_tier": model["tier"],
        "fallback_engaged": False,
        "payload_hash": payload_hash,
        "signature_alg": "ed25519",
        "signature_value": sig_value,
    }


def _write_bid(payload: Dict[str, Any], idempotency_key: str,
               contract_id: str, bid_id: str, state: str, db: Any,
               rejection_reason: Optional[str] = None) -> None:
    cur = db.cursor()
    # First make sure the contract exists
    cur.execute(
        """
        INSERT INTO agent_contracts
            (contract_id, buying_agent_id, selling_agent_id, resource_type,
             contract_amount, escrow_status, threshold_validated)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (contract_id) DO NOTHING
        """,
        (contract_id, payload["buying_agent_id"], payload["selling_agent_id"],
         payload["resource_type"], float(payload["bid_amount"]),
         "OPEN", state == "THRESHOLD_VALIDATED"),
    )
    cur.execute(
        """
        INSERT INTO resource_bids
            (bid_id, contract_id, resource_type, bid_amount,
             max_latency_tolerance, idempotency_key, bid_state, rejection_reason)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """,
        (bid_id, contract_id, payload["resource_type"],
         float(payload["bid_amount"]),
         int(payload["max_latency_tolerance"]),
         idempotency_key, state, rejection_reason),
    )
    db.commit()


# --------------------------- top-level entry ----------------------------

def ingest_bid(payload: Dict[str, Any], idempotency_key: str, db: Any,
               saga: Optional[Any] = None,
               margin_threshold: float = 0.12) -> Dict[str, Any]:
    """Pat directive §1-4: idempotency → threshold evaluation → ledger write.
    Wrapped by the caller in a Saga so unhandled exceptions roll back the
    lock + leave a FAILED marker."""
    _validate_payload(payload)

    if _check_idempotency(idempotency_key, db) == "duplicate":
        return {
            "outcome": "DUPLICATE_DROPPED",
            "idempotency_key": idempotency_key,
            "reason": "already processed in last 24h",
        }

    baseline = _fetch_cost_baseline(payload["resource_type"], db)
    if baseline is None:
        _release_idempotency(idempotency_key, db)
        return {
            "outcome": "BID_REJECTED",
            "reason": f"no internal cost baseline for {payload['resource_type']!r}",
            "idempotency_key": idempotency_key,
        }

    decision = _evaluate_threshold(
        bid_amount=float(payload["bid_amount"]),
        cost_baseline=baseline,
        margin_threshold=margin_threshold,
        saga=saga,
    )

    contract_id = new_contract_id()
    bid_id = new_bid_id()

    if decision["taken"] == "IF_TRUE":
        # Attestation guardrail: FALLBACK tier composing model means we
        # can't trust the signature chain. Reject the bid entirely rather
        # than let an attested-by-fallback transaction enter the ledger.
        model_now = _current_composer_model()
        if model_now["tier"] != "PRIMARY_REASONER":
            _release_idempotency(idempotency_key, db)
            _write_bid(payload, idempotency_key + "_FB", contract_id, bid_id,
                       "BID_REJECTED", db,
                       rejection_reason=(f"transaction signing model is "
                                         f"{model_now['tier']!r} — only "
                                         f"PRIMARY_REASONER tier may sign agent "
                                         f"contracts (attestation guardrail)"))
            return {
                "outcome": "BID_REJECTED",
                "reason": "composing model not in PRIMARY_REASONER tier",
                "model_attestation": model_now,
                "released_lock": True,
            }

        _write_bid(payload, idempotency_key, contract_id, bid_id,
                   "THRESHOLD_VALIDATED", db)
        signature = _sign_transaction(bid_id, contract_id, payload, db)
        return {
            "outcome": "THRESHOLD_VALIDATED",
            "contract_id": contract_id,
            "bid_id": bid_id,
            "threshold_minimum": baseline * (1 + margin_threshold),
            "bid_amount": float(payload["bid_amount"]),
            "transaction_signature": signature,
        }
    else:
        _release_idempotency(idempotency_key, db)
        minimum = baseline * (1 + margin_threshold)
        reason = (f"bid_amount {payload['bid_amount']} below threshold of "
                  f"{minimum:.4f} ({margin_threshold*100:.0f}% over baseline {baseline})")
        # Still write the rejected bid for audit — but with state BID_REJECTED.
        # Use a fresh idempotency_key suffix so the unique constraint doesn't trip
        # (the original idempotency lock is now released).
        _write_bid(payload, idempotency_key + "_REJ", contract_id, bid_id,
                   "BID_REJECTED", db, rejection_reason=reason)
        return {
            "outcome": "BID_REJECTED",
            "reason": reason,
            "idempotency_key": idempotency_key,
            "released_lock": True,
        }
