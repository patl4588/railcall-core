"""
sagalog.py — SagaLog State-Transition Wrapper

A reusable, high-order primitive that wraps any multi-step workflow with
cryptographically tracked state transitions and compensating-transaction
hooks. Drop into ~/railcall-engine/workbench/primitives/sagalog.py.

States: STARTED → COMMITTED | FAILING → COMPENSATING → FAILED

Usage pattern:

    from primitives.sagalog import Saga

    with Saga(name="checkout_v1", db=db_conn) as saga:
        saga.step("reserve_inventory", reserve, args=(order,),
                  compensate=lambda r: release_inventory(order))
        saga.step("charge_card", charge, args=(order,),
                  compensate=lambda r: refund_card(r["charge_id"]))
        saga.step("create_label", easypost_label, args=(order,),
                  compensate=lambda r: easypost_cancel(r["label_id"]))
        # if any step raises, prior step compensators fire in reverse order,
        # SagaLog row transitions STARTED → FAILING → COMPENSATING → FAILED,
        # and the original exception re-raises with tracking_id attached.

The wrapper exposes one public class (Saga) and one helper (current_tracking_id)
so any downstream worker — including a background-queue handoff — can inherit
the exact tracking ID and continue writing into the same SagaLog row.

This module touches NO catalog file at runtime. Combo registration is the
caller's responsibility via the staged combo_candidates.json.PROPOSED entry.
"""

import json
import os
import secrets
import time
import traceback
from contextlib import contextmanager
from typing import Any, Callable, Dict, List, Optional, Tuple


# --------------------------- state machine -------------------------------

STATE_STARTED = "STARTED"
STATE_COMMITTED = "COMMITTED"
STATE_FAILING = "FAILING"
STATE_COMPENSATING = "COMPENSATING"
STATE_FAILED = "FAILED"

_VALID_TRANSITIONS = {
    STATE_STARTED: {STATE_COMMITTED, STATE_FAILING},
    STATE_FAILING: {STATE_COMPENSATING},
    STATE_COMPENSATING: {STATE_FAILED},
    STATE_COMMITTED: set(),
    STATE_FAILED: set(),
}


def _validate_transition(old: str, new: str) -> None:
    if new not in _VALID_TRANSITIONS.get(old, set()):
        raise ValueError(f"illegal saga transition {old!r} -> {new!r}")


# --------------------------- tracking id ---------------------------------

_CONTEXT_TRACKING_ID: Optional[str] = None


def new_tracking_id() -> str:
    """Cryptographically random tracking ID (URL-safe base64, 22 chars).
    Sortable by creation time prefix so SagaLog rows in Postgres index well."""
    ts = int(time.time() * 1000)
    rnd = secrets.token_urlsafe(8)[:11]
    return f"sg_{ts:013d}_{rnd}"


def current_tracking_id() -> Optional[str]:
    """Returns the tracking ID for the saga currently in scope on this thread,
    or None outside a Saga context. Background workers should call this BEFORE
    crossing the queue boundary, then re-enter the saga with .resume()."""
    return _CONTEXT_TRACKING_ID


# --------------------------- the saga ------------------------------------


class Saga:
    """Wraps a sequence of steps with deterministic state tracking and
    compensating transactions. Persists state to Postgres on every transition.

    Constructor:
        name:           workflow name (e.g. 'checkout_v1')
        db:             a Postgres-style connection object with .cursor() and .commit().
                        Must support parameterized queries. SQLAlchemy / psycopg / asyncpg
                        all qualify. For tests, pass an in-memory shim.
        parent_id:      optional parent tracking_id if this saga was spawned by another.
        tracking_id:    optional override (used by .resume() in background workers).
    """

    def __init__(self, name: str, db: Any, parent_id: Optional[str] = None,
                 tracking_id: Optional[str] = None) -> None:
        self.name = name
        self.db = db
        self.parent_id = parent_id
        self.tracking_id = tracking_id or new_tracking_id()
        self.state = STATE_STARTED
        self.history: List[Tuple[str, float]] = [(STATE_STARTED, time.time())]
        self._steps: List[Dict[str, Any]] = []
        self._completed: List[Tuple[Dict[str, Any], Any]] = []  # (step, result) for compensation
        self._metadata: Dict[str, Any] = {}

    # -------- public step API --------

    def step(self, label: str, fn: Callable[..., Any], args: Tuple[Any, ...] = (),
             kwargs: Optional[Dict[str, Any]] = None,
             compensate: Optional[Callable[[Any], None]] = None,
             critical: bool = True) -> Any:
        """Execute one saga step. If `fn` raises and critical=True, kick off
        compensation in reverse order. Returns fn's result on success."""
        kwargs = kwargs or {}
        step_record = {"label": label, "started_at": time.time(),
                       "compensate": compensate, "critical": critical}
        try:
            result = fn(*args, **kwargs)
        except Exception as e:
            step_record["error"] = repr(e)
            step_record["traceback"] = traceback.format_exc()
            self._steps.append(step_record)
            if critical:
                self._fail(e)
                raise
            else:
                return None
        step_record["finished_at"] = time.time()
        step_record["status"] = "ok"
        self._steps.append(step_record)
        self._completed.append((step_record, result))
        self._persist()
        return result

    def attach_metadata(self, **kv: Any) -> None:
        """Attach arbitrary structured data to the saga log row. Useful for
        warehouse-routing decisions, geo-IP lookups, etc., that the caller
        wants in the audit trail even though they're not workflow steps."""
        self._metadata.update(kv)

    # -------- compensation flow --------

    def _fail(self, original_exception: Exception) -> None:
        """Transition STARTED → FAILING → COMPENSATING → FAILED, firing
        each completed step's compensator in reverse order."""
        self._transition(STATE_FAILING)
        self._transition(STATE_COMPENSATING)
        comp_errors: List[str] = []
        for step, result in reversed(self._completed):
            comp = step.get("compensate")
            if comp is None:
                continue
            try:
                comp(result)
                step["compensated_at"] = time.time()
                step["compensation_status"] = "ok"
            except Exception as ce:
                step["compensation_status"] = f"failed: {ce!r}"
                comp_errors.append(f"{step['label']}: {ce!r}")
        self._transition(STATE_FAILED)
        self._metadata["original_error"] = repr(original_exception)
        if comp_errors:
            self._metadata["compensation_errors"] = comp_errors
        self._persist()

    # -------- commit & state transition --------

    def commit(self) -> None:
        """Mark the saga COMMITTED. Idempotent: a second call is a no-op."""
        if self.state == STATE_COMMITTED:
            return
        self._transition(STATE_COMMITTED)
        self._persist()

    def _transition(self, new_state: str) -> None:
        _validate_transition(self.state, new_state)
        self.state = new_state
        self.history.append((new_state, time.time()))

    def _persist(self) -> None:
        """Write current state to SagaLogs Postgres table. Schema is in
        migrations/004-sagalogs.sql."""
        if self.db is None:
            return
        steps_json = json.dumps([
            {k: v for k, v in s.items() if k != "compensate"}  # callables not serializable
            for s in self._steps
        ])
        history_json = json.dumps(self.history)
        metadata_json = json.dumps(self._metadata)
        cur = self.db.cursor()
        cur.execute(
            """
            INSERT INTO sagalogs
                (tracking_id, name, parent_id, state, history, steps, metadata, updated_at)
            VALUES (%s, %s, %s, %s, %s::jsonb, %s::jsonb, %s::jsonb, now())
            ON CONFLICT (tracking_id) DO UPDATE SET
                state = EXCLUDED.state,
                history = EXCLUDED.history,
                steps = EXCLUDED.steps,
                metadata = EXCLUDED.metadata,
                updated_at = now()
            """,
            (self.tracking_id, self.name, self.parent_id, self.state,
             history_json, steps_json, metadata_json),
        )
        self.db.commit()

    # -------- context manager --------

    def __enter__(self) -> "Saga":
        global _CONTEXT_TRACKING_ID
        self._prev_tracking_id = _CONTEXT_TRACKING_ID
        _CONTEXT_TRACKING_ID = self.tracking_id
        self._persist()
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        global _CONTEXT_TRACKING_ID
        _CONTEXT_TRACKING_ID = self._prev_tracking_id
        if exc_type is None and self.state == STATE_STARTED:
            self.commit()
        return False  # never suppress exceptions

    # -------- resume from background queue --------

    @classmethod
    def resume(cls, tracking_id: str, db: Any) -> "Saga":
        """Load an existing saga from Postgres by tracking_id. Used by
        background workers that inherit a tracking_id across a queue
        boundary (e.g., the 4.5-second handoff in self-healing UI)."""
        cur = db.cursor()
        cur.execute(
            "SELECT name, parent_id, state, history, steps, metadata "
            "FROM sagalogs WHERE tracking_id = %s",
            (tracking_id,),
        )
        row = cur.fetchone()
        if row is None:
            raise LookupError(f"no saga with tracking_id {tracking_id!r}")
        name, parent_id, state, history, steps, metadata = row
        saga = cls(name=name, db=db, parent_id=parent_id, tracking_id=tracking_id)
        saga.state = state
        saga.history = json.loads(history) if isinstance(history, str) else history
        saga._steps = json.loads(steps) if isinstance(steps, str) else steps
        saga._metadata = json.loads(metadata) if isinstance(metadata, str) else metadata
        return saga
