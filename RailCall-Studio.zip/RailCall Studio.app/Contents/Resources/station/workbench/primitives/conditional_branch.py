"""
conditional_branch.py — Deterministic Conditional Branching primitive

Closes the conditional-logic catalog gap that kept ~38 workflows stuck at
PARTIAL after the SagaLog + Geo primitives landed. Drop into
workbench/primitives/conditional_branch.py.

Pat blueprint Phase 2 (msg sent 2026-06-30):
    "evaluate active, dynamic business conditions in mid-flight (margin %,
     inventory levels, currency flags). Accept three params: a source eval
     variable, a strict evaluation operator, and two explicit execution
     targets (IF_TRUE route and IF_FALSE route). Register itself directly
     with the active SagaLog context manager. Every conditional path
     selection must update the internal saga ledger state sequentially,
     ensuring branching workflows remain completely traceable and never
     fall into unrecorded zombie logic."

Public API:
    branch(value, op, threshold, if_true=fn, if_false=fn, saga=None,
           label="") -> branch_result
        Evaluates value <op> threshold. Returns:
            {"taken": "IF_TRUE" | "IF_FALSE",
             "value": value, "operator": op, "threshold": threshold,
             "label": label, "result": <fn_result>}
        If a Saga instance is provided (preferred), the decision is logged
        into the saga's history + steps automatically — no zombie logic.

    Operators (re-exported as constants):
        GREATER_THAN, GREATER_OR_EQUAL, LESS_THAN, LESS_OR_EQUAL,
        EQUALS, NOT_EQUALS, IN_SET, NOT_IN_SET

The primitive is deterministic: same (value, op, threshold) → same path.
No clock, no randomness, no hidden state.
"""

import time
from typing import Any, Callable, Iterable, Optional


# --------------------------- operators -----------------------------------

GREATER_THAN = "GREATER_THAN"
GREATER_OR_EQUAL = "GREATER_OR_EQUAL"
LESS_THAN = "LESS_THAN"
LESS_OR_EQUAL = "LESS_OR_EQUAL"
EQUALS = "EQUALS"
NOT_EQUALS = "NOT_EQUALS"
IN_SET = "IN_SET"
NOT_IN_SET = "NOT_IN_SET"

# Pat-spec aliases (2026-06-30 endgame directive §1) — map to existing baseline.
# Both names work; existing receipts using the original constants stay valid.
EQUAL_TO = EQUALS
GREATER_THAN_OR_EQUAL = GREATER_OR_EQUAL
LESS_THAN_OR_EQUAL = LESS_OR_EQUAL

_OPERATORS = {
    GREATER_THAN:    lambda a, b: a >  b,
    GREATER_OR_EQUAL: lambda a, b: a >= b,
    LESS_THAN:       lambda a, b: a <  b,
    LESS_OR_EQUAL:   lambda a, b: a <= b,
    EQUALS:          lambda a, b: a == b,
    NOT_EQUALS:      lambda a, b: a != b,
    IN_SET:          lambda a, b: a in b,
    NOT_IN_SET:      lambda a, b: a not in b,
}


def _evaluate(value: Any, op: str, threshold: Any) -> bool:
    fn = _OPERATORS.get(op)
    if fn is None:
        raise ValueError(
            f"unknown operator {op!r}. Valid: {sorted(_OPERATORS)}"
        )
    return bool(fn(value, threshold))


# --------------------------- the branch ----------------------------------

def branch(value: Any, op: str, threshold: Any,
           if_true: Optional[Callable[[], Any]] = None,
           if_false: Optional[Callable[[], Any]] = None,
           saga: Optional[Any] = None,
           label: str = "") -> dict:
    """Evaluate `value <op> threshold` and run the matching callback.

    If `saga` is a Saga instance (workbench/primitives/sagalog.py), the
    decision is recorded in its history+steps automatically. This is the
    "register directly with the SagaLog context manager" requirement
    from Pat's Phase 2 spec — every path selection updates the saga
    ledger sequentially. Calling without a saga is allowed but emits a
    warning marker in the return dict so reviewers can see the decision
    was made outside a tracked saga.

    Returns:
        {
          "taken":     "IF_TRUE" | "IF_FALSE",
          "value":     value,
          "operator":  op,
          "threshold": threshold,
          "label":     label,
          "result":    <whatever the executed callback returned>,
          "saga_logged": bool,
        }
    """
    decision = _evaluate(value, op, threshold)
    taken = "IF_TRUE" if decision else "IF_FALSE"
    callback = if_true if decision else if_false

    result = None
    if callback is not None:
        result = callback()

    saga_logged = False
    if saga is not None:
        # Log into the saga's step history. We don't call saga.step() because
        # the branch decision itself isn't a side-effectful step — it's a
        # routing decision *about* the step. We record it as a synthetic step
        # so the audit trail captures the choice.
        try:
            step_record = {
                "label": label or f"branch({op})",
                "started_at": time.time(),
                "finished_at": time.time(),
                "status": "ok",
                "branch": {
                    "operator": op,
                    "threshold": threshold,
                    "value": value,
                    "taken": taken,
                },
            }
            saga._steps.append(step_record)
            saga._completed.append((step_record, result))
            saga._persist()
            saga_logged = True
        except AttributeError:
            # `saga` isn't actually a Saga instance — accept the duck type
            # failure and just don't log. Callers should still see the
            # saga_logged: False marker in the return dict.
            pass

    return {
        "taken": taken,
        "value": value,
        "operator": op,
        "threshold": threshold,
        "label": label,
        "result": result,
        "saga_logged": saga_logged,
    }


# --------------------------- convenience guards --------------------------

def assert_in_saga(saga: Any) -> None:
    """Raise if `saga` is None — useful for callers that want to enforce
    the no-zombie-logic rule strictly: a branch outside a saga is treated
    as a programming error rather than a soft warning."""
    if saga is None:
        raise RuntimeError(
            "conditional_branch.assert_in_saga: this branch must run inside "
            "a Saga context to preserve audit trail (Pat blueprint Phase 2 "
            "no-zombie-logic rule)"
        )
