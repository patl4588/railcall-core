"""
geo_routing.py — Geo-IP Nearest-Neighbor Warehouse Routing primitive

Closes the qa_pat1_sys2 catalog gap. Drop into workbench/primitives/geo_routing.py.

Exposes:
    haversine_km(lat1, lon1, lat2, lon2) -> float
        Great-circle distance in kilometers. Deterministic.

    nearest_in_stock(customer_lat, customer_lng, requested_skus, db) -> dict
        Returns the warehouse_id (and metadata) that:
          1. has ALL requested SKUs in 'standard_stock' (filter)
          2. is geographically closest to the customer (rank by haversine)
          3. on tie (within 0.5km), prefers higher total surplus inventory
             (equilibrium fallback per Pat's blueprint Part 1 §2)
        Returns None if no warehouse has full stock.

Schema dependencies (migrations/005-warehouses.sql):
    warehouses(id, name, lat, lng, ...)
    warehouse_inventory(warehouse_id, sku, standard_stock, locked_stock, ...)

The module is pure Python (math stdlib only). Tests are offline-runnable with
the in-memory DB shim pattern from test_sagalog.py.
"""

import math
from typing import Any, Dict, Iterable, List, Optional, Sequence


# --------------------------- distance ------------------------------------

EARTH_RADIUS_KM = 6371.0088  # IUGG mean radius


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance in kilometers between two (lat, lng) points.
    Deterministic: same inputs → same output, no randomness, no clock."""
    rlat1, rlat2 = math.radians(lat1), math.radians(lat2)
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (math.sin(dlat / 2) ** 2
         + math.cos(rlat1) * math.cos(rlat2) * math.sin(dlon / 2) ** 2)
    c = 2 * math.asin(min(1.0, math.sqrt(a)))  # clamp for floating-point safety
    return EARTH_RADIUS_KM * c


# --------------------------- nearest in stock ----------------------------

TIE_THRESHOLD_KM = 0.5  # within this distance, treat as a tie and use surplus
                        # tie-break (Pat's blueprint Part 1 §2 "equilibrium fallback")


def nearest_in_stock(customer_lat: float, customer_lng: float,
                     requested_skus: Sequence[str], db: Any) -> Optional[Dict[str, Any]]:
    """Find the optimal warehouse for the customer's shipment.

    Filters first (must have ALL SKUs in standard_stock), ranks by distance,
    breaks ties by total surplus inventory. Returns a dict:
        {"warehouse_id": ..., "name": ..., "distance_km": ..., "surplus": ...}
    or None if no warehouse satisfies the stock filter.

    The db is any object with .cursor() returning a Postgres-style cursor.
    Queries are parameterized — no string interpolation, no SQL injection risk.
    """
    if not requested_skus:
        raise ValueError("requested_skus must be non-empty — cannot route an empty order")

    candidates = _eligible_warehouses(requested_skus, db)
    if not candidates:
        return None

    # Compute distance for each eligible warehouse
    scored: List[Dict[str, Any]] = []
    for w in candidates:
        d = haversine_km(customer_lat, customer_lng, w["lat"], w["lng"])
        scored.append({**w, "distance_km": d})

    # Sort by distance ascending
    scored.sort(key=lambda x: x["distance_km"])

    # Tie-break: collect everything within TIE_THRESHOLD_KM of the leader,
    # then pick the one with highest surplus inventory
    leader = scored[0]
    tied = [w for w in scored
            if w["distance_km"] - leader["distance_km"] <= TIE_THRESHOLD_KM]
    if len(tied) > 1:
        tied.sort(key=lambda x: x.get("surplus", 0), reverse=True)
        chosen = tied[0]
    else:
        chosen = leader

    return {
        "warehouse_id": chosen["id"],
        "name": chosen["name"],
        "distance_km": round(chosen["distance_km"], 3),
        "surplus": chosen.get("surplus", 0),
        "tie_breakers_considered": len(tied) - 1,
    }


def _eligible_warehouses(requested_skus: Sequence[str], db: Any) -> List[Dict[str, Any]]:
    """Query warehouses that have ALL requested SKUs in standard_stock.
    Returns list of {id, name, lat, lng, surplus} dicts."""
    cur = db.cursor()
    # One parameterized query per warehouse — eligible if all SKUs in stock there.
    # Standard SQL using ALL/GROUP BY HAVING — works on Postgres + sqlite shim.
    placeholders = ",".join(["%s"] * len(requested_skus))
    cur.execute(
        f"""
        SELECT w.id, w.name, w.lat, w.lng,
               COALESCE(SUM(wi.standard_stock - wi.locked_stock), 0) AS surplus
        FROM warehouses w
        JOIN warehouse_inventory wi ON wi.warehouse_id = w.id
        WHERE wi.sku IN ({placeholders})
          AND wi.standard_stock > 0
        GROUP BY w.id, w.name, w.lat, w.lng
        HAVING COUNT(DISTINCT wi.sku) = %s
        """,
        list(requested_skus) + [len(requested_skus)],
    )
    rows = cur.fetchall()
    return [
        {"id": r[0], "name": r[1], "lat": r[2], "lng": r[3], "surplus": r[4]}
        for r in rows
    ]
