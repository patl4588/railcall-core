"""
gateway_auth.py — Edge Security & Gateway Authorization

Pat directive 2026-06-30 — "move the autonomous multi-agent micro-economy
off the loopback boundary." Two hard requirements before any agent payload
touches the broker:

  1. Ed25519 signature verification of every incoming request (no passwords,
     no API keys — asymmetric crypto only). Failed verify → 401 Unauthorized.
  2. Token-bucket rate limiting per agent — 10 burst, refill 2/sec, 1 token
     per request. Empty bucket → 429 Too Many Requests with Retry-After.

Public API:

    register_agent(agent_id, public_key_hex, registry) -> None
    register_agent_from_pem(agent_id, pem_bytes, registry) -> None

    authorize_request(agent_id, signature_hex, payload_bytes, registry,
                      bucket_state, now_seconds) -> dict
        Returns one of:
            {"status": 200, "verified": True, "tokens_remaining": <float>}
            {"status": 401, "reason": "<...>"}
            {"status": 429, "retry_after_seconds": <float>}

`registry` is any dict-like mapping {agent_id: public_key_bytes}. `bucket_state`
is a dict-like mapping {agent_id: TokenBucket}. Both are caller-managed so
this module stays dependency-free and side-effect-free.

`now_seconds` is passed in by the caller — the primitive never reads the
clock itself. This is deliberately deterministic for testing (same pattern
as compose_engine, sagalog, etc.).
"""

import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature


# --------------------------- token bucket --------------------------------

BURST_CAPACITY = 10
REFILL_RATE_PER_SECOND = 2.0
COST_PER_REQUEST = 1


@dataclass
class TokenBucket:
    """Thread-safe leaky-bucket / token-bucket hybrid.

    Tokens accumulate at `refill_rate_per_second` up to `capacity`. Each
    request consumes `COST_PER_REQUEST`. Empty bucket → reject with the
    exact seconds remaining until ONE token replenishes.

    `last_refill = None` is the "uninitialized" sentinel — using `0.0`
    would collide with real t=0 timestamps in deterministic tests.
    """
    capacity: float = BURST_CAPACITY
    refill_rate_per_second: float = REFILL_RATE_PER_SECOND
    tokens: float = field(default=float(BURST_CAPACITY))
    last_refill: Optional[float] = None
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def take(self, now_seconds: float, cost: float = COST_PER_REQUEST) -> bool:
        """Try to consume `cost` tokens. Returns True if successful, False
        if not enough tokens. Refills the bucket based on elapsed time first."""
        with self._lock:
            if self.last_refill is None:
                # First call ever — no time has elapsed
                self.last_refill = now_seconds
            elapsed = max(0.0, now_seconds - self.last_refill)
            self.tokens = min(self.capacity,
                              self.tokens + elapsed * self.refill_rate_per_second)
            self.last_refill = now_seconds

            if self.tokens >= cost:
                self.tokens -= cost
                return True
            return False

    def seconds_until_one_token(self, now_seconds: float) -> float:
        """How long the caller should wait before the bucket has at least
        1 token. Used for the Retry-After header."""
        with self._lock:
            # Re-compute current effective tokens
            if self.last_refill is None:
                eff = self.tokens
            else:
                elapsed = max(0.0, now_seconds - self.last_refill)
                eff = min(self.capacity,
                          self.tokens + elapsed * self.refill_rate_per_second)
            if eff >= COST_PER_REQUEST:
                return 0.0
            needed = COST_PER_REQUEST - eff
            return needed / self.refill_rate_per_second


# --------------------------- agent registry ------------------------------

def register_agent(agent_id: str, public_key_hex: str,
                   registry: Dict[str, bytes]) -> None:
    """Register an agent's Ed25519 public key (raw 32 bytes hex-encoded)."""
    raw = bytes.fromhex(public_key_hex)
    if len(raw) != 32:
        raise ValueError(
            f"Ed25519 public key must be 32 bytes, got {len(raw)}"
        )
    # Round-trip through the cryptography library to validate it's a real key
    Ed25519PublicKey.from_public_bytes(raw)
    registry[agent_id] = raw


# --------------------------- the gateway --------------------------------

def authorize_request(agent_id: str,
                      signature_hex: str,
                      payload_bytes: bytes,
                      registry: Dict[str, bytes],
                      bucket_state: Dict[str, TokenBucket],
                      now_seconds: float) -> Dict[str, Any]:
    """Top-level edge check. Pat directive §3: signature first, THEN rate
    limit. (Reversing the order would let an adversary exhaust someone
    else's bucket by spamming with that agent_id — even with garbage
    signatures.)"""

    # ---- step 1: agent must be known
    pk_bytes = registry.get(agent_id)
    if pk_bytes is None:
        return {"status": 401, "reason": "unknown_agent_id"}

    # ---- step 2: verify Ed25519 signature
    try:
        sig_bytes = bytes.fromhex(signature_hex)
    except (ValueError, TypeError):
        return {"status": 401, "reason": "malformed_signature_hex"}
    if len(sig_bytes) != 64:
        return {"status": 401, "reason": "signature_must_be_64_bytes"}

    pub = Ed25519PublicKey.from_public_bytes(pk_bytes)
    try:
        pub.verify(sig_bytes, payload_bytes)
    except InvalidSignature:
        return {"status": 401, "reason": "invalid_signature"}

    # ---- step 3: token bucket
    bucket = bucket_state.get(agent_id)
    if bucket is None:
        bucket = TokenBucket()
        bucket_state[agent_id] = bucket
    if not bucket.take(now_seconds):
        retry = bucket.seconds_until_one_token(now_seconds)
        return {"status": 429,
                "retry_after_seconds": round(retry, 3),
                "reason": "rate_limited_token_bucket_exhausted"}

    # ---- all checks pass
    return {"status": 200, "verified": True,
            "tokens_remaining": round(bucket.tokens, 3)}


# --------------------------- saga integration helper --------------------

def wrap_broker_call(agent_id: str, signature_hex: str, payload_bytes: bytes,
                     registry: Dict[str, bytes],
                     bucket_state: Dict[str, TokenBucket],
                     now_seconds: float,
                     broker_callable,
                     *broker_args, **broker_kwargs) -> Dict[str, Any]:
    """Pat directive §3: 'wire the gateway component directly into the
    front of the multi-agent procurement broker.' This helper enforces
    the gate, then invokes the broker. The broker NEVER sees the raw
    request until both gates pass.

    If a VALID authenticated agent hits the bucket limit, we log the
    event as a non-fatal warning before returning 429. The caller can
    surface this telemetry; the saga history stays immutable."""
    gate_result = authorize_request(
        agent_id, signature_hex, payload_bytes,
        registry, bucket_state, now_seconds,
    )
    if gate_result["status"] != 200:
        # Annotate with whether the agent_id was at least KNOWN — that
        # distinguishes "rogue probe" (unknown_agent_id) from "valid
        # agent hit limit" (429 on a known agent).
        gate_result["agent_known"] = agent_id in registry
        gate_result["telemetry_class"] = (
            "rate_limit_warning_known_agent"
            if gate_result["status"] == 429 and gate_result["agent_known"]
            else "auth_or_rate_limit_block"
        )
        return gate_result

    # Pass through to the broker
    broker_response = broker_callable(*broker_args, **broker_kwargs)
    return {"status": 200, "gate": gate_result, "broker_response": broker_response}
