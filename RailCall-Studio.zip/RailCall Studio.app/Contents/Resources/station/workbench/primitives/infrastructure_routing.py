"""
infrastructure_routing.py — Geo-spatial routing for decentralized infrastructure

Pat directive (post-attestation): "spatial routing logic for the decentralized
infrastructure". Builds on geo_routing.haversine_km — the math is the same; the
filters are different: instead of "has all requested SKUs in stock", we filter by
"has available capacity for the requested resource type AND meets the agent's
max latency tolerance."

Public API:

    nearest_capable_node(customer_lat, customer_lng, resource_type,
                        requested_capacity, max_latency_ms, db,
                        latency_ms_per_km=0.005) -> Optional[dict]

        Returns the node that:
          1. Matches `resource_type` (compute / storage / inference / bandwidth)
          2. Has at least `requested_capacity` available
          3. Has estimated round-trip latency ≤ `max_latency_ms`
             (latency ≈ distance_km × latency_ms_per_km × 2 + node_base_latency)
          4. Is closest to the customer by Haversine distance
          5. On near-tie within 0.5 km, prefers the node with HIGHER
             available_capacity (load-balance the network)

        Returns None if no node qualifies — the broker treats this as a
        BID_REJECTED with reason "no routable infrastructure".

Schema dependencies (migrations/007-infrastructure-nodes.sql).

This module composes with — does NOT replace — the warehouse-routing
geo_routing primitive. Both reuse haversine_km from geo_routing.
"""

from typing import Any, Dict, List, Optional, Sequence

from .geo_routing import haversine_km, TIE_THRESHOLD_KM


VALID_RESOURCE_TYPES = {"compute", "storage", "logistics", "inference", "bandwidth"}

# Speed-of-light-in-fiber lower bound is ~5us/km (round trip ~10us/km = 0.01ms/km).
# Real-world routing typically adds switching latency; ~0.005ms/km one-way is a
# reasonable default before node base latency.
DEFAULT_LATENCY_MS_PER_KM = 0.005


def nearest_capable_node(customer_lat: float, customer_lng: float,
                         resource_type: str,
                         requested_capacity: float,
                         max_latency_ms: float,
                         db: Any,
                         latency_ms_per_km: float = DEFAULT_LATENCY_MS_PER_KM
                         ) -> Optional[Dict[str, Any]]:
    """See module docstring. Deterministic — same inputs, same answer."""
    if resource_type not in VALID_RESOURCE_TYPES:
        raise ValueError(
            f"resource_type {resource_type!r} not in {sorted(VALID_RESOURCE_TYPES)}"
        )
    if requested_capacity <= 0:
        raise ValueError("requested_capacity must be > 0")
    if max_latency_ms <= 0:
        raise ValueError("max_latency_ms must be > 0")

    candidates = _eligible_nodes(resource_type, requested_capacity, db)
    if not candidates:
        return None

    # Compute distance + estimated latency for each. Round-trip = 2 × distance latency.
    scored: List[Dict[str, Any]] = []
    for node in candidates:
        d_km = haversine_km(customer_lat, customer_lng, node["lat"], node["lng"])
        est_latency = d_km * latency_ms_per_km * 2 + node.get("base_latency_ms", 0)
        if est_latency > max_latency_ms:
            continue
        scored.append({
            **node,
            "distance_km": d_km,
            "estimated_latency_ms": round(est_latency, 3),
        })
    if not scored:
        return None

    scored.sort(key=lambda x: x["distance_km"])

    # Tie-break within TIE_THRESHOLD_KM: prefer higher AVAILABLE capacity (load balance)
    leader = scored[0]
    tied = [n for n in scored
            if n["distance_km"] - leader["distance_km"] <= TIE_THRESHOLD_KM]
    if len(tied) > 1:
        tied.sort(key=lambda x: x["available_capacity"], reverse=True)
        chosen = tied[0]
    else:
        chosen = leader

    return {
        "node_id": chosen["id"],
        "name": chosen["name"],
        "region": chosen.get("region"),
        "resource_type": resource_type,
        "distance_km": round(chosen["distance_km"], 3),
        "estimated_latency_ms": chosen["estimated_latency_ms"],
        "available_capacity": chosen["available_capacity"],
        "requested_capacity": requested_capacity,
        "tie_breakers_considered": len(tied) - 1,
    }


def _eligible_nodes(resource_type: str, requested_capacity: float,
                    db: Any) -> List[Dict[str, Any]]:
    """Read infrastructure_nodes rows that match resource_type AND have
    (total_capacity - used_capacity) ≥ requested_capacity AND active."""
    cur = db.cursor()
    cur.execute(
        """
        SELECT id, name, region, lat, lng,
               total_capacity, used_capacity,
               (total_capacity - used_capacity) AS available_capacity,
               base_latency_ms
        FROM infrastructure_nodes
        WHERE resource_type = %s
          AND active = TRUE
          AND (total_capacity - used_capacity) >= %s
        """,
        (resource_type, requested_capacity),
    )
    rows = cur.fetchall()
    return [
        {"id": r[0], "name": r[1], "region": r[2], "lat": r[3], "lng": r[4],
         "total_capacity": r[5], "used_capacity": r[6],
         "available_capacity": r[7], "base_latency_ms": r[8] or 0}
        for r in rows
    ]
