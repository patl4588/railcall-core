"""
shipping_label_service.py — EasyPost shipping label wrapper

Closes the qa_pat1_sys4 catalog gap. Drop into
workbench/primitives/shipping_label_service.py.

Pat blueprint Phase 3 (msg sent 2026-06-30): "Build an explicit, highly
isolated service wrapper around the EasyPost shipping label generation
suite. Force the wrapper to intercept incoming address tokens, pass them
through a strict client-side validation pattern, and structure the
label-generation payload before hitting any external integration nodes.
Map the wrapper's internal exceptions directly into the SagaLog system."

Public API:
    validate_address(address: dict) -> normalized: dict
        Strict client-side validation. Raises AddressValidationError on
        missing/invalid fields. Never hits an external API.

    generate_label(from_addr, to_addr, parcel, easypost_client, saga=None)
        Normalizes addresses, calls EasyPost, logs to saga, returns
        {label_id, tracking_code, label_url, carrier, cost}.
        On failure, raises ShippingLabelError + signals saga to
        compensate via saga.set_failing() — Pat Phase 3 hard rule:
        "signal the parent saga engine to execute Phase 5's compensating
        stock-rollback routines."

The module duck-types `easypost_client` and `saga` — no external library
dependency at import time. Tests use an in-memory shim. Real callers pass
a real easypost.Client() and a real Saga instance.
"""

import re
from typing import Any, Dict, Optional, Sequence


# --------------------------- errors --------------------------------------

class AddressValidationError(ValueError):
    """Address didn't pass client-side validation. Saga compensation NOT
    triggered for this — it's a programmer/operator bug, not a runtime
    fault."""
    pass


class ShippingLabelError(RuntimeError):
    """External shipping carrier failed to generate label. Saga compensation
    IS triggered — this is a runtime fault that should roll back inventory
    holds upstream."""
    pass


# --------------------------- address validation --------------------------

# US ZIP: 5 digits, optional -4 suffix. International: any country provides 'postal_code'.
_US_ZIP_RE = re.compile(r"^\d{5}(-\d{4})?$")

_REQUIRED_ADDRESS_FIELDS = ("name", "street1", "city", "state", "postal_code", "country")


def validate_address(address: Dict[str, Any]) -> Dict[str, Any]:
    """Strict client-side address validation. Raises AddressValidationError
    on missing/invalid fields. Never hits the network."""
    if not isinstance(address, dict):
        raise AddressValidationError(f"address must be a dict, got {type(address).__name__}")

    missing = [f for f in _REQUIRED_ADDRESS_FIELDS if not address.get(f)]
    if missing:
        raise AddressValidationError(f"address missing required fields: {missing}")

    country = address["country"].upper().strip()
    if len(country) != 2:
        raise AddressValidationError(
            f"country must be a 2-letter ISO 3166-1 alpha-2 code, got {address['country']!r}")

    postal = str(address["postal_code"]).strip()
    if country == "US" and not _US_ZIP_RE.match(postal):
        raise AddressValidationError(
            f"US postal_code must match \\d{{5}}(-\\d{{4}})?, got {postal!r}")
    if not postal:
        raise AddressValidationError("postal_code is empty after strip")

    # Normalize: strip whitespace, uppercase country/state for US
    normalized = dict(address)
    normalized["country"] = country
    if country == "US":
        normalized["state"] = address["state"].upper().strip()
    normalized["postal_code"] = postal
    for k in ("street1", "city", "name"):
        normalized[k] = str(address[k]).strip()

    return normalized


# --------------------------- parcel validation ---------------------------

_PARCEL_FIELDS = ("weight",)  # bare minimum; EasyPost wants oz; many setups also pass length/width/height


def validate_parcel(parcel: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(parcel, dict):
        raise AddressValidationError(f"parcel must be a dict, got {type(parcel).__name__}")
    if "weight" not in parcel:
        raise AddressValidationError("parcel.weight is required (EasyPost expects ounces)")
    w = parcel["weight"]
    if not isinstance(w, (int, float)) or w <= 0:
        raise AddressValidationError(f"parcel.weight must be positive number, got {w!r}")
    return dict(parcel)


# --------------------------- label generation ----------------------------

def generate_label(from_addr: Dict[str, Any],
                   to_addr: Dict[str, Any],
                   parcel: Dict[str, Any],
                   easypost_client: Any,
                   saga: Optional[Any] = None,
                   carrier_preference: Optional[Sequence[str]] = None,
                   label: str = "shipping_label") -> Dict[str, Any]:
    """Normalize + validate, generate a shipping label, log to saga.

    On external failure, raises ShippingLabelError AND signals the saga
    that it's transitioning toward FAILING — this is the integration
    point Pat called out: "translate that specific payload and immediately
    signal the parent saga engine to execute Phase 5's compensating
    stock-rollback routines."

    The caller's saga then catches the exception in its `step()` wrapper
    and runs its compensation chain. The shipping wrapper does NOT call
    saga._fail() itself — that's the saga's own responsibility.
    """
    # 1. Validate inputs (cheap, no network)
    from_norm = validate_address(from_addr)
    to_norm   = validate_address(to_addr)
    parcel_n  = validate_parcel(parcel)

    # 2. Structure the payload (no network yet)
    payload = {
        "from_address": from_norm,
        "to_address":   to_norm,
        "parcel":       parcel_n,
    }
    if carrier_preference:
        payload["carrier_accounts"] = list(carrier_preference)

    # 3. External call
    try:
        # Real client: easypost.Shipment.create(**payload).buy(rate=...)
        # Duck-typed: client.create_shipment(payload) returns a dict.
        result = easypost_client.create_shipment(payload)
    except Exception as e:
        # Translate the carrier exception into our wrapper-internal one.
        # Don't leak EasyPost-specific exception types upward — that's the
        # "isolated wrapper" rule from Pat Phase 3.
        wrapped = ShippingLabelError(f"shipping carrier rejected label request: {e!r}")
        # Annotate the saga step in flight so the caller's saga.step()
        # context records the failure with structured data before it
        # invokes compensators.
        if saga is not None:
            try:
                if saga._steps:
                    saga._steps[-1]["shipping_failure"] = {
                        "carrier_error": repr(e),
                        "payload_size": len(str(payload)),
                        "from_country": from_norm["country"],
                        "to_country": to_norm["country"],
                    }
                    saga._persist()
            except Exception:
                pass
        raise wrapped

    # 4. Normalize the return shape so callers don't depend on EasyPost's schema
    out = {
        "label_id":      result.get("id"),
        "tracking_code": result.get("tracking_code"),
        "label_url":     result.get("postage_label", {}).get("label_url"),
        "carrier":       result.get("selected_rate", {}).get("carrier"),
        "service":       result.get("selected_rate", {}).get("service"),
        "cost":          result.get("selected_rate", {}).get("rate"),
        "currency":      result.get("selected_rate", {}).get("currency", "USD"),
    }

    # 5. Optionally annotate the saga step
    if saga is not None:
        try:
            if saga._steps:
                saga._steps[-1]["shipping_success"] = {
                    "label_id": out["label_id"],
                    "carrier": out["carrier"],
                    "cost": out["cost"],
                }
                saga._persist()
        except Exception:
            pass

    return out
