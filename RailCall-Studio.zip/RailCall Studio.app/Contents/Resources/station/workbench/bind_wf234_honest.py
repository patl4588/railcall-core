#!/usr/bin/env python3
"""
bind_wf234_honest.py — finish WF2/WF3/WF4 the SAME honest way WF1 was done.

NO status is hand-set. For each workflow this:
  - registers the REAL backend component(s) for the null step(s): RUNS its smoke() here (must
    return PASS), real file sha256, MIT, flagged STAGED_LOCAL_AUTHORED / trusted_reuse_allowed=false
    (no governance overclaim),
  - binds the null step(s) to the component,
  - invokes compose_engine.compile_spec() so the ENGINE computes the result,
  - regenerates the workflow json from the receipt verbatim (PASS or PARTIAL — whatever it earns).
Components are the robust, smoke-tested modules already on disk — NOT the weaker pasted stubs.
"""
import os
import sys
import json
import hashlib
import importlib

ROOT = "/tmp/wb-engine"
sys.path.insert(0, os.path.join(ROOT, "workbench"))
sys.path.insert(0, os.path.join(ROOT, "library", "modules"))
import compose_engine as ce

IDX = os.path.join(ROOT, "library", "ui", "ui_component_index.json")
RCPT_DIR = os.path.join(ROOT, "library", "ui", "receipts")
MOD_DIR = os.path.join(ROOT, "library", "modules")
WF_DIR = os.path.join(ROOT, ".railcall_workspace", "workflows")
STAMP = "2026-06-24T12:00:00Z"

# null-step label -> the real component that backs it
WIRING = {
    "manage_leads.json": {"assign lead to sales team": "sales_operations"},
    "tree_service_unpaid_invoices.json": {"Reconcile the payment or move it to bad debt": "treasury_controller"},
    "user_workflow.json": {"Save user data to database": "database_persistence",
                           "Send confirmation email": "outbound_communications"},
}


def register(component):
    """Register a real component: RUN its smoke (must pass), real sha256, honest receipt."""
    src = os.path.join(MOD_DIR, component + ".py")
    smoke = importlib.import_module(component).smoke()      # RUN it — honest, not asserted
    if smoke != "PASS":
        raise SystemExit("%s smoke != PASS (%r) — refusing to register" % (component, smoke))
    sha = "sha256:" + hashlib.sha256(open(src, "rb").read()).hexdigest()
    idx = json.load(open(IDX))
    comps = idx.setdefault("components", [])
    if not any(c.get("component_name") == component for c in comps):
        comps.append({"component_name": component, "role": "backend_action",
                      "license": "MIT", "version": "0.1.0", "smoke_test_result": smoke})
        json.dump(idx, open(IDX, "w"), indent=2)
    json.dump({"asset_type": "component", "component_name": component, "role": "backend_action",
               "source": "original_authored_in_session", "license": "MIT", "license_allowed": True,
               "local_mirror_path": "library/modules/%s.py" % component, "archive_sha256": sha,
               "smoke_test_type": "python_unit",
               "smoke_test_command": "python3 -c 'import %s; %s.smoke()'" % (component, component),
               "smoke_test_result": smoke, "promotion_status": "STAGED_LOCAL_AUTHORED",
               "trusted_reuse_allowed": False, "status": "STAGED"},
              open(os.path.join(RCPT_DIR, component + ".receipt.json"), "w"), indent=2)
    return sha


for comp in ("treasury_controller", "database_persistence", "outbound_communications"):
    print("registered %-24s %s... smoke=PASS" % (comp, register(comp)[:23]))

print("---")
for fname, binds in WIRING.items():
    path = os.path.join(WF_DIR, fname)
    wf = json.load(open(path))
    steps = []
    for s in wf["steps"]:
        piece = binds.get(s["label"], s.get("piece"))
        steps.append({"label": s["label"], "piece": piece})
    spec = {"name": wf["id"], "title": wf["title"], "trigger": wf.get("trigger", ""),
            "steps": steps, "outputs": wf.get("outputs", []), "stage_map": wf.get("stage_map", {})}
    r = ce.compile_spec(spec, ROOT, os.path.join(ROOT, "builds"), os.path.join(ROOT, "tests"), STAMP)["receipt"]
    wf["status"] = r["result"]
    wf["steps"] = r["nodes"]
    wf["audited_pieces"] = [p["name"] for p in r["audited_pieces"]]
    wf["needs_audit"] = [u["label"] for u in r["unaudited_steps"]]
    wf["artifact"] = r["artifact"]
    wf["integrity_root"] = r["integrity_root"]
    wf["updated"] = STAMP
    json.dump(wf, open(path, "w"), indent=2)
    print("%-34s ENGINE-result=%-8s needs_audit=%s" % (wf["id"], r["result"], wf["needs_audit"]))
