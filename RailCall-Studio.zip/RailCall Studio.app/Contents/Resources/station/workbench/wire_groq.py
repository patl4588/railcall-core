#!/usr/bin/env python3
"""Wire your EXISTING Groq key into the studio vault. Reads it from ~/.kai/keys.env (where it
already lives), writes it to the 0600 vault, never prints the value. Run: python3 wire_groq.py"""
import json, os, re

KEYS_ENV = os.path.expanduser("~/.kai/keys.env")
VAULT = "/tmp/wb-engine/.railcall_workspace/keys.local.json"

src = open(KEYS_ENV).read()
m = re.search(r'^\s*(?:export\s+)?GROQ_API_KEY\s*=\s*["\']?([^"\'\s]+)', src, re.M)
if not m:
    raise SystemExit("GROQ_API_KEY not found in " + KEYS_ENV)
key = m.group(1)                       # never printed

v = json.load(open(VAULT))             # preserves the signing seed + ollama already in there
v["groq"] = {"GROQ_API_KEY": key}
tmp = VAULT + ".tmp"
with open(tmp, "w") as f:
    json.dump(v, f, indent=2)
os.chmod(tmp, 0o600)
os.replace(tmp, VAULT)                 # atomic
os.chmod(VAULT, 0o600)

reread = json.load(open(VAULT))
ok = isinstance(reread.get("groq"), dict) and len(reread["groq"].get("GROQ_API_KEY", "")) > 20
print("✅ groq wired to 0600 vault from ~/.kai/keys.env (value never printed):", ok)
print("   vault keys now:", list(reread.keys()))
print("   → tell Claude 'groq done' and it will flip the status + re-audit")
