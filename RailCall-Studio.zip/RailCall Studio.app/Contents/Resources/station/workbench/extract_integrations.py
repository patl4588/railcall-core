#!/usr/bin/env python3
"""Deep-dive extraction: every integration in the manifest, joined to its source-of-truth endpoint
(test_integration probes) and its live vault status. No truncation, no ellipses."""
import json, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
WS = os.environ.get("RAILCALL_WS", os.path.join(os.path.dirname(HERE), ".railcall_workspace"))

ints_json = json.load(open(os.path.join(WS, "integrations.json")))
vault = json.load(open(os.path.join(WS, "keys.local.json")))           # CONNECTED iff a key sits here
vault_ids = set(vault.keys())

# Real endpoints the code actually probes — lifted verbatim from test_integration() in studio_server.py.
PROBE = {
    "anthropic": "https://api.anthropic.com/v1/models",
    "openai": "https://api.openai.com/v1/models",
    "gemini": "https://generativelanguage.googleapis.com/v1beta/models",
    "groq": "https://api.groq.com/openai/v1/chat/completions",
    "ollama": "http://127.0.0.1:11434/api/tags",
    "github": "https://api.github.com/repos/{owner}/{repo}",
    "gitlab": "https://gitlab.com/api/v4/user",
    "stripe": "https://api.stripe.com/v1/balance",
    "twilio": "https://api.twilio.com/2010-04-01/Accounts/{sid}.json",
    "telegram": "https://api.telegram.org/bot{token}/getMe",
    "slack": "https://slack.com/api/auth.test",
    "discord": "https://discord.com/api/v10/users/@me",
    "notion": "https://api.notion.com/v1/users/me",
    "linear": "https://api.linear.app/graphql",
    "cloudflare": "https://api.cloudflare.com/client/v4/user/tokens/verify",
    "replicate": "https://api.replicate.com/v1/account",
    "uptimerobot": "https://api.uptimerobot.com/v2/getMonitors",
    "microsoft": "https://graph.microsoft.com/.default",
}

rows = []
for cat, items in ints_json.items():
    if not isinstance(items, list):
        continue
    for it in items:
        iid = it.get("id")
        name = it.get("name", iid)
        req = it.get("required", []) or it.get("requires", [])
        keys = ", ".join(req) if req else "—"
        # endpoint: the verbatim probe URL if the code actually talks to it, else the declared docs/ref base
        ep = PROBE.get(iid) or it.get("docs") or "—"
        wired = "‡" if iid in PROBE else ""
        connected = (iid in vault_ids) and bool(vault.get(iid))
        status = "✅ CONNECTED" if connected else "⛔ NOT_CONFIGURED"
        rows.append((name, ep + ("  " + wired if wired else ""), keys, status, iid, cat))

rows.sort(key=lambda r: r[0].lower())

print(f"\n# RailCall Studio — Integration Endpoint × Key × Status Matrix  ({len(rows)} integrations)\n")
print(f"_‡ = endpoint the code live-probes (test_integration); others show the declared docs/reference base. "
      f"CONNECTED requires a key in the 0600 vault (keys.local.json) — currently {len(vault_ids - {'_railcall_signing_seed'})} BYOK keys present._\n")
print("| # | Integration | API Endpoint / Base URL | Required Env / Vault Key | Status |")
print("|---|---|---|---|---|")
for i, (name, ep, keys, status, iid, cat) in enumerate(rows, 1):
    print(f"| {i} | {name} | `{ep}` | `{keys}` | {status} |")

# tallies
conn = sum(1 for r in rows if "CONNECTED" in r[3])
probed = sum(1 for r in rows if "‡" in r[1])
print(f"\n**Totals:** {len(rows)} integrations · {conn} CONNECTED · {len(rows)-conn} NOT_CONFIGURED · {probed} have a live-probe endpoint wired in code.")
