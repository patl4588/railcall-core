#!/usr/bin/env python3
"""
RailCall billing telemetry — the client's metered-run ping.

This is the seam where a "local-first" product could quietly start phoning home, so the rules are
explicit and ENFORCED IN CODE, not just promised in docs:

  1. GATED. No `api_key` in .railcall_workspace/config.local.json -> NO ping,
     no socket, nothing. A fresh box, a dev box, and the live-demo box (which is never configured with
     a billing id) call home ZERO times. This is what keeps the across-the-table demo at a literal 0
     outbound sockets — not a promise, a code path that returns before any network call.

  2. FIRE-AND-FORGET. Runs on a daemon thread with a 3s timeout; every exception is swallowed. A failed,
     slow, or offline ping NEVER raises, NEVER blocks the user's workflow, NEVER changes the run result.
     Local-first resilience is absolute — pull the network cable and the run still completes instantly.

  3. MINIMAL PAYLOAD. We send exactly {api_key, run_count, idempotency_key} — your own RailCall key (the
     same one the balance read uses to identify you) plus an integer. NEVER workflow data, record contents,
     customer rows, provider/model keys, or receipt bodies. Just "this key ran N governed times."

  4. AUDITABLE. Every attempt and its outcome is appended to .railcall_workspace/billing_meter.jsonl
     (run-count only). A customer can `tail` that file and reconcile the exact bytes we ever sent against
     their own network monitor. Billing is never hidden.

  5. NOT A WORKFLOW ACTION. The run's receipt still reports external_api_touched honestly about the
     *workflow*. This meter is RailCall's own infrastructure, disclosed and logged separately; we never
     fold it into the receipt's external-touch claim to dress it up or hide it.

stdlib only (urllib) — this module must never add a pip dependency to the local-first client.
"""
import json
import os
import hashlib
import threading
import urllib.request

# Default to the SAME service domain the client already talks to for the balance read, so we don't
# introduce a second mystery host. Overridable per-install via config.local.json "telemetry_endpoint".
DEFAULT_ENDPOINT = os.environ.get("RAILCALL_GATEWAY_URL", "https://railcall-core.onrender.com").rstrip("/") + "/meter"
TIMEOUT_S = 3


def _load_config(ws_dir):
    """Read .railcall_workspace/config.local.json. Missing/unreadable/garbage -> {} (fail to no-op)."""
    try:
        with open(os.path.join(ws_dir, "config.local.json"), encoding="utf-8") as f:
            c = json.load(f)
        return c if isinstance(c, dict) else {}
    except Exception:
        return {}


def _log(ws_dir, record):
    try:
        with open(os.path.join(ws_dir, "billing_meter.jsonl"), "a", encoding="utf-8") as f:
            f.write(json.dumps(record, sort_keys=True) + "\n")
    except Exception:
        pass  # logging must never break the app either


def _run_count(receipt):
    if isinstance(receipt, dict):
        try:
            return max(1, int(receipt.get("records_processed") or receipt.get("run_count") or 1))
        except Exception:
            return 1
    return 1


def meter(receipt, ws_dir, stamp=""):
    """Meter ONE governed run. Returns a small status dict (for tests/callers); NEVER raises.

    Honesty gate: with the engine currently DRY-ONLY (every flow receipt has external_api_touched=False),
    metering "real external sends only" would meter nothing — so the billable unit of the pilot is the
    governed simulation itself. config "meter_dry_runs" (default True) bills per governed run; set it
    False to bill ONLY real external executions once Phase-1 real-send lands. Either way: no configured
    billing id -> no ping."""
    cfg = _load_config(ws_dir)
    api_key = cfg.get("api_key")
    if not api_key:
        return {"metered": False, "reason": "no api_key configured"}

    really_executed = bool(receipt.get("external_api_touched")) if isinstance(receipt, dict) else False
    if not really_executed and not cfg.get("meter_dry_runs", True):
        return {"metered": False, "reason": "dry-run and meter_dry_runs=false"}

    run_count = _run_count(receipt)
    endpoint = cfg.get("telemetry_endpoint") or DEFAULT_ENDPOINT
    # Idempotency bound to the run's own integrity/signature so a retry or a replayed receipt can't
    # double-bill — the gateway dedups on this key via the same processed_events table as its Stripe webhook.
    seal = ""
    if isinstance(receipt, dict):
        seal = str(receipt.get("integrity") or receipt.get("integrity_hash") or receipt.get("integrity_root") or "")
    idem = "idem_" + hashlib.sha256((seal + "|" + str(api_key) + "|" + str(run_count)).encode()).hexdigest()[:32]
    payload = {"api_key": api_key, "run_count": run_count, "idempotency_key": idem}

    rec = {"at": stamp, "endpoint": endpoint, "run_count": run_count,
           "api_key": str(api_key)[:8] + "…", "idempotency_key": idem}
    try:
        req = urllib.request.Request(endpoint, data=json.dumps(payload).encode(),
                                     headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=TIMEOUT_S) as r:
            rec["result"], rec["status"] = "ok", getattr(r, "status", 200)
    except Exception as e:
        # offline / DNS / timeout / endpoint down — ALL swallowed. The user's run already succeeded.
        rec["result"], rec["error"] = "skipped", type(e).__name__
    _log(ws_dir, rec)
    return {"metered": rec.get("result") == "ok", **rec}


def meter_async(receipt, ws_dir, stamp=""):
    """Fire-and-forget: meter() on a daemon thread so the user's run result returns INSTANTLY and a hung
    or slow ping can never add latency to the workflow. No-op (returns None) if no billing id configured,
    so we don't even spawn a thread on an unconfigured/demo/dev box."""
    if not _load_config(ws_dir).get("api_key"):
        return None
    t = threading.Thread(target=meter, args=(receipt, ws_dir, stamp), daemon=True)
    t.start()
    return t
